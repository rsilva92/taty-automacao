<?php
/**
 * TATI STUDIO — AGENTE API v3.0.0
 * Sem banco de dados: projetos salvos como arquivos JSON em /data/
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

// ── Auth ──────────────────────────────────────────────────────────────────────
if (empty($_SESSION['auth'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado.']);
    exit;
}

// ── Config ────────────────────────────────────────────────────────────────────
$configFile = dirname(__DIR__) . '/includes/config.php';
if (!file_exists($configFile)) {
    http_response_code(500);
    echo json_encode(['error' => 'Sistema não configurado.']);
    exit;
}
require_once $configFile;

// ── Helpers de arquivo ────────────────────────────────────────────────────────
function getDataDir(): string {
    $dir = defined('DATA_DIR') ? DATA_DIR : dirname(__DIR__) . '/data';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        // Protege o diretório de acesso direto via web
        file_put_contents($dir . '/.htaccess', "Deny from all\n");
    }
    return $dir;
}

function generateId(): string {
    return date('Ymd_His') . '_' . substr(bin2hex(random_bytes(4)), 0, 6);
}

function projectPath(string $id): string {
    // Sanitiza para evitar path traversal
    $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '', $id);
    return getDataDir() . '/proj_' . $safe . '.json';
}

function indexPath(): string {
    return getDataDir() . '/index.json';
}

function loadIndex(): array {
    $path = indexPath();
    if (!file_exists($path)) return [];
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : [];
}

function saveIndex(array $index): void {
    file_put_contents(indexPath(), json_encode($index, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// ── Input ─────────────────────────────────────────────────────────────────────
$raw  = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'JSON inválido.']);
    exit;
}
$action = $body['action'] ?? 'generate';

// ── SALVAR PROJETO ────────────────────────────────────────────────────────────
if ($action === 'save_project') {
    $titulo     = mb_substr(trim($body['titulo'] ?? 'Sem título'), 0, 255);
    $roteiro    = $body['roteiro'] ?? '';
    $resultados = $body['resultados'] ?? [];
    $pid        = trim($body['project_id'] ?? '');

    $now = date('d/m/Y H:i');

    if ($pid && file_exists(projectPath($pid))) {
        // Atualiza projeto existente
        $project = json_decode(file_get_contents(projectPath($pid)), true) ?? [];
        $project['titulo']      = $titulo;
        $project['roteiro']     = $roteiro;
        $project['resultados']  = $resultados;
        $project['atualizado_em'] = $now;
    } else {
        // Novo projeto
        $pid = generateId();
        $project = [
            'id'           => $pid,
            'titulo'       => $titulo,
            'roteiro'      => $roteiro,
            'resultados'   => $resultados,
            'criado_em'    => $now,
            'atualizado_em'=> $now,
        ];
    }

    file_put_contents(projectPath($pid), json_encode($project, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

    // Atualiza índice (lista leve sem o conteúdo completo)
    $index = loadIndex();
    $index[$pid] = ['id' => $pid, 'titulo' => $titulo, 'criado_em' => $project['criado_em'], 'atualizado_em' => $now];
    saveIndex($index);

    echo json_encode(['ok' => true, 'project_id' => $pid]);
    exit;
}

// ── LISTAR PROJETOS ───────────────────────────────────────────────────────────
if ($action === 'list_projects') {
    $index = loadIndex();
    // Ordena por data de atualização (mais recente primeiro)
    $list = array_values($index);
    usort($list, fn($a, $b) => strcmp($b['atualizado_em'] ?? '', $a['atualizado_em'] ?? ''));
    $list = array_slice($list, 0, 30);
    echo json_encode(['projects' => $list]);
    exit;
}

// ── CARREGAR PROJETO ──────────────────────────────────────────────────────────
if ($action === 'load_project') {
    $pid = trim($body['project_id'] ?? '');
    $path = projectPath($pid);
    if (!$pid || !file_exists($path)) {
        echo json_encode(['error' => 'Projeto não encontrado.']);
        exit;
    }
    $project = json_decode(file_get_contents($path), true);
    if (!$project) {
        echo json_encode(['error' => 'Erro ao ler o projeto.']);
        exit;
    }
    echo json_encode(['project' => $project]);
    exit;
}

// ── DELETAR PROJETO ───────────────────────────────────────────────────────────
if ($action === 'delete_project') {
    $pid  = trim($body['project_id'] ?? '');
    $path = projectPath($pid);
    if ($pid && file_exists($path)) {
        unlink($path);
    }
    $index = loadIndex();
    unset($index[$pid]);
    saveIndex($index);
    echo json_encode(['ok' => true]);
    exit;
}

// ── GERAÇÃO VIA ANTHROPIC ─────────────────────────────────────────────────────
$prompt = trim($body['prompt'] ?? '');
if (empty($prompt)) {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt vazio.']);
    exit;
}

$payload = json_encode([
    'model'      => 'claude-opus-4-5',
    'max_tokens' => 4096,
    'messages'   => [
        ['role' => 'user', 'content' => $prompt]
    ]
], JSON_UNESCAPED_UNICODE);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_TIMEOUT        => 120,
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: '         . ANTHROPIC_API_KEY,
        'anthropic-version: 2023-06-01',
    ],
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro de conexão: ' . $curlErr]);
    exit;
}

$data = json_decode($response, true);
if ($httpCode !== 200) {
    $msg = is_array($data) ? ($data['error']['message'] ?? 'Erro desconhecido da API') : 'Erro da API';
    http_response_code($httpCode >= 400 ? $httpCode : 500);
    echo json_encode(['error' => $msg]);
    exit;
}

$result = '';
foreach ($data['content'] ?? [] as $block) {
    if (isset($block['type']) && $block['type'] === 'text') {
        $result .= $block['text'];
    }
}

if (empty(trim($result))) {
    http_response_code(500);
    echo json_encode(['error' => 'A IA retornou resposta vazia.']);
    exit;
}

echo json_encode(['result' => $result], JSON_UNESCAPED_UNICODE);
