<?php
/**
 * TATI STUDIO — INSTALLER v3.0.0
 * Sem banco de dados. Configura API key, senha e pasta de dados.
 */

$configFile = __DIR__ . '/includes/config.php';
$dataDir    = __DIR__ . '/data';

$step    = 1;
$success = false;
$errors  = [];

// ── POST: gravar configuração ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $apiKey   = trim($_POST['api_key']   ?? '');
    $password = trim($_POST['password']  ?? '');
    $confirm  = trim($_POST['confirm']   ?? '');

    if (empty($apiKey) || !str_starts_with($apiKey, 'sk-ant-')) {
        $errors[] = 'API Key inválida. Deve começar com <code>sk-ant-</code>';
    }
    if (strlen($password) < 6) {
        $errors[] = 'A senha deve ter pelo menos 6 caracteres.';
    }
    if ($password !== $confirm) {
        $errors[] = 'As senhas não coincidem.';
    }

    if (empty($errors)) {
        // Cria diretório de dados
        if (!is_dir($dataDir)) {
            if (!mkdir($dataDir, 0755, true)) {
                $errors[] = 'Não foi possível criar o diretório <code>data/</code>. Verifique as permissões do servidor.';
            } else {
                file_put_contents($dataDir . '/.htaccess', "Deny from all\n");
            }
        }
    }

    if (empty($errors)) {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $subpath      = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');

        $config = <<<PHP
<?php
// Gerado automaticamente pelo installer.php em <?= date('d/m/Y H:i') ?>

define('ANTHROPIC_API_KEY', '{$apiKey}');
define('APP_PASSWORD',      '{$passwordHash}');
define('APP_VERSION',       '3.0.0');
define('INSTALLED',         true);

// Diretório onde os projetos JSON são salvos
define('DATA_DIR', __DIR__ . '/../data');
PHP;

        if (!is_dir(__DIR__ . '/includes')) {
            mkdir(__DIR__ . '/includes', 0755, true);
        }

        if (file_put_contents($configFile, $config) === false) {
            $errors[] = 'Não foi possível gravar <code>includes/config.php</code>. Verifique as permissões da pasta.';
        } else {
            $success = true;
        }
    }

    if (!empty($errors)) $step = 1;
}

// Verifica se já está instalado
$alreadyInstalled = file_exists($configFile);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tati Studio — Instalador</title>
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: system-ui, sans-serif;
    background: #08080f;
    color: #eeeef8;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
}
.card {
    background: #111119;
    border: 1px solid #23233a;
    border-radius: 14px;
    padding: 2.5rem;
    width: 100%;
    max-width: 480px;
}
h1 { font-size: 1.5rem; margin-bottom: .3rem; }
h1 span { color: #ff6b35; }
.sub { color: #72728a; font-size: .9rem; margin-bottom: 2rem; }
.badge {
    display: inline-block;
    background: rgba(45,212,191,.1);
    color: #2dd4bf;
    border: 1px solid rgba(45,212,191,.25);
    border-radius: 6px;
    padding: .15rem .55rem;
    font-size: .72rem;
    font-weight: 600;
    letter-spacing: .04em;
    margin-bottom: 1.5rem;
}
label { display: block; font-size: .78rem; font-weight: 500; color: #72728a; text-transform: uppercase; letter-spacing: .06em; margin-bottom: .4rem; }
input[type=text], input[type=password] {
    width: 100%;
    background: rgba(255,255,255,.04);
    border: 1px solid #23233a;
    border-radius: 8px;
    color: #eeeef8;
    font-size: .95rem;
    padding: .8rem 1rem;
    outline: none;
    margin-bottom: 1.2rem;
    transition: border-color .2s;
}
input:focus { border-color: #ff6b35; }
.btn {
    width: 100%;
    background: #ff6b35;
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: .9rem;
    font-size: 1rem;
    font-weight: 700;
    cursor: pointer;
    transition: opacity .2s;
}
.btn:hover { opacity: .85; }
.error  { background: rgba(248,113,113,.08); border: 1px solid rgba(248,113,113,.25); border-radius: 8px; padding: .8rem 1rem; color: #f87171; font-size: .88rem; margin-bottom: 1.2rem; }
.error + .error { margin-top: -.6rem; }
.success { background: rgba(45,212,191,.08); border: 1px solid rgba(45,212,191,.25); border-radius: 8px; padding: 1.2rem 1rem; color: #2dd4bf; font-size: .9rem; margin-bottom: 1.2rem; line-height: 1.7; }
a.go { display: block; text-align: center; margin-top: 1rem; background: #2dd4bf; color: #08080f; border-radius: 8px; padding: .9rem; font-weight: 700; text-decoration: none; }
a.go:hover { opacity: .85; }
.info { background: rgba(255,183,3,.06); border: 1px solid rgba(255,183,3,.2); border-radius: 8px; padding: .9rem 1rem; color: #ffb703; font-size: .84rem; margin-bottom: 1.5rem; line-height: 1.6; }
hr { border: none; border-top: 1px solid #23233a; margin: 1.5rem 0; }
</style>
</head>
<body>
<div class="card">
    <h1>Tati <span>Studio</span></h1>
    <p class="sub">Instalador v3.0.0</p>
    <span class="badge">✦ Sem banco de dados</span>

    <?php if ($success): ?>
        <div class="success">
            ✅ <strong>Instalação concluída!</strong><br>
            Arquivo <code>includes/config.php</code> criado com sucesso.<br>
            Pasta <code>data/</code> pronta para armazenar projetos.
        </div>
        <a class="go" href="index.php">Acessar o Studio →</a>

    <?php else: ?>

        <?php if ($alreadyInstalled): ?>
        <div class="info">
            ⚠️ O sistema já está instalado. Preencher o formulário abaixo <strong>sobrescreve</strong> a configuração atual (útil para trocar a senha ou a chave de API).
        </div>
        <?php endif; ?>

        <?php foreach ($errors as $e): ?>
        <div class="error">⚠ <?= $e ?></div>
        <?php endforeach; ?>

        <form method="POST">
            <div>
                <label>Anthropic API Key</label>
                <input type="text" name="api_key" placeholder="sk-ant-api03-..." autocomplete="off" value="<?= htmlspecialchars($_POST['api_key'] ?? '') ?>">
            </div>
            <div>
                <label>Senha de acesso</label>
                <input type="password" name="password" placeholder="Mínimo 6 caracteres" autocomplete="new-password">
            </div>
            <div>
                <label>Confirmar senha</label>
                <input type="password" name="confirm" placeholder="Repita a senha" autocomplete="new-password">
            </div>
            <hr>
            <div class="info" style="margin-bottom:1.2rem">
                📁 Projetos salvos em <code>data/*.json</code> — sem MySQL, sem configuração extra.
            </div>
            <button class="btn" type="submit">Instalar agora</button>
        </form>

    <?php endif; ?>
</div>
</body>
</html>
