<?php
// Este arquivo é gerado automaticamente pelo installer.php
// NÃO edite manualmente. Use o instalador.

define('ANTHROPIC_API_KEY', '');
define('APP_PASSWORD', '');          // hash bcrypt gerado pelo installer
define('APP_VERSION',  '3.0.0');
define('INSTALLED',    false);

// Diretório onde os projetos são salvos (arquivos JSON)
define('DATA_DIR', __DIR__ . '/../data');
