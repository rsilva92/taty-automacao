# Tati Studio v3.0.0 — Sem banco de dados

Sistema multiagente de produção YouTube Faceless para o canal **Tati Indicando**.

## ✦ O que mudou na v3

- ❌ MySQL removido completamente
- ✅ Projetos salvos como arquivos JSON em `data/`
- ✅ Instalação muito mais simples: só API key + senha
- ✅ Funciona em qualquer hospedagem PHP 8.0+ (compartilhada, VPS, etc.)

## Estrutura de arquivos

```
tati-studio/
├── index.php           ← Interface principal
├── installer.php       ← Instalador (rode uma vez)
├── api/
│   └── agent.php       ← API interna (chama Anthropic + gerencia projetos)
├── includes/
│   ├── config.php      ← Gerado pelo installer (não edite)
│   └── config.example.php
└── data/               ← Criado automaticamente
    ├── .htaccess       ← Bloqueia acesso direto via web
    ├── index.json      ← Índice de projetos
    └── proj_*.json     ← Um arquivo por projeto
```

## Instalação

1. Faça upload de todos os arquivos para o seu servidor.
2. Acesse `https://seu-site.com/installer.php`.
3. Preencha sua **Anthropic API Key** e defina uma senha.
4. Clique em **Instalar agora**.
5. Pronto — acesse `index.php`.

## Requisitos

- PHP 8.0 ou superior
- Extensão `curl` habilitada
- Permissão de escrita na pasta `data/` (o installer cria automaticamente)

## Backup dos projetos

Basta copiar a pasta `data/` — cada projeto é um arquivo `.json` legível.

## Segurança

- A pasta `data/` é bloqueada por `.htaccess` (acesso direto via browser negado).
- A senha é armazenada como hash bcrypt.
- A API key fica somente em `includes/config.php` (fora do HTML público).
