<?php
/**
 * TATI INDICANDO STUDIO — INSTALADOR v1.3.0
 * Fluxo: Etapa 1 (checagem) → Etapa 2 (configuração) → Etapa 3 (sucesso)
 */
define('INSTALLER_VERSION', '1.3.0');

// Inicia sessão para manter o estado entre os POSTs
session_start();

$errors  = [];
$current = isset($_SESSION['install_step']) ? (int)$_SESSION['install_step'] : 1;

// ── Funções ───────────────────────────────────────────────────────────────────

function checkPHP(): bool {
    return version_compare(PHP_VERSION, '7.4.0', '>=');
}

function checkWritable(): bool {
    return is_writable(__DIR__);
}

function checkExtensions(): array {
    // curl, json, mbstring bloqueiam o instalador.
    // pdo_mysql é verificado separadamente — aviso, não bloqueio.
    $required = ['curl', 'json', 'mbstring'];
    $missing  = [];
    foreach ($required as $ext) {
        if (!extension_loaded($ext)) $missing[] = $ext;
    }
    return $missing;
}

function checkPdoMysql(): bool {
    return extension_loaded('pdo') && extension_loaded('pdo_mysql');
}

function envReady(): bool {
    return checkPHP() && checkWritable() && empty(checkExtensions());
}

function createConfig(array $data): bool {
    $dir = __DIR__ . '/includes';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);

    $php  = "<?php\n";
    $php .= "// Gerado pelo instalador em " . date('d/m/Y H:i:s') . "\n\n";
    foreach ($data as $key => $val) {
        $php .= "define('" . $key . "', '" . addslashes($val) . "');\n";
    }
    $php .= "\ndefine('INSTALLED', true);\n";

    return file_put_contents(__DIR__ . '/includes/config.php', $php) !== false;
}

function createHtaccess(string $subpath): void {
    $base = $subpath ? '/' . trim($subpath, '/') : '';
    $ht   = "Options -Indexes\n\n";
    $ht  .= "<IfModule mod_rewrite.c>\n";
    $ht  .= "  RewriteEngine On\n";
    $ht  .= "  RewriteBase " . ($base ?: '/') . "\n\n";
    $ht  .= "  RewriteCond %{REQUEST_FILENAME} !-f\n";
    $ht  .= "  RewriteCond %{REQUEST_FILENAME} !-d\n";
    $ht  .= "  RewriteRule ^api/ - [L]\n\n";
    $ht  .= "  RewriteRule ^(.*)$ index.php?route=\$1 [QSA,L]\n";
    $ht  .= "</IfModule>\n\n";
    $ht  .= "<FilesMatch \"(config\\.php|\\.env|installer\\.php|fix-config\\.php|db-check\\.php)$\">\n";
    $ht  .= "  Order Allow,Deny\n";
    $ht  .= "  Deny from all\n";
    $ht  .= "</FilesMatch>\n\n";
    $ht  .= "AddDefaultCharset UTF-8\n";
    file_put_contents(__DIR__ . '/.htaccess', $ht);
}

function connectDB(string $host, string $port, string $name, string $user, string $pass): PDO {
    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4;connect_timeout=8";
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

function createTables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS projetos (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        titulo        VARCHAR(255) NOT NULL DEFAULT 'Sem titulo',
        roteiro       LONGTEXT,
        resultados    JSON,
        criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_criado (criado_em)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS sessoes_log (
        id        INT AUTO_INCREMENT PRIMARY KEY,
        ip        VARCHAR(45),
        acao      VARCHAR(100),
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// ── Processar POST ────────────────────────────────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    // ETAPA 1 → 2: passa pela checagem
    if ($action === 'go_config') {
        if (!envReady()) {
            $errors[] = 'Corrija os problemas de ambiente antes de continuar.';
        } else {
            $_SESSION['install_step'] = 2;
            $current = 2;
        }
    }

    // ETAPA 2 → 3: processa configuração e instala
    if ($action === 'install') {

        $apiKey  = trim($_POST['api_key']  ?? '');
        $pass    = trim($_POST['password'] ?? '');
        $subpath = preg_replace('/[^A-Za-z0-9_-]/', '', trim($_POST['subpath'] ?? ''));
        $dbHost  = trim($_POST['db_host']  ?? '127.0.0.1') ?: '127.0.0.1';
        $dbPort  = trim($_POST['db_port']  ?? '3306')      ?: '3306';
        $dbName  = trim($_POST['db_name']  ?? '');
        $dbUser  = trim($_POST['db_user']  ?? '');
        $dbPass  = $_POST['db_pass'] ?? '';

        // ── Validações básicas ────────────────────────────────────────────────
        if (strlen($apiKey) < 20)  $errors[] = 'Chave de API muito curta. Verifique e cole novamente.';
        if (strlen($pass)   < 6)   $errors[] = 'Senha deve ter ao menos 6 caracteres.';
        if (empty($dbName))        $errors[] = 'Nome do banco é obrigatório.';
        if (empty($dbUser))        $errors[] = 'Usuário do banco é obrigatório.';

        // ── Testa conexão com banco ───────────────────────────────────────────
        if (empty($errors)) {
            try {
                $pdo = connectDB($dbHost, $dbPort, $dbName, $dbUser, $dbPass);
                createTables($pdo);
                unset($pdo);
            } catch (Exception $e) {
                $raw = $e->getMessage();
                if     (str_contains($raw, 'Access denied'))                              $errors[] = 'Banco: usuário ou senha incorretos. Verifique e tente novamente.';
                elseif (str_contains($raw, 'Unknown database'))                           $errors[] = "O banco \"{$dbName}\" não existe. Crie-o no painel da hospedagem primeiro.";
                elseif (str_contains($raw, "Can't connect") || str_contains($raw, 'refused')) $errors[] = 'Não foi possível conectar ao MySQL. Verifique se o serviço está rodando.';
                elseif (str_contains($raw, 'No such file'))                               $errors[] = 'Socket do MySQL não encontrado. Tente usar 127.0.0.1 como host.';
                else                                                                      $errors[] = 'Erro de banco: ' . $raw;
            }
        }

        // ── Salva config e cria estrutura ─────────────────────────────────────
        if (empty($errors)) {
            // Cria pastas
            foreach (['includes','api','cache','logs','assets/css','assets/js'] as $dir) {
                @mkdir(__DIR__ . '/' . $dir, 0755, true);
            }

            $saved = createConfig([
                'ANTHROPIC_API_KEY' => $apiKey,
                'APP_PASSWORD'      => password_hash($pass, PASSWORD_DEFAULT),
                'APP_SUBPATH'       => $subpath,
                'APP_VERSION'       => INSTALLER_VERSION,
                'DB_HOST'           => $dbHost,
                'DB_PORT'           => $dbPort,
                'DB_NAME'           => $dbName,
                'DB_USER'           => $dbUser,
                'DB_PASS'           => $dbPass,
            ]);

            if (!$saved) {
                $errors[] = 'Não foi possível salvar o config.php. Verifique se a pasta tem permissão de escrita (chmod 755 includes/).';
            } else {
                createHtaccess($subpath);
                $_SESSION['install_step'] = 3;
                $_SESSION['install_done'] = true;
                $current = 3;
            }
        }

        // Se houve erro, volta para etapa 2 mantendo os campos preenchidos
        if (!empty($errors)) {
            $_SESSION['install_step'] = 2;
            $current = 2;
            // Guarda campos na sessão para repopular o formulário
            $_SESSION['form'] = compact('dbHost','dbPort','dbName','dbUser','subpath');
        }
    }

    // Reiniciar instalação
    if ($action === 'restart') {
        session_destroy();
        header('Location: installer.php');
        exit;
    }
}

// Popula campos do formulário (da sessão ou defaults)
$form = $_SESSION['form'] ?? [];
$fHost    = htmlspecialchars($form['dbHost']  ?? '127.0.0.1');
$fPort    = htmlspecialchars($form['dbPort']  ?? '3306');
$fName    = htmlspecialchars($form['dbName']  ?? 'tati_studio');
$fUser    = htmlspecialchars($form['dbUser']  ?? '');
$fSubpath = htmlspecialchars($form['subpath'] ?? '');

// Monta URL de acesso ao Studio
$studioUrl = '/index.php';
if ($current === 3 && file_exists(__DIR__ . '/includes/config.php')) {
    // Evita re-include se já carregado
    if (!defined('APP_SUBPATH')) @include __DIR__ . '/includes/config.php';
    $sp = defined('APP_SUBPATH') ? APP_SUBPATH : '';
    $studioUrl = ($sp ? '/' . ltrim($sp, '/') : '') . '/index.php';
    $studioUrl = '/' . ltrim($studioUrl, '/');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Instalador — Tati Studio v<?= INSTALLER_VERSION ?></title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg:     #07070d;
  --card:   #111118;
  --border: #222233;
  --accent: #ff6b35;
  --accent2:#ffb703;
  --text:   #eeeef5;
  --muted:  #6b6b88;
  --ok:     #2dd4bf;
  --err:    #f87171;
  --r:      12px;
}
body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background-image:
    radial-gradient(ellipse at 20% 20%, rgba(255,107,53,.08) 0%, transparent 60%),
    radial-gradient(ellipse at 80% 80%, rgba(255,183,3,.06) 0%, transparent 60%);
}
.wrap { width: 100%; max-width: 600px; }
.logo {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1.5rem;
  letter-spacing: -.03em;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: .6rem;
}
.logo span { color: var(--accent); }
.logo .tag {
  font-family: 'DM Sans', sans-serif;
  font-size: .65rem;
  font-weight: 500;
  background: var(--border);
  color: var(--muted);
  padding: .2rem .5rem;
  border-radius: 4px;
  letter-spacing: .05em;
  text-transform: uppercase;
}
/* Steps */
.steps { display: flex; gap: .5rem; margin-bottom: 2rem; }
.step-dot { height: 4px; border-radius: 2px; background: var(--border); flex: 1; transition: background .3s; }
.step-dot.active { background: var(--accent); }
.step-dot.done   { background: var(--ok); }
/* Card */
.card { background: var(--card); border: 1px solid var(--border); border-radius: var(--r); padding: 2.5rem; }
h1 { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1.3rem; letter-spacing: -.02em; margin-bottom: .35rem; }
.sub { color: var(--muted); font-size: .88rem; margin-bottom: 1.75rem; line-height: 1.6; }
/* Checklist */
.checklist { display: flex; flex-direction: column; gap: .6rem; margin-bottom: 1.75rem; }
.check-item {
  display: flex; align-items: center; gap: .75rem;
  padding: .85rem 1rem;
  background: rgba(255,255,255,.02);
  border: 1px solid var(--border);
  border-radius: 8px;
  font-size: .88rem;
}
.check-item .ic { font-size: 1rem; width: 22px; text-align: center; flex-shrink: 0; }
.check-item .lbl { flex: 1; }
.badge { font-size: .72rem; font-weight: 600; padding: .2rem .55rem; border-radius: 20px; }
.badge-ok   { background: rgba(45,212,191,.12);  color: var(--ok); }
.badge-err  { background: rgba(248,113,113,.12); color: var(--err); }
.badge-warn { background: rgba(255,183,3,.12);   color: var(--accent2); }
/* Form */
.field { margin-bottom: 1.25rem; }
.field:last-of-type { margin-bottom: 0; }
label { display: block; font-size: .75rem; font-weight: 500; color: var(--muted); text-transform: uppercase; letter-spacing: .06em; margin-bottom: .4rem; }
input[type=text], input[type=password] {
  width: 100%;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: .92rem;
  padding: .78rem 1rem;
  outline: none;
  transition: border-color .2s;
}
input:focus { border-color: var(--accent); }
.hint { font-size: .78rem; color: var(--muted); margin-top: .35rem; line-height: 1.5; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
hr { border: none; border-top: 1px solid var(--border); margin: 1.5rem 0; }
/* Radio cards */
.radio-group { display: flex; gap: .75rem; margin-bottom: .75rem; }
.radio-card {
  flex: 1; border: 1px solid var(--border); border-radius: 8px;
  padding: 1rem; cursor: pointer; text-align: center;
  transition: border-color .2s, background .2s;
}
.radio-card:has(input:checked) { border-color: var(--accent); background: rgba(255,107,53,.07); }
.radio-card input { display: none; }
.rc-icon  { font-size: 1.4rem; margin-bottom: .35rem; }
.rc-title { font-size: .82rem; font-weight: 600; }
.rc-desc  { font-size: .72rem; color: var(--muted); margin-top: .15rem; }
#subpath-wrap { display: none; }
/* Errors */
.err-box {
  background: rgba(248,113,113,.07);
  border: 1px solid rgba(248,113,113,.3);
  border-radius: 8px;
  padding: 1rem 1.2rem;
  margin-bottom: 1.5rem;
}
.err-box p { color: var(--err); font-size: .86rem; line-height: 1.75; }
/* Buttons */
.btn {
  display: inline-flex; align-items: center; justify-content: center; gap: .5rem;
  background: var(--accent); color: #fff; border: none; border-radius: 8px;
  padding: .88rem 1.8rem;
  font-family: 'Syne', sans-serif; font-weight: 700; font-size: .95rem;
  cursor: pointer; transition: opacity .2s, transform .15s;
  letter-spacing: -.01em; white-space: nowrap;
}
.btn:hover { opacity: .85; transform: translateY(-1px); }
.btn:disabled { opacity: .4; cursor: not-allowed; transform: none; }
.btn-full { width: 100%; }
.btn-ghost {
  background: transparent;
  border: 1px solid var(--border);
  color: var(--muted);
  font-family: 'DM Sans', sans-serif;
  font-weight: 400;
  font-size: .85rem;
}
.btn-ghost:hover { border-color: var(--accent); color: var(--accent); }
/* Success */
.success-icon { font-size: 3.5rem; text-align: center; margin-bottom: 1rem; }
.file-list { margin: 1.5rem 0; }
.file-list h3 { font-size: .75rem; text-transform: uppercase; letter-spacing: .07em; color: var(--muted); margin-bottom: .6rem; }
.file-item {
  font-size: .82rem; font-family: monospace;
  color: var(--ok); background: rgba(45,212,191,.05);
  border-radius: 6px; padding: .5rem .75rem; margin-bottom: .35rem;
}
.next-link {
  display: block; text-align: center; margin-top: 1.75rem; padding: 1rem;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  border-radius: 8px; color: #fff; text-decoration: none;
  font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1rem;
  transition: opacity .2s;
}
.next-link:hover { opacity: .88; }
.warn-box {
  background: rgba(255,183,3,.07); border: 1px solid rgba(255,183,3,.3);
  border-radius: 8px; padding: .75rem 1rem; margin-top: 1rem;
  color: var(--accent2); font-size: .82rem; line-height: 1.6;
}
</style>
</head>
<body>
<div class="wrap">

  <div class="logo">
    Tati <span>Studio</span>
    <span class="tag">Instalador v<?= INSTALLER_VERSION ?></span>
  </div>

  <!-- Indicador de etapas -->
  <div class="steps">
    <div class="step-dot <?= $current >= 1 ? ($current > 1 ? 'done' : 'active') : '' ?>"></div>
    <div class="step-dot <?= $current >= 2 ? ($current > 2 ? 'done' : 'active') : '' ?>"></div>
    <div class="step-dot <?= $current >= 3 ? 'done active' : '' ?>"></div>
  </div>

  <div class="card">

  <?php if ($current === 3): ?>
  <!-- ══════════════ ETAPA 3: SUCESSO ══════════════ -->
  <div class="success-icon">🎬</div>
  <h1 style="text-align:center">Instalação concluída!</h1>
  <p class="sub" style="text-align:center">Tudo configurado e pronto para uso.</p>
  <div class="file-list">
    <h3>Arquivos criados</h3>
    <div class="file-item">✓ includes/config.php</div>
    <div class="file-item">✓ .htaccess</div>
    <div class="file-item">✓ Tabelas MySQL: projetos, sessoes_log</div>
    <div class="file-item">✓ Pastas: cache/, logs/, assets/</div>
  </div>
  <a href="<?= htmlspecialchars($studioUrl) ?>" class="next-link">
    Acessar o Studio →
  </a>
  <div class="warn-box">
    ⚠️ Por segurança, <strong>delete o arquivo installer.php</strong> do servidor após acessar o sistema.
  </div>

  <?php elseif ($current === 2): ?>
  <!-- ══════════════ ETAPA 2: CONFIGURAÇÃO ══════════════ -->
  <h1>Configuração do sistema</h1>
  <p class="sub">Preencha os dados abaixo para instalar o Tati Studio.</p>

  <?php if (!empty($errors)): ?>
  <div class="err-box">
    <?php foreach ($errors as $e): ?>
    <p>⚠ <?= htmlspecialchars($e) ?></p>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <form method="POST" id="install-form">
    <input type="hidden" name="action" value="install">

    <!-- API Anthropic -->
    <div class="field">
      <label>Chave de API — Anthropic</label>
      <input type="password" name="api_key" placeholder="sk-ant-api03-..." autocomplete="off" required>
      <p class="hint">Obtenha em <strong>console.anthropic.com</strong> → API Keys</p>
    </div>

    <!-- Senha -->
    <div class="field">
      <label>Senha de acesso ao Studio</label>
      <input type="password" name="password" placeholder="Mínimo 6 caracteres" autocomplete="new-password" required>
      <p class="hint">Você usará essa senha para entrar no sistema.</p>
    </div>

    <!-- Local de instalação -->
    <div class="field">
      <label>Local de instalação</label>
      <div class="radio-group">
        <label class="radio-card">
          <input type="radio" name="install_type" value="root" checked onchange="toggleSubpath(this)">
          <div class="rc-icon">🏠</div>
          <div class="rc-title">Raiz</div>
          <div class="rc-desc">seusite.com/</div>
        </label>
        <label class="radio-card">
          <input type="radio" name="install_type" value="sub" onchange="toggleSubpath(this)">
          <div class="rc-icon">📁</div>
          <div class="rc-title">Subpasta</div>
          <div class="rc-desc">seusite.com/studio</div>
        </label>
      </div>
      <div id="subpath-wrap">
        <label>Nome da subpasta</label>
        <input type="text" name="subpath" id="subpath-input"
               placeholder="ex: studio"
               value="<?= $fSubpath ?>">
        <p class="hint">Apenas letras, números e hífen. Sem barras.</p>
      </div>
    </div>

    <hr>

    <!-- Banco de dados -->
    <p style="font-family:'Syne',sans-serif;font-weight:700;font-size:.95rem;margin-bottom:1rem">🗄️ Banco de dados (MySQL)</p>

    <div class="grid2">
      <div class="field">
        <label>Host</label>
        <input type="text" name="db_host" value="<?= $fHost ?>" required>
      </div>
      <div class="field">
        <label>Porta</label>
        <input type="text" name="db_port" value="<?= $fPort ?>" required>
      </div>
    </div>

    <div class="field">
      <label>Nome do banco</label>
      <input type="text" name="db_name" value="<?= $fName ?>" required>
      <p class="hint">O banco já deve existir. Crie-o no painel da hospedagem antes de instalar.</p>
    </div>

    <div class="grid2">
      <div class="field">
        <label>Usuário MySQL</label>
        <input type="text" name="db_user" value="<?= $fUser ?>" placeholder="ex: tati_user" required autocomplete="off">
      </div>
      <div class="field">
        <label>Senha MySQL</label>
        <input type="password" name="db_pass" placeholder="Senha do usuário" autocomplete="new-password">
      </div>
    </div>
    <p class="hint" style="margin-top:-.5rem;margin-bottom:1.5rem">
      💡 As tabelas serão criadas automaticamente após conectar.
    </p>

    <button type="submit" class="btn btn-full" id="btn-install">
      Instalar sistema
    </button>
  </form>

  <form method="POST" style="margin-top:.75rem">
    <input type="hidden" name="action" value="restart">
    <button type="submit" class="btn btn-ghost btn-full">← Voltar ao início</button>
  </form>

  <?php else: ?>
  <!-- ══════════════ ETAPA 1: CHECAGEM ══════════════ -->
  <h1>Verificação do ambiente</h1>
  <p class="sub">Checando se o servidor atende os requisitos antes de instalar.</p>

  <?php
  $phpOk      = checkPHP();
  $writableOk = checkWritable();
  $missingExt = checkExtensions();
  $allOk      = $phpOk && $writableOk && empty($missingExt);
  ?>

  <?php $pdoOk = checkPdoMysql(); ?>

  <div class="checklist">
    <div class="check-item">
      <span class="ic">🐘</span>
      <span class="lbl">PHP <?= PHP_VERSION ?></span>
      <span class="badge <?= $phpOk ? 'badge-ok' : 'badge-err' ?>">
        <?= $phpOk ? 'OK' : 'Requer 7.4+' ?>
      </span>
    </div>
    <div class="check-item">
      <span class="ic">📝</span>
      <span class="lbl">Permissão de escrita na pasta</span>
      <span class="badge <?= $writableOk ? 'badge-ok' : 'badge-err' ?>">
        <?= $writableOk ? 'OK' : 'Sem permissão' ?>
      </span>
    </div>
    <div class="check-item">
      <span class="ic">🔌</span>
      <span class="lbl">Extensões base: curl, json, mbstring</span>
      <?php if (empty($missingExt)): ?>
        <span class="badge badge-ok">OK</span>
      <?php else: ?>
        <span class="badge badge-err">Faltam: <?= implode(', ', $missingExt) ?></span>
      <?php endif; ?>
    </div>
    <div class="check-item">
      <span class="ic">🗄️</span>
      <span class="lbl">Extensão pdo_mysql (banco de dados)</span>
      <span class="badge <?= $pdoOk ? 'badge-ok' : 'badge-warn' ?>">
        <?= $pdoOk ? 'OK' : 'Não encontrada — instale antes de usar o banco' ?>
      </span>
    </div>
    <div class="check-item">
      <span class="ic">🌐</span>
      <span class="lbl">mod_rewrite (URLs limpas)</span>
      <span class="badge badge-warn">Verificado após instalação</span>
    </div>
  </div>

  <?php if (!$writableOk): ?>
  <div class="err-box">
    <p>⚠ A pasta não tem permissão de escrita. Execute no servidor:<br>
    <code style="background:rgba(0,0,0,.3);padding:.1rem .4rem;border-radius:4px">
      chmod 755 <?= htmlspecialchars(__DIR__) ?> && chown www-data:www-data <?= htmlspecialchars(__DIR__) ?>
    </code></p>
  </div>
  <?php endif; ?>

  <?php if (!empty($missingExt)): ?>
  <div class="err-box">
    <p>⚠ Extensões bloqueantes faltando: <strong><?= implode(', ', $missingExt) ?></strong><br>
    Execute: <code style="background:rgba(0,0,0,.3);padding:.1rem .4rem;border-radius:4px">
      sudo apt-get install <?= implode(' ', array_map(fn($e) => "php8.2-{$e}", $missingExt)) ?> && sudo systemctl restart apache2
    </code></p>
  </div>
  <?php endif; ?>

  <?php if (!$pdoOk): ?>
  <div class="warn-box" style="margin-bottom:1rem">
    ⚠️ <strong>pdo_mysql não encontrada.</strong> Você pode continuar a instalação, mas o salvamento de projetos não vai funcionar até instalar a extensão.<br><br>
    Para instalar: <code style="background:rgba(0,0,0,.2);padding:.1rem .4rem;border-radius:4px">sudo apt-get install php8.2-mysql -y && sudo systemctl restart apache2</code><br>
    Em hospedagem compartilhada: ative <strong>pdo_mysql</strong> no painel PHP do seu provedor.
  </div>
  <?php endif; ?>

  <form method="POST">
    <input type="hidden" name="action" value="go_config">
    <button type="submit" class="btn btn-full" <?= !$allOk ? 'disabled' : '' ?>>
      <?= $allOk ? 'Continuar → Configurar' : 'Corrija os erros acima para continuar' ?>
    </button>
  </form>

  <?php endif; ?>

  </div><!-- .card -->
</div><!-- .wrap -->

<script>
function toggleSubpath(radio) {
  const wrap  = document.getElementById('subpath-wrap');
  const input = document.getElementById('subpath-input');
  const isSub = radio.value === 'sub';
  wrap.style.display = isSub ? 'block' : 'none';
  isSub ? input.setAttribute('required','required') : input.removeAttribute('required');
  if (!isSub) input.value = '';
}

// Feedback visual no botão de instalar
document.getElementById('install-form')?.addEventListener('submit', function() {
  const btn = document.getElementById('btn-install');
  btn.disabled = true;
  btn.textContent = '⏳ Instalando...';
});
</script>
</body>
</html>
