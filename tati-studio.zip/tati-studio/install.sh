#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  TATI INDICANDO STUDIO — INSTALADOR AUTOMÁTICO
#  Compatível com: Ubuntu 20.04 / 22.04 / 24.04 | Debian 11 / 12
#  Instala: Apache2, PHP 8.2, MySQL 8, extensões e configura o sistema.
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail
IFS=$'\n\t'

# ── Cores ─────────────────────────────────────────────────────────────────────
RED='\033[0;31m';  GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m';  BOLD='\033[1m'; RESET='\033[0m'

# ── Funções de output ─────────────────────────────────────────────────────────
info()    { echo -e "${CYAN}${BOLD}[INFO]${RESET}  $*"; }
success() { echo -e "${GREEN}${BOLD}[ OK ]${RESET}  $*"; }
warn()    { echo -e "${YELLOW}${BOLD}[WARN]${RESET}  $*"; }
error()   { echo -e "${RED}${BOLD}[ERRO]${RESET}  $*"; }
step()    { echo -e "\n${BLUE}${BOLD}━━━  $*  ━━━${RESET}"; }
die()     { error "$*"; exit 1; }

# ── Banner ────────────────────────────────────────────────────────────────────
banner() {
cat <<'EOF'

  ████████╗ █████╗ ████████╗██╗    ███████╗████████╗██╗   ██╗██████╗ ██╗ ██████╗
     ██╔══╝██╔══██╗╚══██╔══╝██║    ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║██╔═══██╗
     ██║   ███████║   ██║   ██║    ███████╗   ██║   ██║   ██║██║  ██║██║██║   ██║
     ██║   ██╔══██║   ██║   ██║    ╚════██║   ██║   ██║   ██║██║  ██║██║██║   ██║
     ██║   ██║  ██║   ██║   ██║    ███████║   ██║   ╚██████╔╝██████╔╝██║╚██████╔╝
     ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚═╝    ╚══════╝   ╚═╝    ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝

  TATI INDICANDO — Studio de Produção YouTube Faceless
  Instalador Automático v1.0.0  |  Apache + PHP 8.2 + MySQL 8

EOF
}

# ── Verificações iniciais ─────────────────────────────────────────────────────
check_root() {
    [[ $EUID -eq 0 ]] || die "Execute como root: sudo bash install.sh"
}

check_os() {
    if [[ ! -f /etc/os-release ]]; then
        die "Sistema operacional não suportado."
    fi
    source /etc/os-release
    case "$ID" in
        ubuntu|debian) success "Sistema: $PRETTY_NAME" ;;
        *) die "Suportado apenas Ubuntu e Debian. Detectado: $PRETTY_NAME" ;;
    esac
}

check_internet() {
    info "Verificando conexão com a internet..."
    curl -s --max-time 5 https://google.com > /dev/null 2>&1 \
        || die "Sem acesso à internet. Verifique a conexão."
    success "Internet OK"
}

# ── Coleta de configurações ───────────────────────────────────────────────────
collect_config() {
    step "CONFIGURAÇÃO DO SISTEMA"
    echo ""

    # Tipo de instalação
    echo -e "${BOLD}Onde deseja instalar o sistema?${RESET}"
    echo "  1) IP/Domínio raiz  (ex: seusite.com/)"
    echo "  2) Subpasta         (ex: seusite.com/studio)"
    echo ""
    read -rp "  Escolha [1/2]: " INSTALL_TYPE
    INSTALL_TYPE="${INSTALL_TYPE:-1}"

    SUBPATH=""
    WEBROOT="/var/www/html"

    if [[ "$INSTALL_TYPE" == "2" ]]; then
        read -rp "  Nome da subpasta (ex: studio): " SUBPATH
        SUBPATH="${SUBPATH// /}"
        SUBPATH="${SUBPATH//\//}"
        if [[ -z "$SUBPATH" ]]; then die "Nome da subpasta inválido."; fi
        WEBROOT="/var/www/html/${SUBPATH}"
    fi

    echo ""
    # Chave de API
    echo -e "${BOLD}Chave de API da Anthropic${RESET}"
    echo -e "  ${CYAN}Obtenha em: https://console.anthropic.com → API Keys${RESET}"
    while true; do
        read -rsp "  Cole sua API key: " API_KEY
        echo ""
        if [[ ${#API_KEY} -lt 20 ]]; then
            warn "Chave parece inválida. Tente novamente."
        else
            break
        fi
    done

    echo ""
    # Senha do sistema
    echo -e "${BOLD}Crie uma senha de acesso ao Studio${RESET}"
    while true; do
        read -rsp "  Senha (mínimo 6 caracteres): " APP_PASS
        echo ""
        if [[ ${#APP_PASS} -lt 6 ]]; then
            warn "Senha muito curta. Tente novamente."
        else
            read -rsp "  Confirme a senha: " APP_PASS2
            echo ""
            if [[ "$APP_PASS" != "$APP_PASS2" ]]; then
                warn "Senhas não coincidem. Tente novamente."
            else
                break
            fi
        fi
    done

    echo ""
    # Banco de dados
    echo -e "${BOLD}Configuração do MySQL${RESET}"
    read -rp "  Senha root do MySQL (deixe vazio para gerar automaticamente): " MYSQL_ROOT_PASS
    if [[ -z "$MYSQL_ROOT_PASS" ]]; then
        MYSQL_ROOT_PASS=$(openssl rand -base64 20 | tr -dc 'A-Za-z0-9' | head -c 20)
        warn "Senha root gerada: ${BOLD}${MYSQL_ROOT_PASS}${RESET}  ← Guarde isto!"
    fi

    DB_NAME="tati_studio"
    DB_USER="tati_user"
    DB_PASS=$(openssl rand -base64 20 | tr -dc 'A-Za-z0-9' | head -c 20)

    echo ""
    # Domínio (para VirtualHost)
    echo -e "${BOLD}Domínio ou IP do servidor${RESET}"
    read -rp "  Ex: seusite.com ou 123.123.123.123 (Enter = localhost): " SERVER_NAME
    SERVER_NAME="${SERVER_NAME:-localhost}"

    # Resumo
    echo ""
    echo -e "${BOLD}━━━ RESUMO DA INSTALAÇÃO ━━━${RESET}"
    echo -e "  Instalação:  ${CYAN}${WEBROOT}${RESET}"
    echo -e "  Domínio:     ${CYAN}${SERVER_NAME}${RESET}"
    echo -e "  Banco:       ${CYAN}${DB_NAME}${RESET}"
    echo -e "  Usuário DB:  ${CYAN}${DB_USER}${RESET}"
    echo ""
    read -rp "  Confirmar e iniciar instalação? [s/N]: " CONFIRM
    [[ "${CONFIRM,,}" == "s" ]] || die "Instalação cancelada pelo usuário."
}

# ── Instalação de pacotes ─────────────────────────────────────────────────────
install_packages() {
    step "INSTALANDO PACOTES DO SISTEMA"

    info "Atualizando lista de pacotes..."
    apt-get update -qq

    info "Instalando dependências base..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        software-properties-common \
        curl \
        wget \
        unzip \
        gnupg2 \
        lsb-release \
        ca-certificates \
        apt-transport-https \
        > /dev/null 2>&1
    success "Dependências base instaladas"

    # PHP 8.2 via ondrej/php (Ubuntu) ou sury (Debian)
    source /etc/os-release
    if [[ "$ID" == "ubuntu" ]]; then
        if ! apt-cache show php8.2 > /dev/null 2>&1; then
            info "Adicionando repositório PHP (ondrej/php)..."
            add-apt-repository -y ppa:ondrej/php > /dev/null 2>&1
            apt-get update -qq
        fi
    else
        if ! apt-cache show php8.2 > /dev/null 2>&1; then
            info "Adicionando repositório PHP (sury.org)..."
            curl -sSL https://packages.sury.org/php/README.txt | bash - > /dev/null 2>&1
            apt-get update -qq
        fi
    fi

    info "Instalando Apache2..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq apache2 > /dev/null 2>&1
    success "Apache2 instalado"

    info "Instalando PHP 8.2 e extensões..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        php8.2 \
        php8.2-cli \
        php8.2-fpm \
        php8.2-mysql \
        php8.2-curl \
        php8.2-json \
        php8.2-mbstring \
        php8.2-openssl \
        php8.2-xml \
        php8.2-zip \
        php8.2-intl \
        php8.2-gd \
        libapache2-mod-php8.2 \
        > /dev/null 2>&1
    success "PHP 8.2 instalado com todas as extensões"

    info "Instalando MySQL 8..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        mysql-server \
        mysql-client \
        > /dev/null 2>&1
    success "MySQL instalado"
}

# ── Configuração do MySQL ─────────────────────────────────────────────────────
configure_mysql() {
    step "CONFIGURANDO MYSQL"

    info "Iniciando serviço MySQL..."
    systemctl enable mysql > /dev/null 2>&1
    systemctl start mysql

    info "Configurando senha root..."
    mysql -u root 2>/dev/null <<SQL || true
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_ROOT_PASS}';
FLUSH PRIVILEGES;
SQL

    info "Criando banco de dados e usuário..."
    mysql -u root -p"${MYSQL_ROOT_PASS}" <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
SQL

    info "Criando tabelas do sistema..."
    mysql -u "${DB_USER}" -p"${DB_PASS}" "${DB_NAME}" <<SQL
CREATE TABLE IF NOT EXISTS projetos (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    titulo       VARCHAR(255) NOT NULL DEFAULT 'Sem título',
    roteiro      LONGTEXT,
    resultados   JSON,
    criado_em    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_criado (criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessoes_log (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    ip         VARCHAR(45),
    acao       VARCHAR(100),
    criado_em  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL

    success "MySQL configurado — banco '${DB_NAME}' criado"
}

# ── Configuração do Apache ────────────────────────────────────────────────────
configure_apache() {
    step "CONFIGURANDO APACHE"

    info "Habilitando módulos..."
    a2enmod rewrite > /dev/null 2>&1
    a2enmod php8.2  > /dev/null 2>&1
    a2enmod headers > /dev/null 2>&1
    a2enmod deflate > /dev/null 2>&1
    a2enmod expires > /dev/null 2>&1

    VHOST_PATH="/etc/apache2/sites-available/tati-studio.conf"
    DOC_ROOT="$( [[ "$INSTALL_TYPE" == "2" ]] && echo "/var/www/html" || echo "/var/www/html" )"

    info "Criando VirtualHost..."
    cat > "$VHOST_PATH" <<VHOST
<VirtualHost *:80>
    ServerName ${SERVER_NAME}
    DocumentRoot ${DOC_ROOT}

    <Directory "${DOC_ROOT}">
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Segurança
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"

    # Compressão
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json
    </IfModule>

    # Cache de assets
    <IfModule mod_expires.c>
        ExpiresActive On
        ExpiresByType text/css "access plus 1 month"
        ExpiresByType application/javascript "access plus 1 month"
    </IfModule>

    # Bloqueia acesso a arquivos sensíveis
    <FilesMatch "(config\.php|installer\.php|\.env|\.git)">
        Order Allow,Deny
        Deny from all
    </FilesMatch>

    ErrorLog \${APACHE_LOG_DIR}/tati-studio-error.log
    CustomLog \${APACHE_LOG_DIR}/tati-studio-access.log combined
</VirtualHost>
VHOST

    a2ensite tati-studio.conf  > /dev/null 2>&1
    a2dissite 000-default.conf > /dev/null 2>&1 || true

    info "Ajustando configurações PHP..."
    PHP_INI="/etc/php/8.2/apache2/php.ini"
    if [[ -f "$PHP_INI" ]]; then
        sed -i 's/^upload_max_filesize.*/upload_max_filesize = 32M/'  "$PHP_INI"
        sed -i 's/^post_max_size.*/post_max_size = 32M/'              "$PHP_INI"
        sed -i 's/^max_execution_time.*/max_execution_time = 120/'    "$PHP_INI"
        sed -i 's/^memory_limit.*/memory_limit = 256M/'               "$PHP_INI"
        sed -i 's/^;date.timezone.*/date.timezone = America\/Sao_Paulo/' "$PHP_INI"
        sed -i 's/^display_errors.*/display_errors = Off/'            "$PHP_INI"
    fi

    systemctl enable apache2 > /dev/null 2>&1
    systemctl restart apache2
    success "Apache configurado e reiniciado"
}

# ── Deploy dos arquivos ───────────────────────────────────────────────────────
deploy_files() {
    step "COPIANDO ARQUIVOS DO SISTEMA"

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

    # Cria diretório de destino
    mkdir -p "$WEBROOT"

    info "Copiando arquivos para ${WEBROOT}..."

    # Copia apenas os arquivos do sistema (exclui o próprio installer)
    rsync -a --exclude='install.sh' --exclude='README.md' --exclude='*.zip' \
        "${SCRIPT_DIR}/" "${WEBROOT}/" 2>/dev/null || \
    cp -r "${SCRIPT_DIR}/." "${WEBROOT}/"

    # Cria pastas necessárias
    mkdir -p "${WEBROOT}/includes"
    mkdir -p "${WEBROOT}/cache"
    mkdir -p "${WEBROOT}/api"
    mkdir -p "${WEBROOT}/assets/css"
    mkdir -p "${WEBROOT}/assets/js"
    mkdir -p "${WEBROOT}/logs"

    # Gera o hash seguro da senha
    APP_PASS_HASH=$(php8.2 -r "echo password_hash('${APP_PASS}', PASSWORD_DEFAULT);")

    info "Gerando arquivo de configuração..."
    cat > "${WEBROOT}/includes/config.php" <<PHP
<?php
// Gerado automaticamente pelo install.sh — Não edite manualmente.
// Data: $(date '+%d/%m/%Y %H:%M:%S')

define('ANTHROPIC_API_KEY', '${API_KEY}');
define('APP_PASSWORD',      '${APP_PASS_HASH}');
define('APP_SUBPATH',       '${SUBPATH}');
define('APP_VERSION',       '1.0.0');

// Banco de dados
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', '${DB_NAME}');
define('DB_USER', '${DB_USER}');
define('DB_PASS', '${DB_PASS}');

define('INSTALLED', true);
PHP

    info "Gerando .htaccess..."
    BASE_PATH="${SUBPATH:+/$SUBPATH}"
    cat > "${WEBROOT}/.htaccess" <<HTACCESS
Options -Indexes

<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase ${BASE_PATH:-/}
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule ^(.*)$ index.php?route=\$1 [QSA,L]
</IfModule>

# Bloqueia arquivos sensíveis
<FilesMatch "(config\.php|install\.sh|\.env)$">
  Order Allow,Deny
  Deny from all
</FilesMatch>

# Charset
AddDefaultCharset UTF-8
HTACCESS

    info "Ajustando permissões..."
    chown -R www-data:www-data "$WEBROOT"
    find "$WEBROOT" -type d -exec chmod 755 {} \;
    find "$WEBROOT" -type f -exec chmod 644 {} \;
    chmod 600 "${WEBROOT}/includes/config.php"
    chmod 755 "${WEBROOT}/cache"
    chmod 755 "${WEBROOT}/logs"

    # Remove o installer.php do servidor por segurança
    rm -f "${WEBROOT}/installer.php"
    rm -f "${WEBROOT}/install.sh"

    success "Arquivos copiados e permissões configuradas"
}

# ── Firewall ──────────────────────────────────────────────────────────────────
configure_firewall() {
    step "CONFIGURANDO FIREWALL"
    if command -v ufw &> /dev/null; then
        ufw allow 22/tcp  > /dev/null 2>&1  || true
        ufw allow 80/tcp  > /dev/null 2>&1  || true
        ufw allow 443/tcp > /dev/null 2>&1  || true
        ufw --force enable > /dev/null 2>&1 || true
        success "UFW: portas 22, 80 e 443 liberadas"
    else
        warn "UFW não encontrado — configure o firewall manualmente"
    fi
}

# ── Verificação final ─────────────────────────────────────────────────────────
final_check() {
    step "VERIFICAÇÃO FINAL"

    # Apache
    systemctl is-active --quiet apache2 && success "Apache2: rodando" || warn "Apache2: verifique com 'systemctl status apache2'"
    # MySQL
    systemctl is-active --quiet mysql   && success "MySQL: rodando"   || warn "MySQL: verifique com 'systemctl status mysql'"
    # PHP
    php8.2 -v > /dev/null 2>&1 && success "PHP 8.2: disponível" || warn "PHP: verifique a instalação"
    # Extensões críticas
    for ext in curl json mbstring openssl pdo pdo_mysql; do
        php8.2 -m 2>/dev/null | grep -q "^${ext}$" \
            && success "Extensão PHP: ${ext}" \
            || warn "Extensão PHP não encontrada: ${ext}"
    done
    # Arquivo de config
    [[ -f "${WEBROOT}/includes/config.php" ]] \
        && success "Config gerado: ${WEBROOT}/includes/config.php" \
        || warn "Arquivo de config não encontrado"
}

# ── Resumo final ──────────────────────────────────────────────────────────────
print_summary() {
    URL_BASE="http://${SERVER_NAME}"
    [[ -n "$SUBPATH" ]] && APP_URL="${URL_BASE}/${SUBPATH}" || APP_URL="${URL_BASE}"

    echo ""
    echo -e "${GREEN}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║        🎬  TATI STUDIO INSTALADO COM SUCESSO!  🎬         ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
    echo -e "  ${BOLD}🌐 Acesse o sistema:${RESET}    ${CYAN}${APP_URL}${RESET}"
    echo -e "  ${BOLD}🔐 Senha de acesso:${RESET}     ${YELLOW}(a que você definiu)${RESET}"
    echo ""
    echo -e "  ${BOLD}━━━ Banco de dados ━━━${RESET}"
    echo -e "  Host:     127.0.0.1"
    echo -e "  Banco:    ${DB_NAME}"
    echo -e "  Usuário:  ${DB_USER}"
    echo -e "  Senha DB: ${YELLOW}${DB_PASS}${RESET}"
    echo ""
    echo -e "  ${BOLD}━━━ Senha root MySQL ━━━${RESET}"
    echo -e "  ${RED}${MYSQL_ROOT_PASS}${RESET}  ← Guarde em local seguro!"
    echo ""
    echo -e "  ${BOLD}━━━ Logs ━━━${RESET}"
    echo -e "  Apache:  /var/log/apache2/tati-studio-error.log"
    echo -e "  App:     ${WEBROOT}/logs/"
    echo ""
    echo -e "  ${BOLD}━━━ Próximos passos ━━━${RESET}"
    echo -e "  1. Acesse ${CYAN}${APP_URL}${RESET} e faça login"
    echo -e "  2. Cole um roteiro e clique em ${BOLD}▶ Gerar tudo${RESET}"
    echo -e "  3. Para SSL/HTTPS: ${CYAN}certbot --apache -d ${SERVER_NAME}${RESET}"
    echo ""

    # Salva resumo em arquivo
    cat > /root/tati-studio-credenciais.txt <<CREDS
TATI STUDIO — CREDENCIAIS DE INSTALAÇÃO
Gerado em: $(date '+%d/%m/%Y %H:%M:%S')

URL do sistema:  ${APP_URL}
Senha de acesso: (a que você definiu durante a instalação)

BANCO DE DADOS:
  Host:     127.0.0.1
  Banco:    ${DB_NAME}
  Usuário:  ${DB_USER}
  Senha DB: ${DB_PASS}

MYSQL ROOT:
  Senha: ${MYSQL_ROOT_PASS}

Arquivos do sistema: ${WEBROOT}
CREDS
    chmod 600 /root/tati-studio-credenciais.txt
    success "Credenciais salvas em: /root/tati-studio-credenciais.txt"
}

# ═══════════════════════════════════════════════════════════════════════════════
#  EXECUÇÃO PRINCIPAL
# ═══════════════════════════════════════════════════════════════════════════════
main() {
    clear
    banner
    sleep 1

    check_root
    check_os
    check_internet
    collect_config
    install_packages
    configure_mysql
    configure_apache
    deploy_files
    configure_firewall
    final_check
    print_summary
}

main "$@"
