#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  TATI INDICANDO STUDIO — INSTALADOR AUTOMÁTICO v1.1.0
#  Compatível com: Ubuntu 20.04 / 22.04 / 24.04 | Debian 11 / 12
#  Instala: Apache2, PHP 8.2, MySQL 8, extensões e configura o sistema.
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail
IFS=$'\n\t'

# ── Cores ─────────────────────────────────────────────────────────────────────
RED='\033[0;31m';  GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m';  BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}${BOLD}[INFO]${RESET}  $*"; }
success() { echo -e "${GREEN}${BOLD}[ OK ]${RESET}  $*"; }
warn()    { echo -e "${YELLOW}${BOLD}[WARN]${RESET}  $*"; }
error()   { echo -e "${RED}${BOLD}[ERRO]${RESET}  $*"; }
step()    { echo -e "\n${BLUE}${BOLD}━━━  $*  ━━━${RESET}"; }
die()     { error "$*"; exit 1; }

banner() {
cat <<'EOF'

  ████████╗ █████╗ ████████╗██╗    ███████╗████████╗██╗   ██╗██████╗ ██╗ ██████╗
     ██╔══╝██╔══██╗╚══██╔══╝██║    ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║██╔═══██╗
     ██║   ███████║   ██║   ██║    ███████╗   ██║   ██║   ██║██║  ██║██║██║   ██║
     ██║   ██╔══██║   ██║   ██║    ╚════██║   ██║   ██║   ██║██║  ██║██║██║   ██║
     ██║   ██║  ██║   ██║   ██║    ███████║   ██║   ╚██████╔╝██████╔╝██║╚██████╔╝
     ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚═╝    ╚══════╝   ╚═╝    ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝

  TATI INDICANDO — Studio de Produção YouTube Faceless
  Instalador Automático v1.1.0  |  Apache + PHP 8.2 + MySQL 8

EOF
}

# ── FIX #4: Gerador de senha seguro sem depender de pipe ─────────────────────
gen_pass() {
    # Usa /dev/urandom diretamente — mais confiável que openssl|tr em pipes
    local len="${1:-20}"
    tr -dc 'A-Za-z0-9' < /dev/urandom | head -c "$len"
    echo ""   # garante newline
}

# ── Verificações iniciais ─────────────────────────────────────────────────────
check_root() {
    [[ $EUID -eq 0 ]] || die "Execute como root: sudo bash install.sh"
}

check_os() {
    [[ -f /etc/os-release ]] || die "Sistema operacional não suportado."
    # shellcheck source=/dev/null
    source /etc/os-release
    case "$ID" in
        ubuntu|debian) success "Sistema: $PRETTY_NAME" ;;
        *) die "Suportado apenas Ubuntu e Debian. Detectado: $PRETTY_NAME" ;;
    esac
}

check_internet() {
    info "Verificando conexão com a internet..."
    curl -s --max-time 8 -o /dev/null -w "%{http_code}" https://google.com | grep -q "200\|301\|302" \
        || die "Sem acesso à internet. Verifique a conexão."
    success "Internet OK"
}

# ── Coleta de configurações ───────────────────────────────────────────────────
collect_config() {
    step "CONFIGURAÇÃO DO SISTEMA"
    echo ""

    echo -e "${BOLD}Onde deseja instalar o sistema?${RESET}"
    echo "  1) IP/Domínio raiz  (ex: seusite.com/)"
    echo "  2) Subpasta         (ex: seusite.com/studio)"
    echo ""
    read -rp "  Escolha [1/2]: " INSTALL_TYPE
    INSTALL_TYPE="${INSTALL_TYPE:-1}"

    SUBPATH=""
    WEBROOT="/var/www/html"

    if [[ "$INSTALL_TYPE" == "2" ]]; then
        read -rp "  Nome da subpasta (ex: studio): " SUBPATH
        # Remove espaços, barras e caracteres especiais
        SUBPATH=$(echo "$SUBPATH" | tr -dc 'A-Za-z0-9_-')
        [[ -z "$SUBPATH" ]] && die "Nome da subpasta inválido."
        WEBROOT="/var/www/html/${SUBPATH}"
    fi

    echo ""
    echo -e "${BOLD}Chave de API da Anthropic${RESET}"
    echo -e "  ${CYAN}Obtenha em: https://console.anthropic.com → API Keys${RESET}"
    while true; do
        read -rsp "  Cole sua API key: " API_KEY
        echo ""
        [[ ${#API_KEY} -ge 20 ]] && break
        warn "Chave parece inválida (muito curta). Tente novamente."
    done

    echo ""
    echo -e "${BOLD}Crie uma senha de acesso ao Studio${RESET}"
    while true; do
        read -rsp "  Senha (mínimo 8 caracteres): " APP_PASS
        echo ""
        if [[ ${#APP_PASS} -lt 8 ]]; then
            warn "Senha muito curta. Mínimo 8 caracteres."
            continue
        fi
        read -rsp "  Confirme a senha: " APP_PASS2
        echo ""
        [[ "$APP_PASS" == "$APP_PASS2" ]] && break
        warn "Senhas não coincidem. Tente novamente."
    done

    echo ""
    echo -e "${BOLD}Configuração do MySQL${RESET}"
    read -rp "  Senha root do MySQL (Enter para gerar automaticamente): " MYSQL_ROOT_PASS
    if [[ -z "$MYSQL_ROOT_PASS" ]]; then
        MYSQL_ROOT_PASS=$(gen_pass 24)
        warn "Senha root gerada: ${BOLD}${MYSQL_ROOT_PASS}${RESET}  ← Guarde!"
    fi

    DB_NAME="tati_studio"
    DB_USER="tati_user"
    DB_PASS=$(gen_pass 24)

    echo ""
    echo -e "${BOLD}Domínio ou IP do servidor${RESET}"
    read -rp "  Ex: seusite.com ou 123.123.123.123 (Enter = localhost): " SERVER_NAME
    SERVER_NAME="${SERVER_NAME:-localhost}"

    echo ""
    echo -e "${BOLD}━━━ RESUMO DA INSTALAÇÃO ━━━${RESET}"
    echo -e "  Pasta:       ${CYAN}${WEBROOT}${RESET}"
    echo -e "  Domínio:     ${CYAN}${SERVER_NAME}${RESET}"
    echo -e "  Banco:       ${CYAN}${DB_NAME}${RESET}"
    echo -e "  Usuário DB:  ${CYAN}${DB_USER}${RESET}"
    echo ""
    read -rp "  Confirmar e iniciar instalação? [s/N]: " CONFIRM
    [[ "${CONFIRM,,}" == "s" ]] || die "Instalação cancelada."
}

# ── Instalação de pacotes ─────────────────────────────────────────────────────
install_packages() {
    step "INSTALANDO PACOTES DO SISTEMA"

    info "Atualizando lista de pacotes..."
    apt-get update -qq

    info "Instalando dependências base..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        software-properties-common curl wget unzip rsync \
        gnupg2 lsb-release ca-certificates apt-transport-https \
        > /dev/null 2>&1
    success "Dependências base instaladas"

    # ── FIX #2: Repositório PHP correto por distro ────────────────────────────
    # shellcheck source=/dev/null
    source /etc/os-release

    if [[ "$ID" == "ubuntu" ]]; then
        if ! apt-cache show php8.2 > /dev/null 2>&1; then
            info "Adicionando repositório PHP (ondrej/php)..."
            add-apt-repository -y ppa:ondrej/php > /dev/null 2>&1
            apt-get update -qq
        fi
    else
        # Debian: usa método moderno com signed-by (sem apt-key deprecated)
        if ! apt-cache show php8.2 > /dev/null 2>&1; then
            info "Adicionando repositório PHP (sury.org — método moderno)..."
            curl -sSo /usr/share/keyrings/deb.sury.org-php.gpg \
                https://packages.sury.org/php/apt.gpg
            echo "deb [signed-by=/usr/share/keyrings/deb.sury.org-php.gpg] \
https://packages.sury.org/php/ $(lsb_release -sc) main" \
                > /etc/apt/sources.list.d/php-sury.list
            apt-get update -qq
        fi
    fi

    info "Instalando Apache2..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq apache2 > /dev/null 2>&1
    success "Apache2 instalado"

    # ── FIX #1: Remove php8.2-json e php8.2-openssl (built-in desde PHP 8.0) ─
    info "Instalando PHP 8.2 e extensões..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        php8.2 \
        php8.2-cli \
        php8.2-fpm \
        php8.2-mysql \
        php8.2-curl \
        php8.2-mbstring \
        php8.2-xml \
        php8.2-zip \
        php8.2-intl \
        php8.2-gd \
        libapache2-mod-php8.2 \
        > /dev/null 2>&1
    success "PHP 8.2 instalado"

    info "Instalando MySQL 8..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        mysql-server mysql-client > /dev/null 2>&1
    success "MySQL instalado"
}

# ── Configuração do MySQL ─────────────────────────────────────────────────────
configure_mysql() {
    step "CONFIGURANDO MYSQL"

    info "Iniciando serviço MySQL..."
    systemctl enable mysql  > /dev/null 2>&1
    systemctl start  mysql

    # ── FIX #5: Ubuntu 22+/24 usa auth_socket por padrão para root ───────────
    # Detecta se MySQL usa auth_socket e faz a troca corretamente
    info "Configurando autenticação root..."
    mysql -u root --connect-expired-password 2>/dev/null <<SQL || true
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_ROOT_PASS}';
FLUSH PRIVILEGES;
SQL

    # Testa se funcionou; se não, tenta via socket sem senha (Ubuntu 22+)
    if ! mysql -u root -p"${MYSQL_ROOT_PASS}" -e "SELECT 1" > /dev/null 2>&1; then
        warn "Ajustando método de autenticação root (Ubuntu 22+/24)..."
        mysql -u root 2>/dev/null <<SQL
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_ROOT_PASS}';
FLUSH PRIVILEGES;
SQL
    fi

    info "Criando banco de dados e usuário..."
    mysql -u root -p"${MYSQL_ROOT_PASS}" <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

DROP USER IF EXISTS '${DB_USER}'@'localhost';
CREATE USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
SQL

    info "Criando tabelas do sistema..."
    mysql -u "${DB_USER}" -p"${DB_PASS}" "${DB_NAME}" <<SQL
CREATE TABLE IF NOT EXISTS projetos (
    id            INT          AUTO_INCREMENT PRIMARY KEY,
    titulo        VARCHAR(255) NOT NULL DEFAULT 'Sem título',
    roteiro       LONGTEXT,
    resultados    JSON,
    criado_em     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_criado (criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessoes_log (
    id        INT         AUTO_INCREMENT PRIMARY KEY,
    ip        VARCHAR(45),
    acao      VARCHAR(100),
    criado_em TIMESTAMP   DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL

    success "MySQL configurado — banco '${DB_NAME}' criado"
}

# ── Configuração do Apache ────────────────────────────────────────────────────
configure_apache() {
    step "CONFIGURANDO APACHE"

    info "Habilitando módulos..."
    a2enmod rewrite headers deflate expires > /dev/null 2>&1
    a2enmod php8.2                          > /dev/null 2>&1

    VHOST_PATH="/etc/apache2/sites-available/tati-studio.conf"
    DOC_ROOT="/var/www/html"

    info "Criando VirtualHost..."
    cat > "$VHOST_PATH" <<VHOST
<VirtualHost *:80>
    ServerName ${SERVER_NAME}
    DocumentRoot ${DOC_ROOT}

    <Directory "${DOC_ROOT}">
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Segurança
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"

    # Compressão
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json
    </IfModule>

    # Cache de assets estáticos
    <IfModule mod_expires.c>
        ExpiresActive On
        ExpiresByType text/css                  "access plus 1 month"
        ExpiresByType application/javascript    "access plus 1 month"
    </IfModule>

    # Bloqueia acesso direto a arquivos sensíveis
    <FilesMatch "(config\.php|install\.sh|installer\.php|\.env|\.git)">
        Order Allow,Deny
        Deny from all
    </FilesMatch>

    ErrorLog  \${APACHE_LOG_DIR}/tati-studio-error.log
    CustomLog \${APACHE_LOG_DIR}/tati-studio-access.log combined
</VirtualHost>
VHOST

    a2ensite  tati-studio.conf > /dev/null 2>&1
    a2dissite 000-default.conf > /dev/null 2>&1 || true

    info "Ajustando php.ini..."
    PHP_INI="/etc/php/8.2/apache2/php.ini"
    if [[ -f "$PHP_INI" ]]; then
        sed -i 's/^upload_max_filesize.*/upload_max_filesize = 32M/'     "$PHP_INI"
        sed -i 's/^post_max_size.*/post_max_size = 32M/'                 "$PHP_INI"
        sed -i 's/^max_execution_time.*/max_execution_time = 120/'       "$PHP_INI"
        sed -i 's/^memory_limit.*/memory_limit = 256M/'                  "$PHP_INI"
        sed -i 's/^;date\.timezone.*/date.timezone = America\/Sao_Paulo/' "$PHP_INI"
        sed -i 's/^display_errors.*/display_errors = Off/'               "$PHP_INI"
        sed -i 's/^expose_php.*/expose_php = Off/'                       "$PHP_INI"
    fi

    systemctl enable apache2 > /dev/null 2>&1
    systemctl restart apache2
    success "Apache configurado e reiniciado"
}

# ── Deploy dos arquivos ───────────────────────────────────────────────────────
deploy_files() {
    step "COPIANDO ARQUIVOS DO SISTEMA"

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    mkdir -p "$WEBROOT"

    info "Copiando arquivos para ${WEBROOT}..."

    # ── FIX #3: rsync com fallback explícito, sem depender do set -e ─────────
    if command -v rsync &> /dev/null; then
        rsync -a \
            --exclude='install.sh' \
            --exclude='README.md'  \
            --exclude='*.zip'      \
            "${SCRIPT_DIR}/" "${WEBROOT}/"
    else
        cp -rf "${SCRIPT_DIR}/." "${WEBROOT}/"
        rm -f "${WEBROOT}/install.sh" "${WEBROOT}/README.md"
    fi

    # Garante estrutura de pastas
    mkdir -p "${WEBROOT}/includes" \
             "${WEBROOT}/cache"    \
             "${WEBROOT}/api"      \
             "${WEBROOT}/assets/css" \
             "${WEBROOT}/assets/js"  \
             "${WEBROOT}/logs"

    # Gera hash da senha
    APP_PASS_HASH=$(php8.2 -r "echo password_hash('${APP_PASS}', PASSWORD_DEFAULT);")

    info "Gerando arquivo de configuração..."
    cat > "${WEBROOT}/includes/config.php" <<PHP
<?php
// Gerado automaticamente pelo install.sh — Não edite manualmente.
// Data: $(date '+%d/%m/%Y %H:%M:%S')

define('ANTHROPIC_API_KEY', '${API_KEY}');
define('APP_PASSWORD',      '${APP_PASS_HASH}');
define('APP_SUBPATH',       '${SUBPATH}');
define('APP_VERSION',       '1.1.0');

// Banco de dados
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', '${DB_NAME}');
define('DB_USER', '${DB_USER}');
define('DB_PASS', '${DB_PASS}');

define('INSTALLED', true);
PHP

    info "Gerando .htaccess..."
    BASE_PATH="${SUBPATH:+/$SUBPATH}"
    cat > "${WEBROOT}/.htaccess" <<HTACCESS
Options -Indexes

<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase ${BASE_PATH:-/}

  # Nunca redireciona arquivos ou pastas que existem fisicamente
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d

  # Nunca redireciona chamadas à pasta api/
  RewriteRule ^api/ - [L]

  # Demais rotas vão para index.php
  RewriteRule ^(.*)$ index.php?route=\$1 [QSA,L]
</IfModule>

# Bloqueia acesso direto a arquivos sensíveis
<FilesMatch "(config\.php|install\.sh|\.env)$">
  Order Allow,Deny
  Deny from all
</FilesMatch>

AddDefaultCharset UTF-8
HTACCESS

    info "Ajustando permissões..."
    chown -R www-data:www-data "$WEBROOT"
    find "$WEBROOT" -type d -exec chmod 755 {} \;
    find "$WEBROOT" -type f -exec chmod 644 {} \;
    chmod 600 "${WEBROOT}/includes/config.php"
    chmod 755 "${WEBROOT}/cache" "${WEBROOT}/logs"

    # Remove arquivos que não devem estar no servidor
    rm -f "${WEBROOT}/installer.php"
    rm -f "${WEBROOT}/install.sh"
    rm -f "${WEBROOT}/README.md"

    success "Arquivos copiados e permissões configuradas"
}

# ── Firewall ──────────────────────────────────────────────────────────────────
configure_firewall() {
    step "CONFIGURANDO FIREWALL"
    if command -v ufw &> /dev/null; then
        ufw allow 22/tcp  > /dev/null 2>&1 || true
        ufw allow 80/tcp  > /dev/null 2>&1 || true
        ufw allow 443/tcp > /dev/null 2>&1 || true
        ufw --force enable > /dev/null 2>&1 || true
        success "UFW: portas 22, 80 e 443 liberadas"
    else
        warn "UFW não encontrado — configure o firewall manualmente"
    fi
}

# ── Verificação final ─────────────────────────────────────────────────────────
final_check() {
    step "VERIFICAÇÃO FINAL"

    systemctl is-active --quiet apache2 \
        && success "Apache2: rodando" \
        || warn    "Apache2: verifique com 'systemctl status apache2'"

    systemctl is-active --quiet mysql \
        && success "MySQL: rodando" \
        || warn    "MySQL: verifique com 'systemctl status mysql'"

    php8.2 -v > /dev/null 2>&1 \
        && success "PHP 8.2: disponível" \
        || warn    "PHP 8.2: verifique a instalação"

    # ── FIX #1: Verifica extensões reais do PHP 8.2 ───────────────────────────
    for ext in curl mbstring pdo pdo_mysql xml zip gd; do
        php8.2 -m 2>/dev/null | grep -qi "^${ext}$" \
            && success "Extensão PHP: ${ext}" \
            || warn    "Extensão não encontrada: ${ext}"
    done

    # json e openssl são built-in — verifica de forma diferente
    php8.2 -r "json_encode([]); echo 'ok';" > /dev/null 2>&1 \
        && success "Extensão PHP: json (built-in)" \
        || warn    "json não disponível"
    php8.2 -r "openssl_random_pseudo_bytes(1); echo 'ok';" > /dev/null 2>&1 \
        && success "Extensão PHP: openssl (built-in)" \
        || warn    "openssl não disponível"

    [[ -f "${WEBROOT}/includes/config.php" ]] \
        && success "Config gerado: ${WEBROOT}/includes/config.php" \
        || warn    "Config não encontrado — verifique permissões"
}

# ── Resumo final ──────────────────────────────────────────────────────────────
print_summary() {
    URL_BASE="http://${SERVER_NAME}"
    [[ -n "$SUBPATH" ]] && APP_URL="${URL_BASE}/${SUBPATH}" || APP_URL="${URL_BASE}"

    echo ""
    echo -e "${GREEN}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║        🎬  TATI STUDIO INSTALADO COM SUCESSO!  🎬         ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
    echo -e "  ${BOLD}🌐 Acesse o sistema:${RESET}    ${CYAN}${APP_URL}${RESET}"
    echo -e "  ${BOLD}🔐 Senha de acesso:${RESET}     ${YELLOW}(a que você definiu)${RESET}"
    echo ""
    echo -e "  ${BOLD}━━━ Banco de dados ━━━${RESET}"
    echo -e "  Host:     127.0.0.1"
    echo -e "  Banco:    ${DB_NAME}"
    echo -e "  Usuário:  ${DB_USER}"
    echo -e "  Senha DB: ${YELLOW}${DB_PASS}${RESET}"
    echo ""
    echo -e "  ${BOLD}━━━ Senha root MySQL ━━━${RESET}"
    echo -e "  ${RED}${MYSQL_ROOT_PASS}${RESET}  ← Guarde em local seguro!"
    echo ""
    echo -e "  ${BOLD}━━━ Próximos passos ━━━${RESET}"
    echo -e "  1. Acesse ${CYAN}${APP_URL}${RESET} e faça login"
    echo -e "  2. Cole um roteiro e clique em ${BOLD}▶ Gerar tudo${RESET}"
    echo -e "  3. Para HTTPS: ${CYAN}certbot --apache -d ${SERVER_NAME}${RESET}"
    echo ""

    # Salva credenciais com segurança
    cat > /root/tati-studio-credenciais.txt <<CREDS
TATI STUDIO — CREDENCIAIS DE INSTALAÇÃO
Gerado em: $(date '+%d/%m/%Y %H:%M:%S')

URL:          ${APP_URL}
Senha acesso: (definida durante a instalação)

BANCO DE DADOS:
  Host:     127.0.0.1
  Banco:    ${DB_NAME}
  Usuário:  ${DB_USER}
  Senha DB: ${DB_PASS}

MYSQL ROOT:
  Senha: ${MYSQL_ROOT_PASS}

Arquivos: ${WEBROOT}
CREDS
    chmod 600 /root/tati-studio-credenciais.txt
    success "Credenciais salvas em: /root/tati-studio-credenciais.txt"
}

# ═══════════════════════════════════════════════════════════════════════════════
#  EXECUÇÃO PRINCIPAL
# ═══════════════════════════════════════════════════════════════════════════════
main() {
    clear
    banner
    sleep 1

    check_root
    check_os
    check_internet
    collect_config
    install_packages
    configure_mysql
    configure_apache
    deploy_files
    configure_firewall
    final_check
    print_summary
}

main "$@"
