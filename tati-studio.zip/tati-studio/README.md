# 🎬 Tati Indicando Studio — Guia de Instalação

## O que é este sistema?

Sistema multiagente de produção de conteúdo YouTube Faceless.
Cole um roteiro e gere automaticamente os 14 blocos de produção:
Mapa, Verdade-Base, Ângulo, Roteiro Otimizado, Storyboard, Shotlist,
Prompts de Imagem IA, Prompts de Vídeo IA, Overlays, Títulos,
Thumbnail, Descrição SEO, Aba Comunidade e Auditoria Final.

---

## Requisitos do servidor

- PHP 7.4 ou superior
- Extensões: curl, json, mbstring, openssl
- mod_rewrite habilitado (para URLs limpas)
- Permissão de escrita na pasta raiz

---

## Instalação passo a passo

### 1. Faça upload de todos os arquivos

Envie a pasta completa para o seu servidor via FTP ou painel de hospedagem.

### 2. Acesse o instalador

Abra no navegador:
- Instalação na raiz: `http://seudominio.com/installer.php`
- Instalação em subpasta: `http://seudominio.com/suapasta/installer.php`

### 3. Siga as etapas do instalador

- Etapa 1: Verificação automática do ambiente
- Etapa 2: Informe sua chave de API da Anthropic e crie uma senha
- Etapa 3: Escolha raiz ou subpasta
- Conclusão: Sistema instalado e pronto para uso

### 4. ⚠️ Importante: Delete o instalador após instalar

Por segurança, após a instalação acesse o sistema e delete
ou renomeie o arquivo `installer.php`.

---

## Estrutura de arquivos

```
/
├── installer.php       ← Execute primeiro, delete após instalar
├── index.php           ← App principal
├── api/
│   ├── agent.php       ← Agente que chama a API Anthropic
│   └── .htaccess       ← Protege a API
├── includes/
│   ├── config.php      ← Gerado pelo instalador (não edite)
│   └── config.example.php
├── cache/              ← Criado automaticamente
└── README.md
```

---

## Onde obter a chave de API

1. Acesse https://console.anthropic.com
2. Vá em "API Keys"
3. Clique em "Create Key"
4. Copie a chave (começa com `sk-ant-api03-...`)

---

## Suporte

Em caso de erro, verifique:
- Se as extensões PHP estão habilitadas no painel da hospedagem
- Se a pasta tem permissão de escrita (chmod 755)
- Se sua chave de API é válida e tem créditos
