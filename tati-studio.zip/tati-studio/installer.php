<?php
/**
 * TATI INDICANDO STUDIO — INSTALADOR AUTOMÁTICO
 * Instala o sistema na raiz ou em subpasta do seu servidor
 */

define('INSTALLER_VERSION', '1.2.0');
$step = isset($_POST['step']) ? max(0, min(3, (int)$_POST['step'])) : 0;
$errors = [];
$success = [];

// ── Funções auxiliares ──────────────────────────────────────────────────────

function checkPHP() {
    return version_compare(PHP_VERSION, '7.4.0', '>=');
}

function checkExtensions() {
    $required = ['curl', 'json', 'mbstring', 'openssl', 'pdo_mysql'];
    $missing = [];
    foreach ($required as $ext) {
        if (!extension_loaded($ext)) $missing[] = $ext;
    }
    return $missing;
}

function checkWritable($path) {
    return is_writable($path);
}

function createEnvFile($data) {
    $content = "<?php\n// Gerado automaticamente pelo instalador — não edite manualmente\n\n";
    foreach ($data as $key => $value) {
        $safe = addslashes($value);
        $content .= "define('{$key}', '{$safe}');\n";
    }
    $content .= "\ndefine('INSTALLED', true);\n";
    return file_put_contents(__DIR__ . '/includes/config.php', $content) !== false;
}

function createHtaccess($subpath) {
    $base = $subpath ? '/' . trim($subpath, '/') : '';
    $content = "Options -Indexes\n\n";
    $content .= "<IfModule mod_rewrite.c>\n";
    $content .= "  RewriteEngine On\n";
    $content .= "  RewriteBase {$base}/\n";
    $content .= "\n";
    $content .= "  # Nunca redireciona arquivos ou pastas que existem fisicamente\n";
    $content .= "  RewriteCond %{REQUEST_FILENAME} !-f\n";
    $content .= "  RewriteCond %{REQUEST_FILENAME} !-d\n";
    $content .= "\n";
    $content .= "  # Nunca redireciona chamadas à pasta api/\n";
    $content .= "  RewriteRule ^api/ - [L]\n";
    $content .= "\n";
    $content .= "  # Demais rotas vão para index.php\n";
    $content .= "  RewriteRule ^(.*)$ index.php?route=$1 [QSA,L]\n";
    $content .= "</IfModule>\n\n";
    $content .= "# Protege arquivos sensíveis\n";
    $content .= "<FilesMatch \"(config\\.php|\\.env|installer\\.php)$\">\n";
    $content .= "  Order Allow,Deny\n";
    $content .= "  Deny from all\n";
    $content .= "</FilesMatch>\n";
    return file_put_contents(__DIR__ . '/.htaccess', $content) !== false;
}

// ── Processar etapas POST ───────────────────────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($step === 2) {
        $apiKey  = trim($_POST['api_key']  ?? '');
        $password = trim($_POST['password'] ?? '');
        $subpath  = trim($_POST['subpath']  ?? '');
        $dbHost   = trim($_POST['db_host']  ?? '127.0.0.1');
        $dbPort   = trim($_POST['db_port']  ?? '3306');
        $dbName   = trim($_POST['db_name']  ?? 'tati_studio');
        $dbUser   = trim($_POST['db_user']  ?? '');
        $dbPass   = trim($_POST['db_pass']  ?? '');

        if (strlen($apiKey)   < 10) $errors[] = 'Chave de API inválida.';
        if (strlen($password)  < 6) $errors[] = 'A senha deve ter ao menos 6 caracteres.';
        if (empty($dbUser))         $errors[] = 'Usuário do banco é obrigatório.';
        if (empty($dbName))         $errors[] = 'Nome do banco é obrigatório.';

        if (empty($errors)) {
            $missingExt = checkExtensions();
            if (!empty($missingExt)) {
                $errors[] = 'Extensões PHP faltando: ' . implode(', ', $missingExt);
            }
        }

        // Testa conexão com o banco
        if (empty($errors)) {
            try {
                $testPdo = new PDO(
                    "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4;connect_timeout=5",
                    $dbUser, $dbPass,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );
                // Cria tabelas automaticamente
                $testPdo->exec("CREATE TABLE IF NOT EXISTS projetos (
                    id            INT AUTO_INCREMENT PRIMARY KEY,
                    titulo        VARCHAR(255) NOT NULL DEFAULT 'Sem titulo',
                    roteiro       LONGTEXT,
                    resultados    JSON,
                    criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_criado (criado_em)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                $testPdo->exec("CREATE TABLE IF NOT EXISTS sessoes_log (
                    id        INT AUTO_INCREMENT PRIMARY KEY,
                    ip        VARCHAR(45),
                    acao      VARCHAR(100),
                    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                unset($testPdo);
            } catch (Exception $e) {
                $msg = $e->getMessage();
                if (str_contains($msg, 'Access denied'))
                    $errors[] = 'Banco: usuário ou senha incorretos (Access denied).';
                elseif (str_contains($msg, 'Unknown database'))
                    $errors[] = "Banco '{$dbName}' nao existe. Crie-o no MySQL primeiro.";
                elseif (str_contains($msg, "Can't connect") || str_contains($msg, 'Connection refused'))
                    $errors[] = 'MySQL nao esta rodando ou porta bloqueada.';
                else
                    $errors[] = 'Erro ao conectar ao banco: ' . $msg;
            }
        }

        if (empty($errors)) {
            @mkdir(__DIR__ . '/includes',   0755, true);
            @mkdir(__DIR__ . '/api',        0755, true);
            @mkdir(__DIR__ . '/cache',      0755, true);
            @mkdir(__DIR__ . '/logs',       0755, true);
            @mkdir(__DIR__ . '/assets/css', 0755, true);
            @mkdir(__DIR__ . '/assets/js',  0755, true);

            $saved = createEnvFile([
                'ANTHROPIC_API_KEY' => $apiKey,
                'APP_PASSWORD'      => password_hash($password, PASSWORD_DEFAULT),
                'APP_SUBPATH'       => $subpath,
                'APP_VERSION'       => INSTALLER_VERSION,
                'DB_HOST'           => $dbHost,
                'DB_PORT'           => $dbPort,
                'DB_NAME'           => $dbName,
                'DB_USER'           => $dbUser,
                'DB_PASS'           => $dbPass,
            ]);

            if (!$saved) {
                $errors[] = 'Nao foi possivel gravar o config.php. Verifique as permissoes da pasta includes/.';
            } else {
                createHtaccess($subpath);
                $step = 3;
            }
        }
    }
}

// ── Checagens de ambiente ───────────────────────────────────────────────────
$phpOk    = checkPHP();
$writableOk = checkWritable(__DIR__);
$missingExt = checkExtensions();
$envReady = $phpOk && $writableOk && empty($missingExt);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Instalador — Tati Indicando Studio</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg: #07070d;
  --card: #111118;
  --border: #222233;
  --accent: #ff6b35;
  --accent2: #ffb703;
  --text: #eeeef5;
  --muted: #6b6b88;
  --ok: #2dd4bf;
  --err: #f87171;
  --r: 12px;
}

body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background-image: radial-gradient(ellipse at 20% 20%, rgba(255,107,53,.08) 0%, transparent 60%),
                    radial-gradient(ellipse at 80% 80%, rgba(255,183,3,.06) 0%, transparent 60%);
}

.wrap { width: 100%; max-width: 620px; }

.logo {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1.5rem;
  letter-spacing: -0.03em;
  margin-bottom: 2.5rem;
  display: flex;
  align-items: center;
  gap: .6rem;
}
.logo span { color: var(--accent); }
.logo .tag {
  font-family: 'DM Sans', sans-serif;
  font-size: .65rem;
  font-weight: 500;
  background: var(--border);
  color: var(--muted);
  padding: .2rem .5rem;
  border-radius: 4px;
  letter-spacing: .05em;
  text-transform: uppercase;
}

/* Steps indicator */
.steps {
  display: flex;
  gap: .5rem;
  margin-bottom: 2rem;
}
.step-dot {
  height: 4px;
  border-radius: 2px;
  background: var(--border);
  flex: 1;
  transition: background .4s;
}
.step-dot.active { background: var(--accent); }
.step-dot.done   { background: var(--ok); }

.card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 2.5rem;
}

h1 {
  font-family: 'Syne', sans-serif;
  font-weight: 700;
  font-size: 1.4rem;
  margin-bottom: .4rem;
  letter-spacing: -.02em;
}
.subtitle { color: var(--muted); font-size: .9rem; margin-bottom: 2rem; line-height: 1.6; }

/* Check list */
.checklist { display: flex; flex-direction: column; gap: .75rem; margin-bottom: 2rem; }
.check-item {
  display: flex;
  align-items: center;
  gap: .75rem;
  padding: .9rem 1rem;
  background: rgba(255,255,255,.03);
  border: 1px solid var(--border);
  border-radius: 8px;
  font-size: .9rem;
}
.check-item .icon { font-size: 1.1rem; flex-shrink: 0; }
.check-item .label { flex: 1; }
.check-item .badge {
  font-size: .75rem;
  font-weight: 500;
  padding: .2rem .6rem;
  border-radius: 20px;
}
.badge-ok  { background: rgba(45,212,191,.12); color: var(--ok); }
.badge-err { background: rgba(248,113,113,.12); color: var(--err); }
.badge-warn{ background: rgba(255,183,3,.12);   color: var(--accent2); }

/* Form */
.field { margin-bottom: 1.5rem; }
label { display: block; font-size: .8rem; font-weight: 500; color: var(--muted); text-transform: uppercase; letter-spacing: .06em; margin-bottom: .5rem; }
input[type=text], input[type=password], input[type=url] {
  width: 100%;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: .95rem;
  padding: .85rem 1rem;
  transition: border-color .2s;
  outline: none;
}
input:focus { border-color: var(--accent); }
.hint { font-size: .8rem; color: var(--muted); margin-top: .4rem; }

.radio-group { display: flex; gap: .75rem; }
.radio-card {
  flex: 1;
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 1rem;
  cursor: pointer;
  transition: border-color .2s, background .2s;
  text-align: center;
}
.radio-card input { display: none; }
.radio-card:has(input:checked) { border-color: var(--accent); background: rgba(255,107,53,.07); }
.radio-card .rc-icon { font-size: 1.5rem; margin-bottom: .4rem; }
.radio-card .rc-title { font-size: .85rem; font-weight: 500; }
.radio-card .rc-desc  { font-size: .75rem; color: var(--muted); margin-top: .2rem; }

#subpath-field { display: none; margin-top: 1rem; }

/* Errors */
.errors { background: rgba(248,113,113,.08); border: 1px solid rgba(248,113,113,.25); border-radius: 8px; padding: 1rem 1.2rem; margin-bottom: 1.5rem; }
.errors p { color: var(--err); font-size: .88rem; line-height: 1.7; }

/* Button */
.btn {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  background: var(--accent);
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: .9rem 2rem;
  font-family: 'Syne', sans-serif;
  font-weight: 700;
  font-size: .95rem;
  cursor: pointer;
  transition: opacity .2s, transform .15s;
  width: 100%;
  justify-content: center;
  letter-spacing: -.01em;
}
.btn:hover { opacity: .88; transform: translateY(-1px); }
.btn:disabled { opacity: .4; cursor: not-allowed; transform: none; }

/* Success */
.success-icon { font-size: 3.5rem; text-align: center; margin-bottom: 1rem; }
.file-list { margin-top: 1.5rem; }
.file-list h3 { font-family: 'Syne', sans-serif; font-size: .9rem; color: var(--muted); text-transform: uppercase; letter-spacing: .05em; margin-bottom: .75rem; }
.file-item {
  display: flex;
  align-items: center;
  gap: .6rem;
  padding: .6rem .8rem;
  border-radius: 6px;
  font-size: .85rem;
  font-family: 'Courier New', monospace;
  color: var(--ok);
  background: rgba(45,212,191,.05);
  margin-bottom: .4rem;
}
.next-link {
  display: block;
  text-align: center;
  margin-top: 2rem;
  padding: 1rem;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  border-radius: 8px;
  color: #fff;
  text-decoration: none;
  font-family: 'Syne', sans-serif;
  font-weight: 700;
  font-size: 1rem;
  transition: opacity .2s;
}
.next-link:hover { opacity: .88; }
</style>
</head>
<body>
<div class="wrap">
  <div class="logo">
    Tati <span>Studio</span>
    <span class="tag">Instalador v<?= INSTALLER_VERSION ?></span>
  </div>

  <!-- Step indicators -->
  <div class="steps">
    <div class="step-dot <?= $step >= 0 ? ($step > 0 ? 'done' : 'active') : '' ?>"></div>
    <div class="step-dot <?= $step >= 1 ? ($step > 1 ? 'done' : 'active') : '' ?>"></div>
    <div class="step-dot <?= $step >= 2 ? ($step > 2 ? 'done' : 'active') : '' ?>"></div>
    <div class="step-dot <?= $step >= 3 ? 'done active' : '' ?>"></div>
  </div>

  <div class="card">

  <?php if ($step === 3): ?>
    <!-- ── SUCESSO ── -->
    <div class="success-icon">🎬</div>
    <h1 style="text-align:center">Instalação concluída!</h1>
    <p class="subtitle" style="text-align:center">Tudo configurado. O sistema está pronto para uso.</p>
    <div class="file-list">
      <h3>Arquivos criados</h3>
      <div class="file-item">✓ includes/config.php</div>
      <div class="file-item">✓ .htaccess</div>
      <div class="file-item">✓ cache/ (pasta de cache)</div>
    </div>
    <?php
      $subpath = '';
      if (file_exists(__DIR__.'/includes/config.php')) {
          include __DIR__.'/includes/config.php';
          $subpath = defined('APP_SUBPATH') ? APP_SUBPATH : '';
      }
      $url = ($subpath ? '/'.$subpath : '') . '/index.php';
      $url = '/' . ltrim($url, '/'); // garante barra simples na raiz
    ?>
    <a href="<?= htmlspecialchars($url) ?>" class="next-link">
      Acessar o Studio →
    </a>
    <p class="hint" style="text-align:center;margin-top:1rem">
      ⚠️ Por segurança, delete ou renomeie o arquivo <code>installer.php</code> após acessar o sistema.
    </p>

  <?php elseif ($step === 0): ?>
    <!-- ── ETAPA 1: CHECAGEM ── -->
    <h1>Verificação do ambiente</h1>
    <p class="subtitle">Antes de instalar, verificamos se seu servidor atende aos requisitos mínimos.</p>
    <div class="checklist">
      <div class="check-item">
        <span class="icon">🐘</span>
        <span class="label">PHP <?= PHP_VERSION ?></span>
        <span class="badge <?= $phpOk ? 'badge-ok' : 'badge-err' ?>"><?= $phpOk ? 'OK' : 'Requer 7.4+' ?></span>
      </div>
      <div class="check-item">
        <span class="icon">📝</span>
        <span class="label">Permissão de escrita na pasta</span>
        <span class="badge <?= $writableOk ? 'badge-ok' : 'badge-err' ?>"><?= $writableOk ? 'OK' : 'Sem permissão' ?></span>
      </div>
      <div class="check-item">
        <span class="icon">🔌</span>
        <span class="label">Extensões: curl, json, mbstring, openssl</span>
        <?php if (empty($missingExt)): ?>
          <span class="badge badge-ok">OK</span>
        <?php else: ?>
          <span class="badge badge-err">Faltam: <?= implode(', ', $missingExt) ?></span>
        <?php endif; ?>
      </div>
      <div class="check-item">
        <span class="icon">🌐</span>
        <span class="label">mod_rewrite (URLs limpas)</span>
        <span class="badge badge-warn">Verificado após instalação</span>
      </div>
    </div>
    <?php if ($envReady): ?>
    <form method="POST">
      <input type="hidden" name="step" value="1">
      <button class="btn" type="submit">Continuar → Configurar</button>
    </form>
    <?php else: ?>
    <button class="btn" disabled>Corrija os erros para continuar</button>
    <?php endif; ?>

  <?php elseif ($step === 1): ?>
    <!-- ── ETAPA 2: CONFIGURAÇÃO ── -->
    <h1>Configuração</h1>
    <p class="subtitle">Informe sua chave de API da Anthropic e escolha onde instalar o sistema.</p>

    <?php if (!empty($errors)): ?>
    <div class="errors"><?php foreach ($errors as $e): ?><p>⚠ <?= htmlspecialchars($e) ?></p><?php endforeach; ?></div>
    <?php endif; ?>

    <form method="POST">
      <input type="hidden" name="step" value="2">

      <div class="field">
        <label>Chave de API — Anthropic</label>
        <input type="password" name="api_key" placeholder="sk-ant-api03-..." autocomplete="off" required>
        <p class="hint">Obtenha em <strong>console.anthropic.com</strong> → API Keys</p>
      </div>

      <div class="field">
        <label>Senha de acesso ao Studio</label>
        <input type="password" name="password" placeholder="Mínimo 6 caracteres" autocomplete="new-password" required>
        <p class="hint">Você usará essa senha para entrar no sistema.</p>
      </div>

      <div class="field">
        <label>Local de instalação</label>
        <div class="radio-group">
          <label class="radio-card" onclick="toggleSubpath('root')">
            <input type="radio" name="install_type" value="root" checked>
            <div class="rc-icon">🏠</div>
            <div class="rc-title">IP / Domínio raiz</div>
            <div class="rc-desc">seusite.com/</div>
          </label>
          <label class="radio-card" onclick="toggleSubpath('sub')">
            <input type="radio" name="install_type" value="sub">
            <div class="rc-icon">📁</div>
            <div class="rc-title">Subpasta</div>
            <div class="rc-desc">seusite.com/studio</div>
          </label>
        </div>
        <div id="subpath-field" style="display:none;margin-top:1rem">
          <label>Nome da subpasta</label>
          <input type="text" name="subpath" id="subpath-input" placeholder="ex: studio (sem barra)">
          <p class="hint">Use apenas letras, números e hífen. Sem espaços ou barras.</p>
        </div>
      </div>

      <hr style="border:none;border-top:1px solid var(--border);margin:1.5rem 0">

      <h3 style="font-family:'Syne',sans-serif;font-size:.95rem;margin-bottom:1rem">🗄️ Banco de dados (MySQL)</h3>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
        <div class="field">
          <label>Host</label>
          <input type="text" name="db_host" value="127.0.0.1" required>
        </div>
        <div class="field">
          <label>Porta</label>
          <input type="text" name="db_port" value="3306" required>
        </div>
      </div>

      <div class="field">
        <label>Nome do banco</label>
        <input type="text" name="db_name" value="tati_studio" required>
        <p class="hint">O banco deve existir antes da instalação. Crie-o no painel ou via MySQL.</p>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
        <div class="field">
          <label>Usuário MySQL</label>
          <input type="text" name="db_user" placeholder="tati_user" required autocomplete="off">
        </div>
        <div class="field">
          <label>Senha MySQL</label>
          <input type="password" name="db_pass" placeholder="Senha do usuário" autocomplete="new-password">
        </div>
      </div>
      <p class="hint" style="margin-top:-.5rem;margin-bottom:1.2rem">
        💡 O instalador vai criar as tabelas automaticamente após conectar.
      </p>

      <button class="btn" type="submit">Instalar sistema</button>
    </form>

  <?php else: ?>
    <!-- Step 0 por padrão -->
    <h1>Verificação do ambiente</h1>
    <p class="subtitle">Iniciando verificação...</p>
    <form method="POST"><input type="hidden" name="step" value="0"><button class="btn">Verificar</button></form>
  <?php endif; ?>

  </div><!-- .card -->
</div>

<script>
function toggleSubpath(type) {
  const field = document.getElementById('subpath-field');
  const input = document.getElementById('subpath-input');
  if (type === 'sub') {
    field.style.display = 'block';
    input.setAttribute('required', 'required');
  } else {
    field.style.display = 'none';
    input.removeAttribute('required');
    input.value = '';
  }
}
</script>
</body>
</html>
