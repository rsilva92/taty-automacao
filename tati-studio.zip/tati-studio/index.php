<?php
session_start();

// ── Config ───────────────────────────────────────────────────────────────────
$configFile = __DIR__ . '/includes/config.php';
if (!file_exists($configFile)) {
    die('<p style="font:1rem sans-serif;padding:2rem;color:#f87171">Sistema não instalado. Acesse <a href="installer.php">installer.php</a> primeiro.</p>');
}
require_once $configFile;

// ── Login ────────────────────────────────────────────────────────────────────
$loginError = '';
if (isset($_POST['action']) && $_POST['action'] === 'login') {
    if (password_verify($_POST['password'] ?? '', APP_PASSWORD)) {
        $_SESSION['auth'] = true;
    } else {
        $loginError = 'Senha incorreta.';
    }
}
if (isset($_POST['action']) && $_POST['action'] === 'logout') {
    session_destroy();
    header('Location: index.php');
    exit;
}
$authed = !empty($_SESSION['auth']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tati Indicando — Studio</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@400;500&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg: #08080f;
  --surface: #111119;
  --surface2: #181824;
  --border: #23233a;
  --border2: #2e2e4a;
  --accent: #ff6b35;
  --accent2: #ffb703;
  --text: #eeeef8;
  --muted: #6868888;
  --muted: #72728a;
  --ok: #2dd4bf;
  --err: #f87171;
  --r: 14px;
  --sidebar: 260px;
}

html, body { height: 100%; }
body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 15px;
  line-height: 1.6;
}

/* ── LOGIN ─────────────────────────────────────────────────── */
.login-wrap {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background-image:
    radial-gradient(ellipse at 15% 25%, rgba(255,107,53,.1) 0%, transparent 55%),
    radial-gradient(ellipse at 85% 75%, rgba(255,183,3,.08) 0%, transparent 55%);
}
.login-card {
  width: 100%;
  max-width: 400px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 2.5rem;
}
.login-logo {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1.6rem;
  letter-spacing: -.04em;
  margin-bottom: 2rem;
}
.login-logo span { color: var(--accent); }
.login-card h2 { font-family: 'Syne', sans-serif; font-size: 1.1rem; margin-bottom: .3rem; }
.login-card p { color: var(--muted); font-size: .88rem; margin-bottom: 1.8rem; }

label { display: block; font-size: .78rem; font-weight: 500; color: var(--muted); text-transform: uppercase; letter-spacing: .06em; margin-bottom: .45rem; }
input[type=password], input[type=text], textarea, select {
  width: 100%;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: .95rem;
  padding: .8rem 1rem;
  transition: border-color .2s;
  outline: none;
  resize: vertical;
}
input:focus, textarea:focus, select:focus { border-color: var(--accent); }
.login-err { color: var(--err); font-size: .85rem; margin-bottom: 1rem; }

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: .5rem;
  background: var(--accent);
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: .85rem 1.6rem;
  font-family: 'Syne', sans-serif;
  font-weight: 700;
  font-size: .95rem;
  cursor: pointer;
  transition: opacity .2s, transform .15s;
  letter-spacing: -.01em;
  white-space: nowrap;
}
.btn:hover { opacity: .85; transform: translateY(-1px); }
.btn:disabled { opacity: .4; cursor: not-allowed; transform: none; }
.btn-full { width: 100%; }
.btn-sm { padding: .5rem 1rem; font-size: .82rem; }
.btn-ghost {
  background: transparent;
  border: 1px solid var(--border2);
  color: var(--text);
}
.btn-ghost:hover { border-color: var(--accent); color: var(--accent); }

/* ── APP LAYOUT ────────────────────────────────────────────── */
.app { display: flex; height: 100vh; overflow: hidden; }

/* Sidebar */
.sidebar {
  width: var(--sidebar);
  flex-shrink: 0;
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  overflow-x: hidden;
}
.sidebar-logo {
  padding: 1.4rem 1.4rem 1rem;
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1rem;
  letter-spacing: -.03em;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.sidebar-logo span { color: var(--accent); }
.sidebar-logo .ver { font-size: .65rem; color: var(--muted); font-weight: 400; font-family: 'DM Sans', sans-serif; display: block; margin-top: .15rem; }

.sidebar-section { padding: 1rem .75rem .4rem; }
.sidebar-section-label { font-size: .68rem; text-transform: uppercase; letter-spacing: .08em; color: var(--muted); padding: 0 .6rem; margin-bottom: .4rem; }

.nav-item {
  display: flex;
  align-items: center;
  gap: .65rem;
  padding: .6rem .8rem;
  border-radius: 8px;
  cursor: pointer;
  transition: background .15s, color .15s;
  font-size: .88rem;
  color: var(--muted);
  position: relative;
  user-select: none;
}
.nav-item:hover { background: rgba(255,255,255,.04); color: var(--text); }
.nav-item.active { background: rgba(255,107,53,.1); color: var(--accent); }
.nav-item .icon { font-size: 1rem; flex-shrink: 0; width: 20px; text-align: center; }
.nav-item .badge {
  margin-left: auto;
  font-size: .65rem;
  padding: .15rem .45rem;
  border-radius: 20px;
  background: var(--border);
  color: var(--muted);
}
.nav-item.done .badge { background: rgba(45,212,191,.12); color: var(--ok); }
.nav-item.active .badge { background: rgba(255,107,53,.15); color: var(--accent); }

.sidebar-footer {
  margin-top: auto;
  border-top: 1px solid var(--border);
  padding: 1rem .75rem;
}

/* Progress bar */
.progress-bar-wrap { padding: .75rem 1.2rem; border-bottom: 1px solid var(--border); }
.progress-label { display: flex; justify-content: space-between; font-size: .75rem; color: var(--muted); margin-bottom: .4rem; }
.progress-bar { height: 4px; background: var(--border); border-radius: 2px; overflow: hidden; }
.progress-bar-fill { height: 100%; background: linear-gradient(90deg, var(--accent), var(--accent2)); border-radius: 2px; transition: width .4s ease; }

/* Main */
.main {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--bg);
}
.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 2rem;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  flex-shrink: 0;
  gap: 1rem;
}
.topbar-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1rem; }
.topbar-actions { display: flex; gap: .6rem; align-items: center; }

.content {
  flex: 1;
  overflow-y: auto;
  padding: 2rem;
}

/* Panel */
.panel { display: none; }
.panel.active { display: block; animation: fadeUp .25s ease; }
@keyframes fadeUp { from { opacity:0; transform: translateY(6px); } to { opacity:1; transform: translateY(0); } }

.panel-header { margin-bottom: 2rem; }
.panel-header h2 { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1.3rem; letter-spacing: -.02em; margin-bottom: .3rem; }
.panel-header p { color: var(--muted); font-size: .9rem; }

/* Cards */
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 1.5rem;
  margin-bottom: 1.5rem;
}
.card-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: .95rem; margin-bottom: 1rem; display: flex; align-items: center; gap: .5rem; }

/* Grid */
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
.field { margin-bottom: 1.2rem; }
.field:last-child { margin-bottom: 0; }

/* Result boxes */
.result-box {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  position: relative;
}
.result-box h3 {
  font-family: 'Syne', sans-serif;
  font-size: .85rem;
  color: var(--accent);
  text-transform: uppercase;
  letter-spacing: .06em;
  margin-bottom: .75rem;
  display: flex;
  align-items: center;
  gap: .4rem;
}
.result-content {
  font-size: .88rem;
  line-height: 1.75;
  color: var(--text);
  white-space: pre-wrap;
  font-family: 'DM Mono', monospace;
  font-size: .82rem;
}
.copy-btn {
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: var(--border);
  border: none;
  border-radius: 6px;
  color: var(--muted);
  padding: .3rem .65rem;
  font-size: .75rem;
  cursor: pointer;
  transition: background .15s, color .15s;
  font-family: 'DM Sans', sans-serif;
}
.copy-btn:hover { background: var(--accent); color: #fff; }

/* Loading */
.loading-overlay {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(8,8,15,.8);
  backdrop-filter: blur(4px);
  z-index: 1000;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 1rem;
}
.loading-overlay.show { display: flex; }
.spinner {
  width: 44px;
  height: 44px;
  border: 3px solid var(--border);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.loading-text { font-family: 'Syne', sans-serif; font-weight: 600; font-size: 1rem; color: var(--text); }
.loading-sub { color: var(--muted); font-size: .85rem; }

/* Step status */
.step-status { display: flex; align-items: center; gap: .5rem; font-size: .82rem; margin-bottom: .4rem; }
.dot-status { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.dot-pending { background: var(--border2); }
.dot-running { background: var(--accent2); animation: pulse 1s ease infinite; }
.dot-done    { background: var(--ok); }
.dot-error   { background: var(--err); }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }

/* Toast */
.toast {
  position: fixed;
  bottom: 2rem;
  right: 2rem;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: .8rem 1.2rem;
  font-size: .88rem;
  z-index: 9999;
  transform: translateY(20px);
  opacity: 0;
  transition: all .3s ease;
  pointer-events: none;
}
.toast.show { transform: translateY(0); opacity: 1; }
.toast.ok { border-color: var(--ok); color: var(--ok); }
.toast.err { border-color: var(--err); color: var(--err); }

/* Welcome */
.welcome-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; margin-top: 1.5rem; }
.welcome-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 1.2rem;
  cursor: pointer;
  transition: border-color .2s, background .2s;
}
.welcome-card:hover { border-color: var(--accent); background: rgba(255,107,53,.05); }
.welcome-card .wc-icon { font-size: 1.6rem; margin-bottom: .6rem; }
.welcome-card .wc-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: .9rem; margin-bottom: .2rem; }
.welcome-card .wc-desc { font-size: .78rem; color: var(--muted); line-height: 1.5; }

/* Roteiro field */
#roteiro {
  min-height: 280px;
  font-size: .82rem;
  font-family: 'DM Mono', monospace;
  line-height: 1.7;
}

/* Responsive */
@media (max-width: 768px) {
  .sidebar { display: none; }
  .grid-2 { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<?php if (!$authed): ?>
<!-- ════════════════════ LOGIN ════════════════════ -->
<div class="login-wrap">
  <div class="login-card">
    <div class="login-logo">Tati <span>Studio</span></div>
    <h2>Entrar no sistema</h2>
    <p>Acesso restrito. Digite sua senha para continuar.</p>
    <?php if ($loginError): ?>
    <p class="login-err">⚠ <?= htmlspecialchars($loginError) ?></p>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="action" value="login">
      <div class="field">
        <label>Senha</label>
        <input type="password" name="password" autofocus placeholder="••••••••">
      </div>
      <button class="btn btn-full" style="margin-top:.5rem">Entrar</button>
    </form>
  </div>
</div>

<?php else: ?>
<!-- ════════════════════ APP ════════════════════ -->
<div class="app">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      Tati <span>Studio</span>
      <span class="ver">v<?= APP_VERSION ?> — Produção</span>
    </div>

    <div class="progress-bar-wrap">
      <div class="progress-label">
        <span>Progresso</span>
        <span id="progress-pct">0%</span>
      </div>
      <div class="progress-bar"><div class="progress-bar-fill" id="progress-fill" style="width:0%"></div></div>
    </div>

    <div class="sidebar-section">
      <div class="sidebar-section-label">Entrada</div>
      <div class="nav-item active" data-panel="welcome" onclick="goPanel('welcome')">
        <span class="icon">🏠</span> Início
      </div>
      <div class="nav-item" data-panel="roteiro" onclick="goPanel('roteiro')">
        <span class="icon">📋</span> Roteiro
        <span class="badge" id="badge-roteiro">—</span>
      </div>
    </div>

    <div class="sidebar-section">
      <div class="sidebar-section-label">Agentes de produção</div>
      <div class="nav-item" data-panel="bloco1" onclick="goPanel('bloco1')">
        <span class="icon">🗺️</span> Mapa do Roteiro
        <span class="badge" id="badge-bloco1">—</span>
      </div>
      <div class="nav-item" data-panel="bloco2" onclick="goPanel('bloco2')">
        <span class="icon">🎯</span> Verdade-Base
        <span class="badge" id="badge-bloco2">—</span>
      </div>
      <div class="nav-item" data-panel="bloco3" onclick="goPanel('bloco3')">
        <span class="icon">📐</span> Ângulo Estratégico
        <span class="badge" id="badge-bloco3">—</span>
      </div>
      <div class="nav-item" data-panel="bloco4" onclick="goPanel('bloco4')">
        <span class="icon">✏️</span> Roteiro Otimizado
        <span class="badge" id="badge-bloco4">—</span>
      </div>
      <div class="nav-item" data-panel="bloco5" onclick="goPanel('bloco5')">
        <span class="icon">🎬</span> Storyboard 3×3
        <span class="badge" id="badge-bloco5">—</span>
      </div>
      <div class="nav-item" data-panel="bloco6" onclick="goPanel('bloco6')">
        <span class="icon">🎥</span> Shotlist
        <span class="badge" id="badge-bloco6">—</span>
      </div>
      <div class="nav-item" data-panel="bloco7" onclick="goPanel('bloco7')">
        <span class="icon">🖼️</span> Prompts Imagem IA
        <span class="badge" id="badge-bloco7">—</span>
      </div>
      <div class="nav-item" data-panel="bloco8" onclick="goPanel('bloco8')">
        <span class="icon">📹</span> Prompts Vídeo IA
        <span class="badge" id="badge-bloco8">—</span>
      </div>
      <div class="nav-item" data-panel="bloco9" onclick="goPanel('bloco9')">
        <span class="icon">💬</span> Overlays
        <span class="badge" id="badge-bloco9">—</span>
      </div>
      <div class="nav-item" data-panel="bloco10" onclick="goPanel('bloco10')">
        <span class="icon">🔤</span> Títulos
        <span class="badge" id="badge-bloco10">—</span>
      </div>
      <div class="nav-item" data-panel="bloco11" onclick="goPanel('bloco11')">
        <span class="icon">🖼️</span> Thumbnail
        <span class="badge" id="badge-bloco11">—</span>
      </div>
      <div class="nav-item" data-panel="bloco12" onclick="goPanel('bloco12')">
        <span class="icon">📝</span> Descrição SEO
        <span class="badge" id="badge-bloco12">—</span>
      </div>
      <div class="nav-item" data-panel="bloco13" onclick="goPanel('bloco13')">
        <span class="icon">📢</span> Aba Comunidade
        <span class="badge" id="badge-bloco13">—</span>
      </div>
      <div class="nav-item" data-panel="bloco14" onclick="goPanel('bloco14')">
        <span class="icon">✅</span> Auditoria Final
        <span class="badge" id="badge-bloco14">—</span>
      </div>
    </div>

    <div class="sidebar-footer">
      <form method="POST" style="margin:0">
        <input type="hidden" name="action" value="logout">
        <button class="btn btn-ghost btn-sm btn-full" type="submit">Sair</button>
      </form>
    </div>
  </aside>

  <!-- MAIN -->
  <main class="main">
    <div class="topbar">
      <span class="topbar-title" id="topbar-title">Início</span>
      <div class="topbar-actions">
        <button class="btn btn-sm btn-ghost" onclick="resetAll()">🔄 Novo projeto</button>
        <button class="btn btn-sm" id="btn-run-all" onclick="runAll()" disabled>▶ Gerar tudo</button>
      </div>
    </div>

    <div class="content">

      <!-- WELCOME -->
      <div class="panel active" id="panel-welcome">
        <div class="panel-header">
          <h2>👋 Bem-vinda ao Studio</h2>
          <p>Sistema multiagente de produção de conteúdo YouTube Faceless — Tati Indicando</p>
        </div>
        <div class="card">
          <div class="card-title">🚀 Como usar</div>
          <div style="color:var(--muted);font-size:.9rem;line-height:1.8">
            <strong style="color:var(--text)">1.</strong> Vá até <strong style="color:var(--accent)">Roteiro</strong> e cole o seu roteiro completo.<br>
            <strong style="color:var(--text)">2.</strong> Clique em <strong style="color:var(--accent)">▶ Gerar tudo</strong> para rodar todos os 14 agentes automaticamente.<br>
            <strong style="color:var(--text)">3.</strong> Ou clique em <strong style="color:var(--accent)">▶ Gerar este bloco</strong> em cada etapa para rodar individualmente.<br>
            <strong style="color:var(--text)">4.</strong> Copie os resultados usando o botão <strong style="color:var(--accent)">Copiar</strong> em cada bloco.<br>
            <strong style="color:var(--text)">5.</strong> Clique em <strong style="color:var(--accent)">🔄 Novo projeto</strong> para começar um novo vídeo.
          </div>
        </div>
        <div class="welcome-grid">
          <div class="welcome-card" onclick="goPanel('roteiro')">
            <div class="wc-icon">📋</div>
            <div class="wc-title">Começar aqui</div>
            <div class="wc-desc">Cole seu roteiro e inicie a produção</div>
          </div>
          <div class="welcome-card" onclick="runAll()">
            <div class="wc-icon">⚡</div>
            <div class="wc-title">Gerar tudo</div>
            <div class="wc-desc">Roda todos os 14 agentes em sequência</div>
          </div>
        </div>
      </div>

      <!-- ROTEIRO -->
      <div class="panel" id="panel-roteiro">
        <div class="panel-header">
          <h2>📋 Roteiro</h2>
          <p>Cole aqui o roteiro completo do vídeo. Todo o sistema nasce a partir dele.</p>
        </div>
        <div class="card">
          <div class="field">
            <label>Roteiro completo</label>
            <textarea id="roteiro" placeholder="Cole aqui o roteiro completo do seu vídeo..."></textarea>
          </div>
          <button class="btn" onclick="saveRoteiro()">💾 Salvar e continuar</button>
        </div>
      </div>

      <!-- BLOCOS 1–14 (gerados dinamicamente) -->
      <?php
      $blocos = [
        1  => ['🗺️', 'Mapa do Roteiro',       'Extrai estrutura, personagens, momentos-chave e intenção de compra.'],
        2  => ['🎯', 'Verdade-Base',            'Identifica os fatos reais do roteiro que sustentam todo o conteúdo.'],
        3  => ['📐', 'Ângulo Estratégico',      'Define o posicionamento, intenção de busca, clique, retenção e compra.'],
        4  => ['✏️', 'Roteiro Otimizado',       'Versão aprimorada do roteiro, sem mudar a essência original.'],
        5  => ['🎬', 'Storyboard 3×3',          'Divisão visual em 9 a 12 cenas com descrição de cada uma.'],
        6  => ['🎥', 'Shotlist Detalhada',      'Lista técnica de cada cena: tipo de plano, ação, duração.'],
        7  => ['🖼️', 'Prompts de Imagem IA',    'Prompts hiper-realistas em inglês para geração de imagens por IA.'],
        8  => ['📹', 'Prompts de Vídeo IA',     'Prompts com keyframes e movimentos de câmera para vídeos IA.'],
        9  => ['💬', 'Overlays de Benefícios',  'Textos de sobreposição que aparecem na tela durante o vídeo.'],
        10 => ['🔤', 'Títulos',                 '20 títulos divididos em 4 categorias: Search, Browse, Comparação e Decisão.'],
        11 => ['🖼️', 'Thumbnail',               'Conceito, layout, psicologia de clique, prompt e variações de texto.'],
        12 => ['📝', 'Descrição SEO',           'Descrição completa com CTA, timestamps, links e 20 palavras-chave.'],
        13 => ['📢', 'Aba Comunidade',          'Post de carrossel com prompts, legenda, CTA e hashtags.'],
        14 => ['✅', 'Auditoria Final',          'Checklist completo de qualidade: fidelidade, coerência e conversão.'],
      ];
      foreach ($blocos as $n => $info):
      ?>
      <div class="panel" id="panel-bloco<?= $n ?>">
        <div class="panel-header">
          <h2><?= $info[0] ?> Bloco <?= $n ?> — <?= $info[1] ?></h2>
          <p><?= $info[2] ?></p>
        </div>
        <div style="display:flex;gap:.75rem;margin-bottom:1.5rem">
          <button class="btn btn-sm" onclick="runBloco(<?= $n ?>)">▶ Gerar este bloco</button>
          <?php if ($n > 1): ?>
          <button class="btn btn-sm btn-ghost" onclick="goPanel('bloco<?= $n-1 ?>')">← Anterior</button>
          <?php endif; ?>
          <?php if ($n < 14): ?>
          <button class="btn btn-sm btn-ghost" onclick="goPanel('bloco<?= $n+1 ?>')">Próximo →</button>
          <?php endif; ?>
        </div>
        <div id="result-bloco<?= $n ?>" style="display:none">
          <div class="result-box">
            <h3><?= $info[0] ?> <?= $info[1] ?></h3>
            <button class="copy-btn" onclick="copyResult(<?= $n ?>)">Copiar</button>
            <div class="result-content" id="content-bloco<?= $n ?>"></div>
          </div>
        </div>
        <div id="empty-bloco<?= $n ?>" class="card" style="color:var(--muted);font-size:.9rem;text-align:center;padding:2.5rem">
          Clique em <strong>▶ Gerar este bloco</strong> para processar esta etapa.
        </div>
      </div>
      <?php endforeach; ?>

    </div><!-- .content -->
  </main>
</div><!-- .app -->

<!-- LOADING OVERLAY -->
<div class="loading-overlay" id="loading">
  <div class="spinner"></div>
  <div class="loading-text" id="loading-text">Processando...</div>
  <div class="loading-sub" id="loading-sub">Aguarde</div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<script>
// ── State ────────────────────────────────────────────────────────────────────
const state = {
  roteiro: '',
  results: {},
  done: new Set()
};

const TOTAL_BLOCOS = 14;

// ── Navigation ───────────────────────────────────────────────────────────────
function goPanel(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const panel = document.getElementById('panel-' + name);
  if (panel) panel.classList.add('active');
  const nav = document.querySelector(`[data-panel="${name}"]`);
  if (nav) nav.classList.add('active');
  const titles = {
    'welcome': 'Início',
    'roteiro': 'Roteiro',
    ...Object.fromEntries(Array.from({length:14},(_,i)=>[`bloco${i+1}`,`Bloco ${i+1}`]))
  };
  document.getElementById('topbar-title').textContent = titles[name] || name;
}

// ── Roteiro ──────────────────────────────────────────────────────────────────
function saveRoteiro() {
  const val = document.getElementById('roteiro').value.trim();
  if (!val || val.length < 50) {
    showToast('Cole um roteiro com pelo menos 50 caracteres.', 'err');
    return;
  }
  state.roteiro = val;
  document.getElementById('badge-roteiro').textContent = '✓';
  document.querySelector('[data-panel="roteiro"]').classList.add('done');
  document.getElementById('btn-run-all').disabled = false;
  showToast('Roteiro salvo! Pronto para gerar.', 'ok');
  goPanel('bloco1');
}

// ── Progress ─────────────────────────────────────────────────────────────────
function updateProgress() {
  const pct = Math.round((state.done.size / TOTAL_BLOCOS) * 100);
  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('progress-pct').textContent = pct + '%';
}

// ── API Call ─────────────────────────────────────────────────────────────────
async function callAPI(prompt) {
  const res = await fetch('api/agent.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ prompt })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Erro na API');
  }
  const data = await res.json();
  return data.result;
}

// ── Agents prompts ───────────────────────────────────────────────────────────
function buildPrompt(n) {
  const roteiro = state.roteiro;
  const ctx = (b) => state.results[b] ? `\n\n[BLOCO ${b} JÁ GERADO]\n${state.results[b]}` : '';

  const base = `Você é um agente especialista em produção de conteúdo YouTube faceless para o canal "Tati Indicando" (nicho: eletrodomésticos, afiliados).

REGRAS FIXAS:
- Tudo deve nascer do roteiro abaixo
- Não inventar características técnicas
- Não criar benefício que o roteiro não sustenta
- Não citar lojas na narração
- Não usar abertura clichê
- Não usar "fala pessoal"
- Não revelar o 1º lugar antes da hora
- Cada cena deve espelhar um trecho do roteiro
- Cada benefício precisa virar prova visual
- Imagens sem texto, prompts hiper-realistas
- Tom: Natural, direto, confiável, comercial e humano

ROTEIRO COMPLETO:
${roteiro}${ctx(n-1)}

`;

  const tasks = {
    1: base + `TAREFA: Gere o BLOCO 1 — MAPA DO ROTEIRO.
Extraia e apresente de forma estruturada:
- Tema central e produto(s) em destaque
- Estrutura (introdução, desenvolvimento, encerramento)
- Momentos-chave de persuasão
- Palavras e frases de intenção de compra presentes no roteiro
- Produtos citados e ordem de aparição
- Tom identificado
- Duração estimada da narração`,

    2: base + `TAREFA: Gere o BLOCO 2 — VERDADE-BASE EXTRAÍDA DO ROTEIRO.
Liste apenas fatos reais que o roteiro sustenta:
- Benefícios mencionados explicitamente
- Diferenciais citados
- Comparações presentes
- Dados ou números mencionados
- Problemas que os produtos resolvem (conforme o roteiro)
- O que NÃO está no roteiro (alertas de invenção a evitar)`,

    3: base + `TAREFA: Gere o BLOCO 3 — ÂNGULO ESTRATÉGICO.
Defina:
- Intenção de busca do espectador (Search Intent)
- Gatilho de clique principal
- Estratégia de retenção (o que faz o viewer ficar até o fim)
- Momento de decisão de compra (onde o CTA é mais forte)
- Posicionamento do canal neste vídeo
- Diferencial competitivo deste vídeo vs. outros do nicho`,

    4: base + `TAREFA: Gere o BLOCO 4 — ROTEIRO OTIMIZADO.
Reescreva o roteiro mantendo 100% da essência, mas:
- Melhorando o ritmo e a fluidez
- Reforçando os CTAs naturais
- Eliminando redundâncias
- Adicionando ganchos de retenção nas viradas de cena
- Garantindo que o 1º lugar seja revelado apenas no final
- Máximo 6 minutos de narração`,

    5: base + `TAREFA: Gere o BLOCO 5 — STORYBOARD 3x3.
Divida o vídeo em 9 a 12 cenas. Para cada cena:
- Número e título da cena
- Trecho do roteiro correspondente
- Descrição visual (o que aparece na tela)
- Objetivo emocional da cena
- Duração estimada`,

    6: base + `TAREFA: Gere o BLOCO 6 — SHOTLIST DETALHADA.
Para cada cena do storyboard, entregue:
- Tipo de plano (close, detalhe, ambiente, packshot, etc.)
- Ângulo e posição de câmera
- Ação principal do produto na cena
- Iluminação sugerida
- Duração em segundos
- Notas de direção`,

    7: base + `TAREFA: Gere o BLOCO 7 — PROMPTS DE IMAGEM IA.
Para cada cena (9 a 12), entregue:
- Trecho do roteiro vinculado
- Objetivo visual
- Prompt completo em inglês (hiper-realista, sem texto na imagem, sem logotipos inventados, sem CGI artificial)
- Iluminação
- Lente (ex: 85mm f/1.8)
- Enquadramento
- Composição
- Frame inicial
- Frame final
- Negative prompt`,

    8: base + `TAREFA: Gere o BLOCO 8 — PROMPTS DE VÍDEO IA.
Para cada cena, entregue:
- Duração estimada
- Intenção visual
- Movimento de câmera
- Ação do produto
- Keyframe inicial
- Keyframe intermediário
- Keyframe final
- Transição para próxima cena
- Prompt completo em inglês
- Negative prompt`,

    9: base + `TAREFA: Gere o BLOCO 9 — OVERLAYS DE BENEFÍCIOS.
Para cada cena, crie textos de sobreposição:
- Texto principal do overlay (máx 5 palavras)
- Subtexto se necessário (máx 8 palavras)
- Momento de entrada (ex: "aos 0:45")
- Duração do overlay em segundos
- Estilo visual sugerido (cor, posição)
- Baseie-se APENAS no que o roteiro sustenta`,

    10: base + `TAREFA: Gere o BLOCO 10 — TÍTULOS.
Crie exatamente:
5 títulos Search (palavras-chave diretas, comprador quente)
5 títulos Browse (curiosidade, emoção, formato)
5 títulos Comparação (produto vs. produto, ranking)
5 títulos Decisão de compra (urgência, certeza, CTR)
Total: 20 títulos. Cada um com máx 60 caracteres. Não repita a mesma ideia.`,

    11: base + `TAREFA: Gere o BLOCO 11 — THUMBNAIL.
Entregue:
- Conceito criativo
- Layout descrito (o que aparece em cada zona)
- Psicologia de clique usada
- Texto curto para a thumbnail (máx 4 palavras)
- Prompt completo da thumbnail em inglês (hiper-realista, sem distorções, produto real)
- 3 variações de texto alternativas`,

    12: base + `TAREFA: Gere o BLOCO 12 — DESCRIÇÃO SEO.
Estrutura completa:
- CTA inicial (2-3 linhas, antes dos links)
- Timestamps de cada cena
- 3º lugar: produto + links Mercado Livre, Magalu e Shopee (use [LINK ML], [LINK MAGALU], [LINK SHOPEE] como placeholder)
- 2º lugar: mesmo formato
- 1º lugar: mesmo formato
- Link do vídeo (placeholder)
- Breve resumo do vídeo (3-4 linhas)
- 20 palavras-chave long-tail separadas por vírgula
- 3 hashtags finais`,

    13: base + `TAREFA: Gere o BLOCO 13 — ABA COMUNIDADE.
Entregue:
- Ideia de carrossel 1:1 (quantos slides, tema de cada um)
- Prompts de imagem para cada slide (em inglês, hiper-realista)
- Legenda completa do post
- CTA final da legenda
- 5 palavras-chave relevantes
- 3 hashtags`,

    14: base + `TAREFA: Gere o BLOCO 14 — AUDITORIA FINAL.
Verifique cada item abaixo com ✅ (aprovado) ou ⚠️ (atenção) + justificativa:

1. Tudo nasceu do roteiro?
2. Há invenção técnica não sustentada?
3. Cenas estão conectadas ao roteiro?
4. Títulos prometem o que o vídeo entrega?
5. Thumbnail não repete o título?
6. Descrição está otimizada para SEO?
7. CTAs estão naturais e não forçados?
8. Prompts visuais são fiéis ao roteiro?
9. A decisão de compra ficou clara para o espectador?
10. O 1º lugar foi revelado apenas no final?

Ao final, dê uma nota de 0 a 100 e uma recomendação geral.`
  };

  return tasks[n] || base + `Execute o bloco ${n}.`;
}

// ── Run single bloco ─────────────────────────────────────────────────────────
async function runBloco(n) {
  if (!state.roteiro) {
    showToast('Salve o roteiro primeiro!', 'err');
    goPanel('roteiro');
    return;
  }
  showLoading(`Gerando Bloco ${n}...`, 'Chamando a IA — aguarde');
  try {
    const result = await callAPI(buildPrompt(n));
    state.results[n] = result;
    state.done.add(n);
    displayResult(n, result);
    updateProgress();
    updateBadge(n, '✓');
    showToast(`Bloco ${n} gerado com sucesso!`, 'ok');
  } catch (e) {
    showToast('Erro: ' + e.message, 'err');
    updateBadge(n, '!');
  } finally {
    hideLoading();
  }
}

// ── Run all ──────────────────────────────────────────────────────────────────
async function runAll() {
  if (!state.roteiro) {
    showToast('Salve o roteiro primeiro!', 'err');
    goPanel('roteiro');
    return;
  }
  document.getElementById('btn-run-all').disabled = true;
  for (let n = 1; n <= TOTAL_BLOCOS; n++) {
    goPanel('bloco' + n);
    showLoading(`Bloco ${n} de ${TOTAL_BLOCOS}`, `Gerando: ${['Mapa','Verdade-Base','Ângulo','Roteiro Otimizado','Storyboard','Shotlist','Prompts Imagem','Prompts Vídeo','Overlays','Títulos','Thumbnail','Descrição SEO','Aba Comunidade','Auditoria'][n-1]}`);
    try {
      const result = await callAPI(buildPrompt(n));
      state.results[n] = result;
      state.done.add(n);
      displayResult(n, result);
      updateProgress();
      updateBadge(n, '✓');
    } catch (e) {
      updateBadge(n, '!');
      showToast(`Erro no Bloco ${n}: ${e.message}`, 'err');
    }
  }
  hideLoading();
  document.getElementById('btn-run-all').disabled = false;
  showToast('🎉 Todos os blocos foram gerados!', 'ok');
}

// ── Display ──────────────────────────────────────────────────────────────────
function displayResult(n, text) {
  document.getElementById('content-bloco' + n).textContent = text;
  document.getElementById('result-bloco' + n).style.display = 'block';
  document.getElementById('empty-bloco' + n).style.display = 'none';
}

function updateBadge(n, text) {
  const badge = document.getElementById('badge-bloco' + n);
  if (badge) {
    badge.textContent = text;
    if (text === '✓') document.querySelector(`[data-panel="bloco${n}"]`).classList.add('done');
  }
}

function copyResult(n) {
  const text = document.getElementById('content-bloco' + n).textContent;
  navigator.clipboard.writeText(text).then(() => showToast('Copiado!', 'ok'));
}

// ── Reset ────────────────────────────────────────────────────────────────────
function resetAll() {
  if (!confirm('Limpar tudo e começar um novo projeto?')) return;
  state.roteiro = '';
  state.results = {};
  state.done.clear();
  document.getElementById('roteiro').value = '';
  for (let n = 1; n <= TOTAL_BLOCOS; n++) {
    document.getElementById('result-bloco' + n).style.display = 'none';
    document.getElementById('empty-bloco' + n).style.display = 'block';
    document.getElementById('content-bloco' + n).textContent = '';
    updateBadge(n, '—');
    document.querySelector(`[data-panel="bloco${n}"]`).classList.remove('done');
  }
  document.getElementById('badge-roteiro').textContent = '—';
  document.querySelector('[data-panel="roteiro"]').classList.remove('done');
  document.getElementById('btn-run-all').disabled = true;
  updateProgress();
  goPanel('welcome');
}

// ── UI helpers ───────────────────────────────────────────────────────────────
function showLoading(title, sub) {
  document.getElementById('loading-text').textContent = title;
  document.getElementById('loading-sub').textContent = sub;
  document.getElementById('loading').classList.add('show');
}
function hideLoading() {
  document.getElementById('loading').classList.remove('show');
}
function showToast(msg, type = 'ok') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type} show`;
  setTimeout(() => t.classList.remove('show'), 3000);
}
</script>

<?php endif; ?>
</body>
</html>
