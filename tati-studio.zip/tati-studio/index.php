<?php
session_start();

// ── Config ───────────────────────────────────────────────────────────────────
$configFile = __DIR__ . '/includes/config.php';
if (!file_exists($configFile)) {
    die('<p style="font:1rem sans-serif;padding:2rem;color:#f87171">Sistema não instalado. Acesse <a href="installer.php">installer.php</a> primeiro.</p>');
}
require_once $configFile;

// ── Login / Logout ────────────────────────────────────────────────────────────
$loginError = '';
if (isset($_POST['action'])) {
    if ($_POST['action'] === 'login') {
        $pass = $_POST['password'] ?? '';
        if (password_verify($pass, APP_PASSWORD)) {
            session_regenerate_id(true); // previne session fixation
            $_SESSION['auth'] = true;
        } else {
            $loginError = 'Senha incorreta.';
        }
    }
    if ($_POST['action'] === 'logout') {
        session_destroy();
        header('Location: index.php');
        exit;
    }
}
$authed = !empty($_SESSION['auth']);

// ── URL da API: relativa ao script atual, funciona em raiz e subpasta ────────
// dirname('/index.php') = '/' na raiz — rtrim remove a barra, resultando em string vazia.
// Assim '/api/agent.php' fica correto tanto na raiz quanto em subpasta.
$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$apiUrl    = $scriptDir . '/api/agent.php'; // ex: '/api/agent.php' ou '/studio/api/agent.php'
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tati Indicando — Studio</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@400;500&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg:       #08080f;
  --surface:  #111119;
  --surface2: #181824;
  --border:   #23233a;
  --border2:  #2e2e4a;
  --accent:   #ff6b35;
  --accent2:  #ffb703;
  --text:     #eeeef8;
  --muted:    #72728a;  /* FIX #6: removida declaração duplicada */
  --ok:       #2dd4bf;
  --err:      #f87171;
  --r:        14px;
  --sidebar:  260px;
}

html, body { height: 100%; }
body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 15px;
  line-height: 1.6;
}

/* ── LOGIN ─────────────────────────────────────────────── */
.login-wrap {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background-image:
    radial-gradient(ellipse at 15% 25%, rgba(255,107,53,.1) 0%, transparent 55%),
    radial-gradient(ellipse at 85% 75%, rgba(255,183,3,.08) 0%, transparent 55%);
}
.login-card {
  width: 100%;
  max-width: 400px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 2.5rem;
}
.login-logo {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1.6rem;
  letter-spacing: -.04em;
  margin-bottom: 2rem;
}
.login-logo span { color: var(--accent); }
.login-card h2 { font-family: 'Syne', sans-serif; font-size: 1.1rem; margin-bottom: .3rem; }
.login-card .subtitle { color: var(--muted); font-size: .88rem; margin-bottom: 1.8rem; }
.login-err { color: var(--err); font-size: .85rem; margin-bottom: 1rem; padding: .6rem .8rem; background: rgba(248,113,113,.08); border-radius: 6px; }

label { display: block; font-size: .78rem; font-weight: 500; color: var(--muted); text-transform: uppercase; letter-spacing: .06em; margin-bottom: .45rem; }
input[type=password], input[type=text], textarea, select {
  width: 100%;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: .95rem;
  padding: .8rem 1rem;
  transition: border-color .2s;
  outline: none;
  resize: vertical;
}
input:focus, textarea:focus, select:focus { border-color: var(--accent); }

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: .5rem;
  background: var(--accent);
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: .85rem 1.6rem;
  font-family: 'Syne', sans-serif;
  font-weight: 700;
  font-size: .95rem;
  cursor: pointer;
  transition: opacity .2s, transform .15s;
  letter-spacing: -.01em;
  white-space: nowrap;
}
.btn:hover  { opacity: .85; transform: translateY(-1px); }
.btn:active { transform: translateY(0); }
.btn:disabled { opacity: .4; cursor: not-allowed; transform: none; }
.btn-full { width: 100%; }
.btn-sm { padding: .5rem 1rem; font-size: .82rem; }
.btn-ghost {
  background: transparent;
  border: 1px solid var(--border2);
  color: var(--text);
}
.btn-ghost:hover { border-color: var(--accent); color: var(--accent); }

/* ── LAYOUT ────────────────────────────────────────────── */
.app { display: flex; height: 100vh; overflow: hidden; }

.sidebar {
  width: var(--sidebar);
  flex-shrink: 0;
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  overflow-x: hidden;
}
.sidebar-logo {
  padding: 1.4rem 1.4rem 1rem;
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1rem;
  letter-spacing: -.03em;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.sidebar-logo span { color: var(--accent); }
.sidebar-logo .ver { font-size: .65rem; color: var(--muted); font-weight: 400; font-family: 'DM Sans', sans-serif; display: block; margin-top: .15rem; }

.sidebar-section { padding: 1rem .75rem .4rem; }
.sidebar-section-label { font-size: .68rem; text-transform: uppercase; letter-spacing: .08em; color: var(--muted); padding: 0 .6rem; margin-bottom: .4rem; }

.nav-item {
  display: flex;
  align-items: center;
  gap: .65rem;
  padding: .6rem .8rem;
  border-radius: 8px;
  cursor: pointer;
  transition: background .15s, color .15s;
  font-size: .88rem;
  color: var(--muted);
  user-select: none;
}
.nav-item:hover  { background: rgba(255,255,255,.04); color: var(--text); }
.nav-item.active { background: rgba(255,107,53,.1);   color: var(--accent); }
.nav-item .icon  { font-size: 1rem; flex-shrink: 0; width: 20px; text-align: center; }
.nav-item .badge {
  margin-left: auto;
  font-size: .65rem;
  padding: .15rem .45rem;
  border-radius: 20px;
  background: var(--border);
  color: var(--muted);
}
.nav-item.done   .badge { background: rgba(45,212,191,.12);  color: var(--ok); }
.nav-item.active .badge { background: rgba(255,107,53,.15);  color: var(--accent); }
.nav-item.err    .badge { background: rgba(248,113,113,.12); color: var(--err); }

.sidebar-footer {
  margin-top: auto;
  border-top: 1px solid var(--border);
  padding: 1rem .75rem;
}

.progress-bar-wrap { padding: .75rem 1.2rem; border-bottom: 1px solid var(--border); }
.progress-label { display: flex; justify-content: space-between; font-size: .75rem; color: var(--muted); margin-bottom: .4rem; }
.progress-bar { height: 4px; background: var(--border); border-radius: 2px; overflow: hidden; }
.progress-bar-fill { height: 100%; background: linear-gradient(90deg, var(--accent), var(--accent2)); border-radius: 2px; transition: width .4s ease; }

.main { flex: 1; display: flex; flex-direction: column; overflow: hidden; background: var(--bg); }

.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 2rem;
  border-bottom: 1px solid var(--border);
  background: var(--surface);
  flex-shrink: 0;
  gap: 1rem;
}
.topbar-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1rem; }
.topbar-actions { display: flex; gap: .6rem; align-items: center; }

.content { flex: 1; overflow-y: auto; padding: 2rem; }

.panel { display: none; }
.panel.active { display: block; animation: fadeUp .25s ease; }
@keyframes fadeUp { from { opacity:0; transform: translateY(6px); } to { opacity:1; transform: translateY(0); } }

.panel-header { margin-bottom: 2rem; }
.panel-header h2 { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1.3rem; letter-spacing: -.02em; margin-bottom: .3rem; }
.panel-header p  { color: var(--muted); font-size: .9rem; }

.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 1.5rem;
  margin-bottom: 1.5rem;
}
.card-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: .95rem; margin-bottom: 1rem; display: flex; align-items: center; gap: .5rem; }

.field { margin-bottom: 1.2rem; }
.field:last-child { margin-bottom: 0; }

.result-box {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  position: relative;
}
.result-box h3 {
  font-family: 'Syne', sans-serif;
  font-size: .85rem;
  color: var(--accent);
  text-transform: uppercase;
  letter-spacing: .06em;
  margin-bottom: .75rem;
}
.result-content {
  font-size: .82rem;
  line-height: 1.75;
  color: var(--text);
  white-space: pre-wrap;
  font-family: 'DM Mono', monospace;
}
.copy-btn {
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: var(--border);
  border: none;
  border-radius: 6px;
  color: var(--muted);
  padding: .3rem .65rem;
  font-size: .75rem;
  cursor: pointer;
  transition: background .15s, color .15s;
  font-family: 'DM Sans', sans-serif;
}
.copy-btn:hover { background: var(--accent); color: #fff; }

/* Loading */
.loading-overlay {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(8,8,15,.82);
  backdrop-filter: blur(4px);
  z-index: 1000;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 1rem;
}
.loading-overlay.show { display: flex; }
.spinner {
  width: 44px; height: 44px;
  border: 3px solid var(--border);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.loading-text { font-family: 'Syne', sans-serif; font-weight: 600; font-size: 1rem; }
.loading-sub  { color: var(--muted); font-size: .85rem; }

/* Toast */
.toast {
  position: fixed;
  bottom: 2rem; right: 2rem;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: .8rem 1.2rem;
  font-size: .88rem;
  z-index: 9999;
  transform: translateY(20px);
  opacity: 0;
  transition: all .3s ease;
  pointer-events: none;
  max-width: 320px;
}
.toast.show { transform: translateY(0); opacity: 1; }
.toast.ok  { border-color: var(--ok);  color: var(--ok); }
.toast.err { border-color: var(--err); color: var(--err); }

/* Welcome grid */
.welcome-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px,1fr)); gap: 1rem; margin-top: 1.5rem; }
.welcome-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 1.2rem;
  cursor: pointer;
  transition: border-color .2s, background .2s;
}
.welcome-card:hover { border-color: var(--accent); background: rgba(255,107,53,.05); }
.welcome-card .wc-icon  { font-size: 1.6rem; margin-bottom: .6rem; }
.welcome-card .wc-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: .9rem; margin-bottom: .2rem; }
.welcome-card .wc-desc  { font-size: .78rem; color: var(--muted); line-height: 1.5; }

/* Projetos */
.project-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: .8rem 1rem;
  border: 1px solid var(--border);
  border-radius: 8px;
  margin-bottom: .5rem;
  cursor: pointer;
  transition: border-color .2s;
}
.project-item:hover { border-color: var(--accent); }
.project-item .pi-title { font-weight: 500; font-size: .9rem; }
.project-item .pi-date  { font-size: .75rem; color: var(--muted); }
.project-item .pi-del   { background: none; border: none; color: var(--muted); cursor: pointer; font-size: .8rem; padding: .2rem .4rem; border-radius: 4px; }
.project-item .pi-del:hover { color: var(--err); background: rgba(248,113,113,.1); }

#roteiro { min-height: 280px; font-size: .82rem; font-family: 'DM Mono', monospace; line-height: 1.7; }

/* Bloco nav buttons */
.bloco-nav { display: flex; gap: .75rem; margin-bottom: 1.5rem; flex-wrap: wrap; }

@media (max-width: 768px) {
  .sidebar { display: none; }
}
</style>
</head>
<body>

<?php if (!$authed): ?>
<!-- ════════════ LOGIN ════════════ -->
<div class="login-wrap">
  <div class="login-card">
    <div class="login-logo">Tati <span>Studio</span></div>
    <h2>Entrar no sistema</h2>
    <p class="subtitle">Acesso restrito. Digite sua senha para continuar.</p>
    <?php if ($loginError): ?>
    <div class="login-err">⚠ <?= htmlspecialchars($loginError) ?></div>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="action" value="login">
      <div class="field">
        <label>Senha</label>
        <input type="password" name="password" autofocus placeholder="••••••••" autocomplete="current-password">
      </div>
      <button class="btn btn-full" style="margin-top:.75rem" type="submit">Entrar</button>
    </form>
  </div>
</div>

<?php else: ?>
<!-- ════════════ APP ════════════ -->
<div class="app">

  <aside class="sidebar">
    <div class="sidebar-logo">
      Tati <span>Studio</span>
      <span class="ver">v<?= APP_VERSION ?></span>
    </div>

    <div class="progress-bar-wrap">
      <div class="progress-label">
        <span>Progresso</span>
        <span id="progress-pct">0%</span>
      </div>
      <div class="progress-bar">
        <div class="progress-bar-fill" id="progress-fill" style="width:0%"></div>
      </div>
    </div>

    <div class="sidebar-section">
      <div class="sidebar-section-label">Entrada</div>
      <div class="nav-item active" data-panel="welcome" onclick="goPanel('welcome')">
        <span class="icon">🏠</span> Início
      </div>
      <div class="nav-item" data-panel="roteiro" onclick="goPanel('roteiro')">
        <span class="icon">📋</span> Roteiro
        <span class="badge" id="badge-roteiro">—</span>
      </div>
      <div class="nav-item" data-panel="projetos" onclick="goPanel('projetos'); loadProjects()">
        <span class="icon">💾</span> Projetos salvos
      </div>
    </div>

    <div class="sidebar-section">
      <div class="sidebar-section-label">Agentes de produção</div>
      <?php
      $blocos = [
        1  => ['🗺️', 'Mapa do Roteiro'],
        2  => ['🎯', 'Verdade-Base'],
        3  => ['📐', 'Ângulo Estratégico'],
        4  => ['✏️', 'Roteiro Otimizado'],
        5  => ['🎬', 'Storyboard 3×3'],
        6  => ['🎥', 'Shotlist'],
        7  => ['🖼️', 'Prompts Imagem IA'],
        8  => ['📹', 'Prompts Vídeo IA'],
        9  => ['💬', 'Overlays'],
        10 => ['🔤', 'Títulos'],
        11 => ['🖼️', 'Thumbnail'],
        12 => ['📝', 'Descrição SEO'],
        13 => ['📢', 'Aba Comunidade'],
        14 => ['✅', 'Auditoria Final'],
      ];
      foreach ($blocos as $n => $info):
      ?>
      <div class="nav-item" data-panel="bloco<?= $n ?>" onclick="goPanel('bloco<?= $n ?>')">
        <span class="icon"><?= $info[0] ?></span> <?= $info[1] ?>
        <span class="badge" id="badge-bloco<?= $n ?>">—</span>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="sidebar-footer">
      <form method="POST" style="margin:0">
        <input type="hidden" name="action" value="logout">
        <button class="btn btn-ghost btn-sm btn-full" type="submit">Sair</button>
      </form>
    </div>
  </aside>

  <main class="main">
    <div class="topbar">
      <span class="topbar-title" id="topbar-title">Início</span>
      <div class="topbar-actions">
        <button class="btn btn-sm btn-ghost" onclick="saveProject()">💾 Salvar projeto</button>
        <button class="btn btn-sm btn-ghost" onclick="resetAll()">🔄 Novo</button>
        <button class="btn btn-sm" id="btn-run-all" onclick="runAll()" disabled>▶ Gerar tudo</button>
      </div>
    </div>

    <div class="content">

      <!-- WELCOME -->
      <div class="panel active" id="panel-welcome">
        <div class="panel-header">
          <h2>👋 Bem-vinda ao Studio</h2>
          <p>Sistema multiagente de produção YouTube Faceless — Tati Indicando</p>
        </div>
        <div class="card">
          <div class="card-title">🚀 Como usar</div>
          <div style="color:var(--muted);font-size:.9rem;line-height:1.9">
            <strong style="color:var(--text)">1.</strong> Vá em <strong style="color:var(--accent)">Roteiro</strong> e cole o roteiro completo.<br>
            <strong style="color:var(--text)">2.</strong> Clique em <strong style="color:var(--accent)">▶ Gerar tudo</strong> para rodar todos os 14 agentes.<br>
            <strong style="color:var(--text)">3.</strong> Ou clique em <strong style="color:var(--accent)">▶ Gerar este bloco</strong> em cada etapa individualmente.<br>
            <strong style="color:var(--text)">4.</strong> Use <strong style="color:var(--accent)">💾 Salvar projeto</strong> para guardar o trabalho no banco.<br>
            <strong style="color:var(--text)">5.</strong> Recupere projetos anteriores em <strong style="color:var(--accent)">Projetos salvos</strong>.
          </div>
        </div>
        <div class="welcome-grid">
          <div class="welcome-card" onclick="goPanel('roteiro')">
            <div class="wc-icon">📋</div>
            <div class="wc-title">Começar aqui</div>
            <div class="wc-desc">Cole seu roteiro e inicie a produção</div>
          </div>
          <div class="welcome-card" onclick="runAll()">
            <div class="wc-icon">⚡</div>
            <div class="wc-title">Gerar tudo</div>
            <div class="wc-desc">Roda os 14 agentes em sequência</div>
          </div>
          <div class="welcome-card" onclick="goPanel('projetos'); loadProjects()">
            <div class="wc-icon">💾</div>
            <div class="wc-title">Projetos salvos</div>
            <div class="wc-desc">Retome um projeto anterior</div>
          </div>
        </div>
      </div>

      <!-- ROTEIRO -->
      <div class="panel" id="panel-roteiro">
        <div class="panel-header">
          <h2>📋 Roteiro</h2>
          <p>Cole aqui o roteiro completo. Todo o sistema nasce a partir dele.</p>
        </div>
        <div class="card">
          <div class="field">
            <label>Título do projeto</label>
            <input type="text" id="project-title" placeholder="Ex: Top 3 Aspiradores 2025">
          </div>
          <div class="field">
            <label>Roteiro completo</label>
            <textarea id="roteiro" placeholder="Cole aqui o roteiro completo do seu vídeo..."></textarea>
          </div>
          <button class="btn" onclick="saveRoteiro()">💾 Salvar e continuar →</button>
        </div>
      </div>

      <!-- PROJETOS -->
      <div class="panel" id="panel-projetos">
        <div class="panel-header">
          <h2>💾 Projetos salvos</h2>
          <p>Clique em um projeto para carregar todos os resultados.</p>
        </div>
        <div id="projects-list">
          <div class="card" style="color:var(--muted);text-align:center;padding:2rem">
            Carregando projetos...
          </div>
        </div>
      </div>

      <!-- BLOCOS 1–14 -->
      <?php
      $blocoDesc = [
        1  => 'Extrai estrutura, personagens, momentos-chave e intenção de compra.',
        2  => 'Identifica os fatos reais do roteiro que sustentam todo o conteúdo.',
        3  => 'Define posicionamento, intenção de busca, clique, retenção e compra.',
        4  => 'Versão aprimorada do roteiro, sem mudar a essência original.',
        5  => 'Divisão visual em 9 a 12 cenas com descrição de cada uma.',
        6  => 'Lista técnica de cada cena: tipo de plano, ação, duração.',
        7  => 'Prompts hiper-realistas em inglês para geração de imagens por IA.',
        8  => 'Prompts com keyframes e movimentos de câmera para vídeos IA.',
        9  => 'Textos de sobreposição que aparecem na tela durante o vídeo.',
        10 => '20 títulos em 4 categorias: Search, Browse, Comparação e Decisão.',
        11 => 'Conceito, layout, psicologia de clique, prompt e variações de texto.',
        12 => 'Descrição completa com CTA, timestamps, links e 20 palavras-chave.',
        13 => 'Post de carrossel com prompts, legenda, CTA e hashtags.',
        14 => 'Checklist completo: fidelidade, coerência e conversão.',
      ];
      foreach ($blocos as $n => $info):
      ?>
      <div class="panel" id="panel-bloco<?= $n ?>">
        <div class="panel-header">
          <h2><?= $info[0] ?> Bloco <?= $n ?> — <?= $info[1] ?></h2>
          <p><?= $blocoDesc[$n] ?></p>
        </div>
        <div class="bloco-nav">
          <button class="btn btn-sm" onclick="runBloco(<?= $n ?>)">▶ Gerar este bloco</button>
          <?php if ($n > 1): ?>
          <button class="btn btn-sm btn-ghost" onclick="goPanel('bloco<?= $n-1 ?>')">← Bloco <?= $n-1 ?></button>
          <?php endif; ?>
          <?php if ($n < 14): ?>
          <button class="btn btn-sm btn-ghost" onclick="goPanel('bloco<?= $n+1 ?>')">Bloco <?= $n+1 ?> →</button>
          <?php endif; ?>
        </div>
        <div id="result-bloco<?= $n ?>" style="display:none">
          <div class="result-box">
            <h3><?= $info[0] ?> <?= $info[1] ?></h3>
            <button class="copy-btn" onclick="copyResult(<?= $n ?>)">Copiar</button>
            <div class="result-content" id="content-bloco<?= $n ?>"></div>
          </div>
        </div>
        <div id="empty-bloco<?= $n ?>" class="card" style="color:var(--muted);font-size:.9rem;text-align:center;padding:2.5rem">
          Clique em <strong>▶ Gerar este bloco</strong> para processar esta etapa.
        </div>
      </div>
      <?php endforeach; ?>

    </div><!-- .content -->
  </main>
</div><!-- .app -->

<!-- LOADING -->
<div class="loading-overlay" id="loading">
  <div class="spinner"></div>
  <div class="loading-text" id="loading-text">Processando...</div>
  <div class="loading-sub"  id="loading-sub">Aguarde</div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<script>
// ── State ─────────────────────────────────────────────────────────────────────
const state = {
  roteiro:    '',
  title:      '',
  project_id: 0,
  results:    {},
  done:       new Set()
};

const TOTAL   = 14;
// FIX #7: URL da API resolvida pelo PHP no servidor
const API_URL = <?= json_encode($apiUrl) ?>;

// ── Navigation ────────────────────────────────────────────────────────────────
function goPanel(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const panel = document.getElementById('panel-' + name);
  if (panel) panel.classList.add('active');
  const nav = document.querySelector(`[data-panel="${name}"]`);
  if (nav) nav.classList.add('active');
  // Atualiza título da topbar
  const el = nav ? nav.cloneNode(true) : null;
  if (el) {
    el.querySelectorAll('.badge,.icon').forEach(x => x.remove());
    document.getElementById('topbar-title').textContent = el.textContent.trim();
  }
  window.scrollTo && window.scrollTo(0,0);
}

// ── Roteiro ───────────────────────────────────────────────────────────────────
function saveRoteiro() {
  const val   = document.getElementById('roteiro').value.trim();
  const title = document.getElementById('project-title').value.trim() || 'Sem título';
  if (!val || val.length < 50) {
    showToast('Cole um roteiro com pelo menos 50 caracteres.', 'err');
    return;
  }
  state.roteiro = val;
  state.title   = title;
  document.getElementById('badge-roteiro').textContent = '✓';
  document.querySelector('[data-panel="roteiro"]').classList.add('done');
  document.getElementById('btn-run-all').disabled = false;
  showToast('Roteiro salvo! Pronto para gerar.', 'ok');
  goPanel('bloco1');
}

// ── Progress ──────────────────────────────────────────────────────────────────
function updateProgress() {
  const pct = Math.round((state.done.size / TOTAL) * 100);
  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('progress-pct').textContent  = pct + '%';
}

// ── API ───────────────────────────────────────────────────────────────────────
async function callAPI(body) {
  const res = await fetch(API_URL, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

// ── Prompts dos agentes ───────────────────────────────────────────────────────
function buildPrompt(n) {
  const r   = state.roteiro;
  const ctx = b => state.results[b] ? `\n\n[BLOCO ${b} GERADO]\n${state.results[b]}` : '';

  const base = `Você é um agente especialista em produção de conteúdo YouTube faceless para o canal "Tati Indicando" (nicho: eletrodomésticos, afiliados).

REGRAS FIXAS:
- Tudo deve nascer do roteiro abaixo
- Não inventar características técnicas
- Não criar benefício que o roteiro não sustenta
- Não citar lojas na narração
- Não usar abertura clichê nem "fala pessoal"
- Não revelar o 1º lugar antes da hora
- Cada cena deve espelhar um trecho do roteiro
- Tom: natural, direto, confiável, comercial e humano

ROTEIRO COMPLETO:\n${r}${ctx(n - 1)}\n\n`;

  const tasks = {
    1:  base + `TAREFA — BLOCO 1: MAPA DO ROTEIRO.\nExtraia: tema central, produtos e ordem de aparição, estrutura (intro/dev/encerramento), momentos-chave de persuasão, palavras de intenção de compra, tom identificado, duração estimada de narração.`,
    2:  base + `TAREFA — BLOCO 2: VERDADE-BASE.\nListe SOMENTE fatos que o roteiro sustenta: benefícios explícitos, diferenciais citados, comparações presentes, dados/números mencionados, problemas que os produtos resolvem. Ao final, liste o que NÃO está no roteiro (itens a evitar inventar).`,
    3:  base + `TAREFA — BLOCO 3: ÂNGULO ESTRATÉGICO.\nDefina: intenção de busca do espectador, gatilho de clique principal, estratégia de retenção, momento de decisão de compra, posicionamento do canal, diferencial vs. outros vídeos do nicho.`,
    4:  base + `TAREFA — BLOCO 4: ROTEIRO OTIMIZADO.\nReescreva o roteiro mantendo 100% da essência: melhore o ritmo, reforce CTAs naturais, elimine redundâncias, adicione ganchos de retenção nas viradas, garanta que o 1º lugar seja revelado só no final. Máximo 6 minutos de narração.`,
    5:  base + `TAREFA — BLOCO 5: STORYBOARD 3x3.\nDivida em 9 a 12 cenas. Para cada: número + título, trecho do roteiro correspondente, descrição do que aparece na tela, objetivo emocional, duração estimada.`,
    6:  base + `TAREFA — BLOCO 6: SHOTLIST DETALHADA.\nPara cada cena: tipo de plano (close/detalhe/ambiente/packshot), ângulo de câmera, ação principal do produto, iluminação sugerida, duração em segundos, notas de direção.`,
    7:  base + `TAREFA — BLOCO 7: PROMPTS DE IMAGEM IA.\nPara cada cena (9-12), entregue: trecho vinculado, objetivo visual, prompt completo em inglês (hiper-realista, sem texto, sem logotipos inventados, sem CGI), iluminação, lente (ex: 85mm f/1.8), enquadramento, composição, frame inicial, frame final, negative prompt.`,
    8:  base + `TAREFA — BLOCO 8: PROMPTS DE VÍDEO IA.\nPara cada cena: duração, intenção visual, movimento de câmera, ação do produto, keyframe inicial, keyframe intermediário, keyframe final, transição, prompt completo em inglês, negative prompt.`,
    9:  base + `TAREFA — BLOCO 9: OVERLAYS DE BENEFÍCIOS.\nPara cada cena: texto principal (máx 5 palavras), subtexto se necessário (máx 8 palavras), momento de entrada (ex: "aos 0:45"), duração em segundos, estilo visual sugerido (cor, posição). Baseie-se APENAS no que o roteiro sustenta.`,
    10: base + `TAREFA — BLOCO 10: TÍTULOS.\nCrie exatamente: 5 títulos Search (palavras-chave diretas), 5 títulos Browse (curiosidade/emoção/formato), 5 títulos Comparação (ranking/produto vs produto), 5 títulos Decisão de compra (urgência/certeza). Total: 20 títulos, máx 60 caracteres cada, sem repetir ideias.`,
    11: base + `TAREFA — BLOCO 11: THUMBNAIL.\nEntregue: conceito criativo, layout por zona (o que aparece onde), psicologia de clique usada, texto curto (máx 4 palavras), prompt completo em inglês (hiper-realista, produto real, sem distorções), 3 variações de texto alternativas.`,
    12: base + `TAREFA — BLOCO 12: DESCRIÇÃO SEO.\nEntregue: CTA inicial (2-3 linhas), timestamps de cada cena, 3º lugar + links [LINK ML] [LINK MAGALU] [LINK SHOPEE], 2º lugar idem, 1º lugar idem, link do vídeo (placeholder), resumo do vídeo (3-4 linhas), 20 palavras-chave long-tail separadas por vírgula, 3 hashtags finais.`,
    13: base + `TAREFA — BLOCO 13: ABA COMUNIDADE.\nEntregue: ideia de carrossel 1:1 (slides e temas), prompts de imagem em inglês para cada slide, legenda completa, CTA final, 5 palavras-chave relevantes, 3 hashtags.`,
    14: base + `TAREFA — BLOCO 14: AUDITORIA FINAL.\nVerifique cada item com ✅ (aprovado) ou ⚠️ (atenção) + justificativa:\n1. Tudo nasceu do roteiro?\n2. Há invenção técnica não sustentada?\n3. Cenas conectadas ao roteiro?\n4. Títulos prometem o que o vídeo entrega?\n5. Thumbnail não repete o título?\n6. Descrição otimizada para SEO?\n7. CTAs naturais?\n8. Prompts fiéis ao roteiro?\n9. Decisão de compra clara?\n10. 1º lugar revelado só no final?\n\nAo final: nota de 0-100 e recomendação geral.`
  };

  return tasks[n] || base + `Execute o bloco ${n}.`;
}

// ── Rodar bloco individual ────────────────────────────────────────────────────
async function runBloco(n) {
  if (!state.roteiro) {
    showToast('Salve o roteiro primeiro!', 'err');
    goPanel('roteiro');
    return;
  }
  showLoading(`Gerando Bloco ${n}...`, 'Chamando a IA — aguarde');
  try {
    const data   = await callAPI({ prompt: buildPrompt(n) });
    state.results[n] = data.result;
    state.done.add(n);
    displayResult(n, data.result);
    updateProgress();
    updateBadge(n, '✓', 'done');
    showToast(`Bloco ${n} gerado!`, 'ok');
  } catch (e) {
    updateBadge(n, '!', 'err');
    showToast('Erro: ' + e.message, 'err');
  } finally {
    hideLoading();
  }
}

// ── Rodar tudo ────────────────────────────────────────────────────────────────
async function runAll() {
  if (!state.roteiro) {
    showToast('Salve o roteiro primeiro!', 'err');
    goPanel('roteiro');
    return;
  }
  const btn = document.getElementById('btn-run-all');
  btn.disabled = true;
  const names = ['Mapa','Verdade-Base','Ângulo','Roteiro Otimizado','Storyboard',
                 'Shotlist','Prompts Imagem','Prompts Vídeo','Overlays','Títulos',
                 'Thumbnail','Descrição SEO','Aba Comunidade','Auditoria'];
  for (let n = 1; n <= TOTAL; n++) {
    goPanel('bloco' + n);
    showLoading(`Bloco ${n} de ${TOTAL}`, `Gerando: ${names[n-1]}`);
    try {
      const data = await callAPI({ prompt: buildPrompt(n) });
      state.results[n] = data.result;
      state.done.add(n);
      displayResult(n, data.result);
      updateProgress();
      updateBadge(n, '✓', 'done');
    } catch (e) {
      updateBadge(n, '!', 'err');
      showToast(`Erro no Bloco ${n}: ${e.message}`, 'err');
    }
  }
  hideLoading();
  btn.disabled = false;
  showToast('🎉 Todos os blocos gerados!', 'ok');
}

// ── Salvar projeto no banco ───────────────────────────────────────────────────
async function saveProject() {
  if (!state.roteiro) { showToast('Nada para salvar ainda.', 'err'); return; }
  try {
    const data = await callAPI({
      action:     'save_project',
      project_id: state.project_id,
      titulo:     state.title || document.getElementById('project-title')?.value || 'Sem título',
      roteiro:    state.roteiro,
      resultados: state.results
    });
    if (data.ok) {
      state.project_id = data.project_id;
      showToast('Projeto salvo!', 'ok');
    }
  } catch (e) {
    showToast('Erro ao salvar: ' + e.message, 'err');
  }
}

// ── Listar projetos ───────────────────────────────────────────────────────────
async function loadProjects() {
  const container = document.getElementById('projects-list');
  container.innerHTML = '<div class="card" style="color:var(--muted);text-align:center;padding:2rem">Carregando...</div>';
  try {
    const data = await callAPI({ action: 'list_projects' });
    if (!data.projects || data.projects.length === 0) {
      container.innerHTML = '<div class="card" style="color:var(--muted);text-align:center;padding:2rem">Nenhum projeto salvo ainda.</div>';
      return;
    }
    container.innerHTML = data.projects.map(p => `
      <div class="project-item">
        <div>
          <div class="pi-title">${escHtml(p.titulo)}</div>
          <div class="pi-date">${p.criado_em}</div>
        </div>
        <div style="display:flex;gap:.5rem">
          <button class="btn btn-sm btn-ghost" onclick="loadProject(${p.id})">Abrir</button>
          <button class="pi-del" onclick="deleteProject(${p.id}, this)">✕</button>
        </div>
      </div>
    `).join('');
  } catch (e) {
    container.innerHTML = `<div class="card" style="color:var(--err);padding:2rem">Erro ao carregar: ${escHtml(e.message)}</div>`;
  }
}

async function loadProject(id) {
  showLoading('Carregando projeto...', 'Aguarde');
  try {
    const data = await callAPI({ action: 'load_project', project_id: id });
    if (data.error) throw new Error(data.error);
    const p = data.project;
    state.roteiro    = p.roteiro    || '';
    state.title      = p.titulo     || '';
    state.project_id = p.id;
    state.results    = p.resultados || {};
    state.done       = new Set(Object.keys(state.results).map(Number).filter(n => state.results[n]));
    // Restaura UI
    const roteiroEl = document.getElementById('roteiro');
    const titleEl   = document.getElementById('project-title');
    if (roteiroEl) roteiroEl.value = state.roteiro;
    if (titleEl)   titleEl.value   = state.title;
    for (let n = 1; n <= TOTAL; n++) {
      if (state.results[n]) {
        displayResult(n, state.results[n]);
        updateBadge(n, '✓', 'done');
      }
    }
    if (state.roteiro) {
      document.getElementById('badge-roteiro').textContent = '✓';
      document.querySelector('[data-panel="roteiro"]').classList.add('done');
      document.getElementById('btn-run-all').disabled = false;
    }
    updateProgress();
    showToast('Projeto carregado!', 'ok');
    goPanel('welcome');
  } catch (e) {
    showToast('Erro ao carregar: ' + e.message, 'err');
  } finally {
    hideLoading();
  }
}

async function deleteProject(id, btn) {
  if (!confirm('Deletar este projeto permanentemente?')) return;
  btn.disabled = true;
  try {
    await callAPI({ action: 'delete_project', project_id: id });
    loadProjects();
    showToast('Projeto deletado.', 'ok');
  } catch (e) {
    showToast('Erro: ' + e.message, 'err');
    btn.disabled = false;
  }
}

// ── Display ───────────────────────────────────────────────────────────────────
function displayResult(n, text) {
  document.getElementById('content-bloco' + n).textContent = text;
  document.getElementById('result-bloco'  + n).style.display = 'block';
  document.getElementById('empty-bloco'   + n).style.display = 'none';
}

function updateBadge(n, text, cls = '') {
  const badge = document.getElementById('badge-bloco' + n);
  const nav   = document.querySelector(`[data-panel="bloco${n}"]`);
  if (badge) badge.textContent = text;
  if (nav) {
    nav.classList.remove('done', 'err');
    if (cls) nav.classList.add(cls);
  }
}

// FIX #8: Clipboard com fallback para http://
function copyResult(n) {
  const text = document.getElementById('content-bloco' + n).textContent;
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text)
      .then(() => showToast('Copiado!', 'ok'))
      .catch(() => fallbackCopy(text));
  } else {
    fallbackCopy(text);
  }
}
function fallbackCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity  = '0';
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  document.body.removeChild(ta);
  showToast('Copiado!', 'ok');
}

// ── Reset ─────────────────────────────────────────────────────────────────────
function resetAll() {
  if (!confirm('Limpar tudo e começar um novo projeto?')) return;
  state.roteiro    = '';
  state.title      = '';
  state.project_id = 0;
  state.results    = {};
  state.done       = new Set();
  const roteiroEl = document.getElementById('roteiro');
  const titleEl   = document.getElementById('project-title');
  if (roteiroEl) roteiroEl.value = '';
  if (titleEl)   titleEl.value   = '';
  for (let n = 1; n <= TOTAL; n++) {
    document.getElementById('result-bloco'  + n).style.display = 'none';
    document.getElementById('empty-bloco'   + n).style.display = 'block';
    document.getElementById('content-bloco' + n).textContent   = '';
    updateBadge(n, '—');
  }
  document.getElementById('badge-roteiro').textContent = '—';
  document.querySelector('[data-panel="roteiro"]').classList.remove('done');
  document.getElementById('btn-run-all').disabled = true;
  updateProgress();
  goPanel('welcome');
}

// ── UI helpers ────────────────────────────────────────────────────────────────
function showLoading(title, sub) {
  document.getElementById('loading-text').textContent = title;
  document.getElementById('loading-sub').textContent  = sub;
  document.getElementById('loading').classList.add('show');
}
function hideLoading() {
  document.getElementById('loading').classList.remove('show');
}

let toastTimer;
function showToast(msg, type = 'ok') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className   = `toast ${type} show`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3500);
}

function escHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>

<?php endif; ?>
</body>
</html>
