<?php
/**
 * TATI STUDIO — DIAGNÓSTICO DO BANCO
 * Acesse: seusite.com/db-check.php
 * DELETE este arquivo após resolver o problema!
 */

// Proteção mínima: só roda se passar ?check=tati na URL
if (($_GET['check'] ?? '') !== 'tati') {
    http_response_code(403);
    die('<p style="font:1rem sans-serif;padding:2rem">Acesso negado. Use ?check=tati</p>');
}

$configFile = __DIR__ . '/includes/config.php';

echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
<title>DB Check — Tati Studio</title>
<style>
  * { box-sizing:border-box; margin:0; padding:0; }
  body { background:#0a0a0f; color:#eeeef8; font-family:monospace; padding:2rem; }
  h1 { font-size:1.2rem; margin-bottom:1.5rem; color:#ff6b35; }
  .item { display:flex; align-items:flex-start; gap:.75rem; padding:.7rem 1rem;
          border:1px solid #23233a; border-radius:8px; margin-bottom:.5rem; font-size:.9rem; }
  .ok   { border-color:#2dd4bf; color:#2dd4bf; }
  .err  { border-color:#f87171; color:#f87171; }
  .warn { border-color:#ffb703; color:#ffb703; }
  .icon { font-size:1.1rem; flex-shrink:0; }
  .label { flex:1; }
  .detail { font-size:.78rem; opacity:.7; margin-top:.2rem; word-break:break-all; }
  hr { border:none; border-top:1px solid #23233a; margin:1.5rem 0; }
  .box { background:#111119; border:1px solid #23233a; border-radius:10px; padding:1.5rem; margin-bottom:1rem; }
  .fix  { background:#1a1a0a; border-color:#ffb703; border-radius:8px; padding:1rem 1.2rem; margin-top:.5rem; font-size:.82rem; line-height:1.7; }
  code  { background:#222; padding:.1rem .4rem; border-radius:4px; color:#ffb703; }
</style></head><body>';

echo '<h1>🔍 Tati Studio — Diagnóstico do Banco de Dados</h1>';

// ── 1. Arquivo de config ──────────────────────────────────────────────────────
echo '<div class="box"><b>1. Arquivo de configuração</b><br><br>';

if (!file_exists($configFile)) {
    echo '<div class="item err"><span class="icon">✗</span><div class="label">
        includes/config.php não encontrado
        <div class="detail">Execute o installer.php ou install.sh para gerar o arquivo.</div>
    </div></div>';
    echo '</div></body></html>';
    exit;
}

echo '<div class="item ok"><span class="icon">✓</span><div class="label">includes/config.php encontrado</div></div>';

require_once $configFile;

// ── 2. Constantes definidas ───────────────────────────────────────────────────
echo '</div><div class="box"><b>2. Constantes do banco</b><br><br>';

$consts = ['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASS', 'ANTHROPIC_API_KEY'];
foreach ($consts as $c) {
    if (defined($c)) {
        $val = $c === 'DB_PASS' || $c === 'ANTHROPIC_API_KEY'
            ? substr(constant($c), 0, 6) . '...' . substr(constant($c), -4)
            : constant($c);
        echo "<div class='item ok'><span class='icon'>✓</span><div class='label'>{$c} = <code>{$val}</code></div></div>";
    } else {
        echo "<div class='item err'><span class='icon'>✗</span><div class='label'>{$c} não definida
            <div class='detail'>Esta constante está faltando no includes/config.php</div>
        </div></div>";
    }
}

// ── 3. Extensão PDO MySQL ─────────────────────────────────────────────────────
echo '</div><div class="box"><b>3. Extensões PHP</b><br><br>';

$exts = ['pdo', 'pdo_mysql', 'curl', 'json', 'mbstring'];
foreach ($exts as $ext) {
    if (extension_loaded($ext)) {
        echo "<div class='item ok'><span class='icon'>✓</span><div class='label'>Extensão <code>{$ext}</code> carregada</div></div>";
    } else {
        echo "<div class='item err'><span class='icon'>✗</span><div class='label'>Extensão <code>{$ext}</code> NÃO carregada
            <div class='detail'>Instale com: apt-get install php8.2-{$ext} ou ative no php.ini</div>
        </div></div>";
    }
}

// ── 4. Conexão com o MySQL ────────────────────────────────────────────────────
echo '</div><div class="box"><b>4. Conexão com o MySQL</b><br><br>';

if (!defined('DB_HOST') || !defined('DB_NAME')) {
    echo '<div class="item err"><span class="icon">✗</span><div class="label">Constantes não definidas — não é possível testar</div></div>';
} else {
    // Testa conexão SEM banco primeiro (só host)
    try {
        $dsnHost = sprintf('mysql:host=%s;port=%s;connect_timeout=5',
            DB_HOST, defined('DB_PORT') ? DB_PORT : '3306');
        $pdoHost = new PDO($dsnHost, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        echo '<div class="item ok"><span class="icon">✓</span><div class="label">
            Conexão com o servidor MySQL OK
            <div class="detail">' . DB_HOST . ':' . (defined('DB_PORT') ? DB_PORT : 3306) . ' — usuário: ' . DB_USER . '</div>
        </div></div>';

        // Testa se o banco existe
        try {
            $pdoHost->exec('USE `' . DB_NAME . '`');
            echo '<div class="item ok"><span class="icon">✓</span><div class="label">
                Banco <code>' . DB_NAME . '</code> existe e acessível
            </div></div>';

            // Testa se as tabelas existem
            $tables = $pdoHost->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            if (empty($tables)) {
                echo '<div class="item warn"><span class="icon">⚠</span><div class="label">
                    Banco vazio — tabelas não criadas
                    <div class="detail">Execute o SQL abaixo para criar as tabelas.</div>
                </div></div>';
                echo '<div class="fix">
                    <b>Execute este SQL no MySQL:</b><br><br>
                    <code>mysql -u ' . DB_USER . ' -p ' . DB_NAME . ' &lt; tabelas.sql</code><br><br>
                    Ou acesse o phpMyAdmin e execute:<br><br>
                    <pre style="background:#0a0a0f;padding:1rem;border-radius:6px;overflow-x:auto;font-size:.78rem">
CREATE TABLE IF NOT EXISTS projetos (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    titulo        VARCHAR(255) NOT NULL DEFAULT \'Sem título\',
    roteiro       LONGTEXT,
    resultados    JSON,
    criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS sessoes_log (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    ip        VARCHAR(45),
    acao      VARCHAR(100),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                    </pre>
                </div>';
            } else {
                foreach (['projetos', 'sessoes_log'] as $t) {
                    if (in_array($t, $tables)) {
                        echo "<div class='item ok'><span class='icon'>✓</span><div class='label'>Tabela <code>{$t}</code> existe</div></div>";
                    } else {
                        echo "<div class='item err'><span class='icon'>✗</span><div class='label'>Tabela <code>{$t}</code> não encontrada</div></div>";
                    }
                }

                // Teste de escrita
                try {
                    $pdoHost->exec("INSERT INTO sessoes_log (ip, acao) VALUES ('127.0.0.1', 'db_check')");
                    echo '<div class="item ok"><span class="icon">✓</span><div class="label">Escrita no banco OK</div></div>';
                } catch (Exception $e) {
                    echo '<div class="item err"><span class="icon">✗</span><div class="label">
                        Falha ao escrever no banco
                        <div class="detail">' . htmlspecialchars($e->getMessage()) . '</div>
                    </div></div>';
                }
            }

        } catch (Exception $e) {
            echo '<div class="item err"><span class="icon">✗</span><div class="label">
                Banco <code>' . DB_NAME . '</code> não encontrado ou sem permissão
                <div class="detail">' . htmlspecialchars($e->getMessage()) . '</div>
            </div></div>';
            echo '<div class="fix">
                <b>Para criar o banco e usuário, execute como root do MySQL:</b><br><br>
                <pre style="background:#0a0a0f;padding:1rem;border-radius:6px;font-size:.78rem">
CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '`
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS \'' . DB_USER . '\'@\'localhost\' IDENTIFIED BY \'SUA_SENHA\';
GRANT ALL PRIVILEGES ON `' . DB_NAME . '`.* TO \'' . DB_USER . '\'@\'localhost\';
FLUSH PRIVILEGES;
                </pre>
            </div>';
        }

    } catch (Exception $e) {
        $msg = $e->getMessage();
        echo '<div class="item err"><span class="icon">✗</span><div class="label">
            Falha ao conectar no MySQL
            <div class="detail">' . htmlspecialchars($msg) . '</div>
        </div></div>';

        // Diagnóstico específico por tipo de erro
        if (str_contains($msg, 'Access denied')) {
            echo '<div class="fix">
                ⚠ <b>Senha ou usuário incorretos</b><br>
                Verifique <code>DB_USER</code> e <code>DB_PASS</code> no <code>includes/config.php</code>.<br>
                Para redefinir a senha do usuário:<br>
                <code>ALTER USER \''.DB_USER.'\'@\'localhost\' IDENTIFIED BY \'nova_senha\';</code>
            </div>';
        } elseif (str_contains($msg, "Can't connect") || str_contains($msg, 'Connection refused')) {
            echo '<div class="fix">
                ⚠ <b>MySQL não está rodando ou porta bloqueada</b><br>
                Verifique com: <code>systemctl status mysql</code><br>
                Para iniciar: <code>systemctl start mysql</code>
            </div>';
        } elseif (str_contains($msg, 'No such file')) {
            echo '<div class="fix">
                ⚠ <b>Socket do MySQL não encontrado</b><br>
                MySQL pode não estar instalado. Instale com:<br>
                <code>apt-get install mysql-server</code>
            </div>';
        }
    }
}

// ── 5. Permissões de pasta ────────────────────────────────────────────────────
echo '</div><div class="box"><b>5. Permissões de pastas</b><br><br>';
$dirs = [
    __DIR__ . '/cache'    => 'cache/',
    __DIR__ . '/logs'     => 'logs/',
    __DIR__ . '/includes' => 'includes/',
];
foreach ($dirs as $path => $label) {
    if (!is_dir($path)) {
        echo "<div class='item warn'><span class='icon'>⚠</span><div class='label'>
            Pasta <code>{$label}</code> não existe — será criada automaticamente
        </div></div>";
        @mkdir($path, 0755, true);
    } elseif (is_writable($path)) {
        echo "<div class='item ok'><span class='icon'>✓</span><div class='label'>
            <code>{$label}</code> com permissão de escrita
        </div></div>";
    } else {
        echo "<div class='item err'><span class='icon'>✗</span><div class='label'>
            <code>{$label}</code> sem permissão de escrita
            <div class='detail'>Execute: chmod 755 {$path} && chown www-data:www-data {$path}</div>
        </div></div>";
    }
}

echo '</div>';
echo '<p style="color:#72728a;font-size:.8rem;margin-top:1rem">⚠ Delete o arquivo <code>db-check.php</code> após resolver o problema.</p>';
echo '</body></html>';
