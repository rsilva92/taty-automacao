<?php
// Este arquivo é gerado automaticamente pelo installer.php
// NÃO edite manualmente. Use o instalador.

define('ANTHROPIC_API_KEY', '');
define('APP_PASSWORD', '');
define('APP_SUBPATH', '');
define('APP_VERSION', '1.0.0');
define('INSTALLED', false);
