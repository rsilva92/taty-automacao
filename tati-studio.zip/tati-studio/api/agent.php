<?php
/**
 * TATI STUDIO — AGENTE API
 * Chama Anthropic e persiste resultados no MySQL.
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['auth'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado.']);
    exit;
}

$configFile = dirname(__DIR__) . '/includes/config.php';
if (!file_exists($configFile)) {
    http_response_code(500);
    echo json_encode(['error' => 'Sistema não configurado.']);
    exit;
}
require_once $configFile;

function getDB(): ?PDO {
    if (!defined('DB_HOST') || !defined('DB_NAME')) return null;
    try {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . (defined('DB_PORT') ? DB_PORT : 3306)
             . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        return new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT            => 5,
        ]);
    } catch (Exception $e) { return null; }
}

$raw  = file_get_contents('php://input');
$body = json_decode($raw, true) ?? [];
$action = $body['action'] ?? 'generate';

// ── Ações de banco ────────────────────────────────────────────────────────────
if ($action === 'save_project') {
    $pdo = getDB();
    if (!$pdo) { echo json_encode(['ok' => false, 'error' => 'Banco indisponível']); exit; }
    $titulo     = mb_substr(trim($body['titulo'] ?? 'Sem título'), 0, 255);
    $roteiro    = $body['roteiro'] ?? '';
    $resultados = json_encode($body['resultados'] ?? []);
    $pid        = isset($body['project_id']) ? (int)$body['project_id'] : 0;
    if ($pid > 0) {
        $pdo->prepare('UPDATE projetos SET titulo=?, roteiro=?, resultados=? WHERE id=?')
            ->execute([$titulo, $roteiro, $resultados, $pid]);
        echo json_encode(['ok' => true, 'project_id' => $pid]);
    } else {
        $pdo->prepare('INSERT INTO projetos (titulo, roteiro, resultados) VALUES (?,?,?)')
            ->execute([$titulo, $roteiro, $resultados]);
        echo json_encode(['ok' => true, 'project_id' => (int)$pdo->lastInsertId()]);
    }
    exit;
}

if ($action === 'list_projects') {
    $pdo = getDB();
    if (!$pdo) { echo json_encode(['projects' => []]); exit; }
    $rows = $pdo->query('SELECT id, titulo, criado_em FROM projetos ORDER BY criado_em DESC LIMIT 30')->fetchAll();
    echo json_encode(['projects' => $rows]);
    exit;
}

if ($action === 'load_project') {
    $pdo = getDB();
    if (!$pdo) { echo json_encode(['error' => 'Banco indisponível']); exit; }
    $id  = (int)($body['project_id'] ?? 0);
    $st  = $pdo->prepare('SELECT * FROM projetos WHERE id = ?');
    $st->execute([$id]);
    $project = $st->fetch();
    if (!$project) { echo json_encode(['error' => 'Não encontrado']); exit; }
    $project['resultados'] = json_decode($project['resultados'], true);
    echo json_encode(['project' => $project]);
    exit;
}

if ($action === 'delete_project') {
    $pdo = getDB();
    if (!$pdo) { echo json_encode(['ok' => false]); exit; }
    $pdo->prepare('DELETE FROM projetos WHERE id = ?')->execute([(int)($body['project_id'] ?? 0)]);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Geração via Anthropic ─────────────────────────────────────────────────────
$prompt = trim($body['prompt'] ?? '');
if (empty($prompt)) {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt vazio.']);
    exit;
}

$payload = json_encode([
    'model'      => 'claude-opus-4-5',
    'max_tokens' => 4096,
    'messages'   => [['role' => 'user', 'content' => $prompt]]
]);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_TIMEOUT        => 120,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: ' . ANTHROPIC_API_KEY,
        'anthropic-version: 2023-06-01',
    ],
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr) { http_response_code(500); echo json_encode(['error' => 'Erro cURL: '.$curlErr]); exit; }

$data = json_decode($response, true);
if ($httpCode !== 200) {
    echo json_encode(['error' => $data['error']['message'] ?? 'Erro API']);
    exit;
}

$result = implode('', array_column(
    array_filter($data['content'] ?? [], fn($b) => $b['type'] === 'text'),
    'text'
));

if (empty($result)) { http_response_code(500); echo json_encode(['error' => 'Sem conteúdo.']); exit; }

try {
    $pdo = getDB();
    if ($pdo) $pdo->prepare('INSERT INTO sessoes_log (ip, acao) VALUES (?,?)')->execute([$_SERVER['REMOTE_ADDR'] ?? '', 'bloco_gerado']);
} catch (Exception $e) {}

echo json_encode(['result' => $result]);
