<?php
/**
 * TATI STUDIO — AGENTE API v1.1.0
 * Chama Anthropic e persiste resultados no MySQL.
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

// ── Auth ──────────────────────────────────────────────────────────────────────
if (empty($_SESSION['auth'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado.']);
    exit;
}

// ── Config ────────────────────────────────────────────────────────────────────
$configFile = dirname(__DIR__) . '/includes/config.php';
if (!file_exists($configFile)) {
    http_response_code(500);
    echo json_encode(['error' => 'Sistema não configurado.']);
    exit;
}
require_once $configFile;

// Retorna PDO ou lança exceção com mensagem clara
function getDB(): PDO {
    if (!defined('DB_HOST') || !defined('DB_NAME')) {
        throw new RuntimeException('Constantes de banco não definidas. Verifique includes/config.php.');
    }
    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4;connect_timeout=5',
        DB_HOST,
        defined('DB_PORT') ? DB_PORT : '3306',
        DB_NAME
    );
    return new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
}

// Wrapper que captura e traduz o erro para o frontend
function tryDB(): array {
    try {
        return ['pdo' => getDB(), 'error' => null];
    } catch (Exception $e) {
        $msg = $e->getMessage();
        if (str_contains($msg, 'Access denied'))
            $friendly = 'Credenciais incorretas (Access denied). Verifique DB_USER e DB_PASS no config.php.';
        elseif (str_contains($msg, 'Connection refused'))
            $friendly = 'MySQL não está rodando. Execute: systemctl start mysql';
        elseif (str_contains($msg, "Can't connect"))
            $friendly = 'Não foi possível conectar ao MySQL. Verifique se o serviço está ativo.';
        elseif (str_contains($msg, 'Unknown database'))
            $friendly = 'Banco "' . (defined('DB_NAME') ? DB_NAME : '?') . '" não existe. Crie-o ou rode o instalador novamente.';
        else
            $friendly = 'Erro de banco: ' . $msg;
        return ['pdo' => null, 'error' => $friendly];
    }
}

// ── Input ─────────────────────────────────────────────────────────────────────
$raw    = file_get_contents('php://input');
$body   = json_decode($raw, true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'JSON inválido.']);
    exit;
}
$action = $body['action'] ?? 'generate';

// ── Ações de banco ────────────────────────────────────────────────────────────
if ($action === 'save_project') {
    ['pdo' => $pdo, 'error' => $dbErr] = tryDB();
    if (!$pdo) {
        echo json_encode(['ok' => false, 'error' => $dbErr]);
        exit;
    }
    $titulo     = mb_substr(trim($body['titulo'] ?? 'Sem título'), 0, 255);
    $roteiro    = $body['roteiro'] ?? '';
    $resultados = json_encode($body['resultados'] ?? [], JSON_UNESCAPED_UNICODE);
    $pid        = isset($body['project_id']) ? (int)$body['project_id'] : 0;

    if ($pid > 0) {
        $st = $pdo->prepare('UPDATE projetos SET titulo=?, roteiro=?, resultados=? WHERE id=?');
        $st->execute([$titulo, $roteiro, $resultados, $pid]);
        echo json_encode(['ok' => true, 'project_id' => $pid]);
    } else {
        $st = $pdo->prepare('INSERT INTO projetos (titulo, roteiro, resultados) VALUES (?,?,?)');
        $st->execute([$titulo, $roteiro, $resultados]);
        echo json_encode(['ok' => true, 'project_id' => (int)$pdo->lastInsertId()]);
    }
    exit;
}

if ($action === 'list_projects') {
    ['pdo' => $pdo, 'error' => $dbErr] = tryDB();
    if (!$pdo) {
        echo json_encode(['projects' => [], 'error' => $dbErr]);
        exit;
    }
    $rows = $pdo->query(
        'SELECT id, titulo, DATE_FORMAT(criado_em, "%d/%m/%Y %H:%i") AS criado_em
         FROM projetos ORDER BY criado_em DESC LIMIT 30'
    )->fetchAll();
    echo json_encode(['projects' => $rows]);
    exit;
}

if ($action === 'load_project') {
    ['pdo' => $pdo, 'error' => $dbErr] = tryDB();
    if (!$pdo) {
        echo json_encode(['error' => $dbErr]);
        exit;
    }
    $id = (int)($body['project_id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['error' => 'ID inválido']);
        exit;
    }
    $st = $pdo->prepare('SELECT * FROM projetos WHERE id = ?');
    $st->execute([$id]);
    $project = $st->fetch();
    if (!$project) {
        echo json_encode(['error' => 'Projeto não encontrado']);
        exit;
    }
    $project['resultados'] = json_decode($project['resultados'], true) ?? [];
    echo json_encode(['project' => $project]);
    exit;
}

if ($action === 'delete_project') {
    ['pdo' => $pdo, 'error' => $dbErr] = tryDB();
    if (!$pdo) {
        echo json_encode(['ok' => false, 'error' => $dbErr]);
        exit;
    }
    $id = (int)($body['project_id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['ok' => false, 'error' => 'ID inválido']);
        exit;
    }
    $pdo->prepare('DELETE FROM projetos WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Geração via Anthropic ─────────────────────────────────────────────────────
$prompt = trim($body['prompt'] ?? '');
if (empty($prompt)) {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt vazio.']);
    exit;
}

$payload = json_encode([
    'model'      => 'claude-opus-4-5',
    'max_tokens' => 4096,
    'messages'   => [
        ['role' => 'user', 'content' => $prompt]
    ]
], JSON_UNESCAPED_UNICODE);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_TIMEOUT        => 120,
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: '          . ANTHROPIC_API_KEY,
        'anthropic-version: 2023-06-01',
    ],
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro de conexão: ' . $curlErr]);
    exit;
}

$data = json_decode($response, true);
if ($httpCode !== 200) {
    $msg = is_array($data) ? ($data['error']['message'] ?? 'Erro desconhecido da API') : 'Erro da API';
    http_response_code($httpCode >= 400 ? $httpCode : 500);
    echo json_encode(['error' => $msg]);
    exit;
}

// Extrai texto de todos os blocos de conteúdo
$result = '';
foreach ($data['content'] ?? [] as $block) {
    if (isset($block['type']) && $block['type'] === 'text') {
        $result .= $block['text'];
    }
}

if (empty(trim($result))) {
    http_response_code(500);
    echo json_encode(['error' => 'A IA retornou resposta vazia.']);
    exit;
}

// Log de uso (silencioso — não bloqueia resposta)
try {
    ['pdo' => $logPdo, 'error' => $logErr] = tryDB();
    if ($logPdo) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $ip = substr($ip, 0, 45);
        $logPdo->prepare('INSERT INTO sessoes_log (ip, acao) VALUES (?,?)')
               ->execute([$ip, 'bloco_gerado']);
    }
} catch (Exception $e) {
    // Silencia erros de log para não afetar a resposta principal
}

echo json_encode(['result' => $result], JSON_UNESCAPED_UNICODE);
