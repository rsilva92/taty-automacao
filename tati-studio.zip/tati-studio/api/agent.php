<?php
/**
 * TATI STUDIO — AGENTE API
 * Recebe prompt do frontend, chama Anthropic e retorna resultado.
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

// ── Auth ──────────────────────────────────────────────────────────────────────
if (empty($_SESSION['auth'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado.']);
    exit;
}

// ── Config ────────────────────────────────────────────────────────────────────
$configFile = dirname(__DIR__) . '/includes/config.php';
if (!file_exists($configFile)) {
    http_response_code(500);
    echo json_encode(['error' => 'Sistema não configurado. Execute o instalador.']);
    exit;
}
require_once $configFile;

// ── Input ─────────────────────────────────────────────────────────────────────
$body = json_decode(file_get_contents('php://input'), true);
$prompt = trim($body['prompt'] ?? '');

if (empty($prompt)) {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt vazio.']);
    exit;
}

// ── Call Anthropic ────────────────────────────────────────────────────────────
$payload = json_encode([
    'model'      => 'claude-opus-4-5',
    'max_tokens' => 4096,
    'messages'   => [
        ['role' => 'user', 'content' => $prompt]
    ]
]);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_TIMEOUT        => 120,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: ' . ANTHROPIC_API_KEY,
        'anthropic-version: 2023-06-01',
    ],
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro de conexão: ' . $curlErr]);
    exit;
}

$data = json_decode($response, true);

if ($httpCode !== 200) {
    $msg = $data['error']['message'] ?? 'Erro desconhecido da API.';
    http_response_code($httpCode);
    echo json_encode(['error' => $msg]);
    exit;
}

// ── Extrai texto ──────────────────────────────────────────────────────────────
$result = '';
foreach ($data['content'] ?? [] as $block) {
    if ($block['type'] === 'text') {
        $result .= $block['text'];
    }
}

if (empty($result)) {
    http_response_code(500);
    echo json_encode(['error' => 'A IA não retornou conteúdo.']);
    exit;
}

echo json_encode(['result' => $result]);
