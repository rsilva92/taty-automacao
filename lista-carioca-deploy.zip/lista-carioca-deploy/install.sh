#!/bin/bash

# =============================================================================
#  Lista Carioca — Script de Instalação Completa
#  Servidor: Ubuntu/Debian + Apache2 + MySQL + PHP 8.2
#  Uso: sudo bash install.sh
# =============================================================================

set -e  # Para o script se qualquer comando falhar

# ─── Cores para output ───────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ─── Funções de log ──────────────────────────────────────────────────────────
log_info()    { echo -e "${BLUE}[INFO]${NC}  $1"; }
log_ok()      { echo -e "${GREEN}[OK]${NC}    $1"; }
log_warn()    { echo -e "${YELLOW}[AVISO]${NC} $1"; }
log_error()   { echo -e "${RED}[ERRO]${NC}  $1"; exit 1; }
log_section() { echo -e "\n${CYAN}${BOLD}══════════════════════════════════════════${NC}"; \
                echo -e "${CYAN}${BOLD}  $1${NC}"; \
                echo -e "${CYAN}${BOLD}══════════════════════════════════════════${NC}\n"; }

# ─── Banner ──────────────────────────────────────────────────────────────────
clear
echo -e "${ORANGE}"
cat << 'EOF'
  _     _     _        ____            _
 | |   (_)___| |_ __ _/ ___|__ _ _ __(_) ___   ___ __ _
 | |   | / __| __/ _` | |   / _` | '__| |/ _ \ / __/ _` |
 | |___| \__ \ || (_| | |__| (_| | |  | | (_) | (_| (_| |
 |_____|_|___/\__\__,_|\____\__,_|_|  |_|\___/ \___\__,_|

  Marketplace de Serviços de Beleza — Cabo Frio, RJ
  Script de Instalação v1.0
EOF
echo -e "${NC}"

# ─── Verificar root ──────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    log_error "Este script deve ser executado como root. Use: sudo bash install.sh"
fi

# ─── Verificar sistema operacional ───────────────────────────────────────────
if ! command -v apt-get &>/dev/null; then
    log_error "Este script suporta apenas sistemas baseados em Debian/Ubuntu (apt-get não encontrado)."
fi

# =============================================================================
#  CONFIGURAÇÕES — edite aqui antes de rodar
# =============================================================================

APP_NAME="lista-carioca"
APP_DIR="/var/www/${APP_NAME}"
APP_DOMAIN="${APP_DOMAIN:-lista-carioca.local}"        # domínio do site
DB_NAME="${DB_NAME:-lista_carioca}"                    # nome do banco
DB_USER="${DB_USER:-listacarioca}"                     # usuário do banco
DB_PASS="${DB_PASS:-$(openssl rand -base64 16)}"       # senha gerada automaticamente
MYSQL_ROOT_PASS="${MYSQL_ROOT_PASS:-}"                 # deixe vazio se não tiver senha no root
PHP_VERSION="8.2"
COMPOSER_INSTALL_DIR="/usr/local/bin"

# Mostrar configurações
echo -e "${BOLD}Configurações da instalação:${NC}"
echo -e "  Diretório da app : ${YELLOW}${APP_DIR}${NC}"
echo -e "  Domínio          : ${YELLOW}${APP_DOMAIN}${NC}"
echo -e "  Banco de dados   : ${YELLOW}${DB_NAME}${NC}"
echo -e "  Usuário DB       : ${YELLOW}${DB_USER}${NC}"
echo -e "  Senha DB         : ${YELLOW}${DB_PASS}${NC}"
echo ""
read -p "$(echo -e ${BOLD}Continuar com estas configurações? [s/N]: ${NC})" CONFIRM
[[ "${CONFIRM,,}" != "s" ]] && echo "Instalação cancelada." && exit 0

# =============================================================================
#  1. ATUALIZAR SISTEMA
# =============================================================================
log_section "1. Atualizando sistema"

apt-get update -qq
apt-get upgrade -y -qq
log_ok "Sistema atualizado"

# =============================================================================
#  2. INSTALAR DEPENDÊNCIAS BASE
# =============================================================================
log_section "2. Instalando dependências base"

apt-get install -y -qq \
    curl \
    wget \
    git \
    unzip \
    zip \
    software-properties-common \
    apt-transport-https \
    ca-certificates \
    gnupg \
    lsb-release \
    openssl

log_ok "Dependências base instaladas"

# =============================================================================
#  3. INSTALAR PHP 8.2 + EXTENSÕES
# =============================================================================
log_section "3. Instalando PHP ${PHP_VERSION} e extensões"

# Adicionar repositório Ondrej PPA (PHP atualizado)
if ! grep -q "ondrej/php" /etc/apt/sources.list.d/* 2>/dev/null; then
    add-apt-repository ppa:ondrej/php -y -q
    apt-get update -qq
fi

apt-get install -y -qq \
    php${PHP_VERSION} \
    php${PHP_VERSION}-cli \
    php${PHP_VERSION}-fpm \
    php${PHP_VERSION}-common \
    php${PHP_VERSION}-mysql \
    php${PHP_VERSION}-xml \
    php${PHP_VERSION}-xmlrpc \
    php${PHP_VERSION}-curl \
    php${PHP_VERSION}-gd \
    php${PHP_VERSION}-imagick \
    php${PHP_VERSION}-dev \
    php${PHP_VERSION}-imap \
    php${PHP_VERSION}-mbstring \
    php${PHP_VERSION}-opcache \
    php${PHP_VERSION}-soap \
    php${PHP_VERSION}-zip \
    php${PHP_VERSION}-intl \
    php${PHP_VERSION}-bcmath \
    php${PHP_VERSION}-tokenizer \
    php${PHP_VERSION}-fileinfo \
    libapache2-mod-php${PHP_VERSION}

log_ok "PHP ${PHP_VERSION} instalado"

# Definir versão padrão
update-alternatives --set php /usr/bin/php${PHP_VERSION} 2>/dev/null || true

PHP_ACTUAL=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
log_ok "PHP ativo: ${PHP_ACTUAL}"

# =============================================================================
#  4. INSTALAR APACHE2
# =============================================================================
log_section "4. Instalando e configurando Apache2"

apt-get install -y -qq apache2

# Habilitar módulos necessários
a2enmod rewrite
a2enmod headers
a2enmod ssl
a2enmod php${PHP_VERSION}

systemctl enable apache2
systemctl start apache2

log_ok "Apache2 instalado e em execução"

# =============================================================================
#  5. INSTALAR MYSQL
# =============================================================================
log_section "5. Instalando MySQL"

# Instalar MySQL de forma não interativa
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq mysql-server mysql-client

systemctl enable mysql
systemctl start mysql

log_ok "MySQL instalado e em execução"

# =============================================================================
#  6. CONFIGURAR BANCO DE DADOS
# =============================================================================
log_section "6. Configurando banco de dados"

# Função para executar SQL no MySQL
mysql_exec() {
    if [[ -n "${MYSQL_ROOT_PASS}" ]]; then
        mysql -u root -p"${MYSQL_ROOT_PASS}" -e "$1" 2>/dev/null
    else
        mysql -u root -e "$1" 2>/dev/null
    fi
}

# Criar banco e usuário
mysql_exec "CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql_exec "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
mysql_exec "GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';"
mysql_exec "FLUSH PRIVILEGES;"

log_ok "Banco '${DB_NAME}' e usuário '${DB_USER}' criados"

# =============================================================================
#  7. INSTALAR COMPOSER
# =============================================================================
log_section "7. Instalando Composer"

if command -v composer &>/dev/null; then
    log_info "Composer já instalado: $(composer --version --no-ansi 2>/dev/null | head -1)"
else
    EXPECTED_CHECKSUM="$(php -r 'copy("https://composer.github.io/installer.sig", "php://stdout");')"
    php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
    ACTUAL_CHECKSUM="$(php -r "echo hash_file('sha384', 'composer-setup.php');")"

    if [ "$EXPECTED_CHECKSUM" != "$ACTUAL_CHECKSUM" ]; then
        rm -f composer-setup.php
        log_error "Falha na verificação do instalador do Composer"
    fi

    php composer-setup.php --quiet --install-dir=${COMPOSER_INSTALL_DIR} --filename=composer
    rm -f composer-setup.php
    log_ok "Composer instalado: $(composer --version --no-ansi 2>/dev/null | head -1)"
fi

# =============================================================================
#  8. INSTALAR APLICAÇÃO
# =============================================================================
log_section "8. Instalando a aplicação Lista Carioca"

# Determinar onde está o ZIP do projeto
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ZIP_FILE="${SCRIPT_DIR}/lista-carioca.zip"

if [[ ! -f "${ZIP_FILE}" ]]; then
    log_error "Arquivo lista-carioca.zip não encontrado em: ${SCRIPT_DIR}\nColoque o install.sh e lista-carioca.zip na mesma pasta."
fi

# Criar diretório e extrair
rm -rf "${APP_DIR}"
mkdir -p "${APP_DIR}"
unzip -q "${ZIP_FILE}" -d /tmp/lista-carioca-extract/

# Encontrar a pasta raiz dentro do ZIP
EXTRACTED_DIR=$(find /tmp/lista-carioca-extract -maxdepth 1 -type d | grep -v "^/tmp/lista-carioca-extract$" | head -1)
if [[ -z "${EXTRACTED_DIR}" ]]; then
    log_error "Não foi possível encontrar a pasta extraída do ZIP."
fi

cp -r "${EXTRACTED_DIR}/." "${APP_DIR}/"
rm -rf /tmp/lista-carioca-extract/

log_ok "Arquivos extraídos para ${APP_DIR}"

# =============================================================================
#  9. CONFIGURAR .ENV
# =============================================================================
log_section "9. Configurando variáveis de ambiente"

cd "${APP_DIR}"

cp .env.example .env

# Atualizar .env com as configurações reais
sed -i "s|APP_NAME=.*|APP_NAME=\"Lista Carioca\"|"            .env
sed -i "s|APP_ENV=.*|APP_ENV=production|"                    .env
sed -i "s|APP_DEBUG=.*|APP_DEBUG=false|"                     .env
sed -i "s|APP_URL=.*|APP_URL=http://${APP_DOMAIN}|"          .env
sed -i "s|DB_DATABASE=.*|DB_DATABASE=${DB_NAME}|"            .env
sed -i "s|DB_USERNAME=.*|DB_USERNAME=${DB_USER}|"            .env
sed -i "s|DB_PASSWORD=.*|DB_PASSWORD=${DB_PASS}|"            .env
sed -i "s|DB_HOST=.*|DB_HOST=127.0.0.1|"                    .env
sed -i "s|DB_PORT=.*|DB_PORT=3306|"                          .env

log_ok ".env configurado"

# =============================================================================
#  10. INSTALAR DEPENDÊNCIAS PHP (COMPOSER)
# =============================================================================
log_section "10. Instalando dependências do Composer"

composer install \
    --no-dev \
    --optimize-autoloader \
    --no-interaction \
    --prefer-dist \
    --quiet

log_ok "Dependências Composer instaladas"

# =============================================================================
#  11. CONFIGURAR LARAVEL
# =============================================================================
log_section "11. Configurando Laravel"

# Gerar chave da aplicação
php artisan key:generate --force
log_ok "APP_KEY gerada"

# Rodar migrations
log_info "Rodando migrations..."
php artisan migrate --force
log_ok "Migrations executadas"

# Popular banco com dados de teste
log_info "Populando banco de dados (seeders)..."
php artisan db:seed --force
log_ok "Seeders executados"

# Cache de configuração para produção
php artisan config:cache
php artisan route:cache
php artisan view:cache
log_ok "Cache de produção gerado"

# =============================================================================
#  12. PERMISSÕES
# =============================================================================
log_section "12. Configurando permissões"

# Definir dono dos arquivos
chown -R www-data:www-data "${APP_DIR}"

# Permissões de diretórios e arquivos
find "${APP_DIR}" -type f -exec chmod 644 {} \;
find "${APP_DIR}" -type d -exec chmod 755 {} \;

# Storage e bootstrap/cache precisam de escrita
chmod -R 775 "${APP_DIR}/storage"
chmod -R 775 "${APP_DIR}/bootstrap/cache"

# Criar link simbólico do storage público
php artisan storage:link 2>/dev/null || true

log_ok "Permissões configuradas"

# =============================================================================
#  13. CONFIGURAR VIRTUAL HOST DO APACHE
# =============================================================================
log_section "13. Configurando Virtual Host do Apache"

VHOST_FILE="/etc/apache2/sites-available/${APP_NAME}.conf"

cat > "${VHOST_FILE}" << VHOST
<VirtualHost *:80>
    ServerName ${APP_DOMAIN}
    ServerAlias www.${APP_DOMAIN}
    DocumentRoot ${APP_DIR}/public

    <Directory ${APP_DIR}/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted

        # Segurança básica
        Header always set X-Content-Type-Options "nosniff"
        Header always set X-Frame-Options "SAMEORIGIN"
        Header always set X-XSS-Protection "1; mode=block"
        Header always set Referrer-Policy "strict-origin-when-cross-origin"
    </Directory>

    # Logs
    ErrorLog \${APACHE_LOG_DIR}/${APP_NAME}-error.log
    CustomLog \${APACHE_LOG_DIR}/${APP_NAME}-access.log combined

    # Compressão gzip
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css
        AddOutputFilterByType DEFLATE application/javascript application/json
    </IfModule>

    # Cache de assets estáticos
    <IfModule mod_expires.c>
        ExpiresActive On
        ExpiresByType text/css "access plus 1 month"
        ExpiresByType application/javascript "access plus 1 month"
        ExpiresByType image/png "access plus 1 month"
        ExpiresByType image/jpeg "access plus 1 month"
    </IfModule>
</VirtualHost>
VHOST

# Habilitar módulos extras
a2enmod deflate expires 2>/dev/null || true

# Desabilitar site padrão e habilitar o nosso
a2dissite 000-default.conf 2>/dev/null || true
a2ensite "${APP_NAME}.conf"

# Verificar configuração do Apache
if apache2ctl configtest 2>/dev/null; then
    systemctl reload apache2
    log_ok "Virtual Host configurado e Apache recarregado"
else
    log_warn "Erro na configuração do Apache. Verifique: apache2ctl configtest"
fi

# =============================================================================
#  14. CONFIGURAR PHP PARA PRODUÇÃO
# =============================================================================
log_section "14. Otimizando PHP para produção"

PHP_INI="/etc/php/${PHP_VERSION}/apache2/php.ini"

if [[ -f "${PHP_INI}" ]]; then
    # Configurações de segurança e performance
    sed -i "s/^expose_php = .*/expose_php = Off/"               "${PHP_INI}"
    sed -i "s/^display_errors = .*/display_errors = Off/"       "${PHP_INI}"
    sed -i "s/^log_errors = .*/log_errors = On/"                "${PHP_INI}"
    sed -i "s/^memory_limit = .*/memory_limit = 256M/"          "${PHP_INI}"
    sed -i "s/^upload_max_filesize = .*/upload_max_filesize = 20M/" "${PHP_INI}"
    sed -i "s/^post_max_size = .*/post_max_size = 25M/"         "${PHP_INI}"
    sed -i "s/^max_execution_time = .*/max_execution_time = 60/" "${PHP_INI}"
    sed -i "s/^;date.timezone =.*/date.timezone = America\/Sao_Paulo/" "${PHP_INI}"

    # OPcache para performance
    cat >> "${PHP_INI}" << 'OPCACHE'

; OPcache — Lista Carioca
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=10000
opcache.revalidate_freq=0
opcache.validate_timestamps=0
OPCACHE

    systemctl reload apache2
    log_ok "PHP otimizado para produção"
else
    log_warn "php.ini não encontrado em ${PHP_INI} — ajustes PHP pulados"
fi

# =============================================================================
#  15. CONFIGURAR MYSQL PARA PRODUÇÃO
# =============================================================================
log_section "15. Otimizando MySQL"

MYSQL_CONF="/etc/mysql/mysql.conf.d/mysqld.cnf"

if [[ -f "${MYSQL_CONF}" ]]; then
    cat >> "${MYSQL_CONF}" << 'MYSQLCONF'

# Otimizações — Lista Carioca
[mysqld]
innodb_buffer_pool_size = 256M
innodb_log_file_size = 64M
max_connections = 150
query_cache_type = 1
query_cache_size = 32M
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 2
MYSQLCONF

    systemctl restart mysql
    log_ok "MySQL otimizado"
fi

# =============================================================================
#  16. CONFIGURAR CRON (Laravel Scheduler)
# =============================================================================
log_section "16. Configurando Cron para Laravel Scheduler"

CRON_JOB="* * * * * www-data cd ${APP_DIR} && php artisan schedule:run >> /dev/null 2>&1"
CRON_FILE="/etc/cron.d/${APP_NAME}"

echo "${CRON_JOB}" > "${CRON_FILE}"
chmod 644 "${CRON_FILE}"

log_ok "Cron configurado em ${CRON_FILE}"

# =============================================================================
#  17. CONFIGURAR LOGROTATE
# =============================================================================
log_section "17. Configurando rotação de logs"

cat > "/etc/logrotate.d/${APP_NAME}" << LOGROTATE
${APP_DIR}/storage/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0664 www-data www-data
    sharedscripts
    postrotate
        /usr/bin/php ${APP_DIR}/artisan queue:restart > /dev/null 2>&1 || true
    endscript
}
LOGROTATE

log_ok "Logrotate configurado"

# =============================================================================
#  18. CONFIGURAR /ETC/HOSTS (se domínio local)
# =============================================================================
if [[ "${APP_DOMAIN}" == *".local"* ]] || [[ "${APP_DOMAIN}" == *"localhost"* ]]; then
    log_section "18. Adicionando domínio local em /etc/hosts"

    if ! grep -q "${APP_DOMAIN}" /etc/hosts; then
        echo "127.0.0.1  ${APP_DOMAIN}" >> /etc/hosts
        log_ok "${APP_DOMAIN} adicionado em /etc/hosts"
    else
        log_info "${APP_DOMAIN} já existe em /etc/hosts"
    fi
fi

# =============================================================================
#  19. VERIFICAÇÃO FINAL
# =============================================================================
log_section "19. Verificação final"

ERRORS=0

# Verificar serviços
for SERVICE in apache2 mysql; do
    if systemctl is-active --quiet "${SERVICE}"; then
        log_ok "${SERVICE} está rodando"
    else
        log_warn "${SERVICE} NÃO está rodando"
        ((ERRORS++))
    fi
done

# Verificar PHP
if php -v &>/dev/null; then
    log_ok "PHP $(php -r 'echo PHP_VERSION;') funcionando"
else
    log_warn "PHP com problema"
    ((ERRORS++))
fi

# Verificar conexão com banco
if php -r "new PDO('mysql:host=127.0.0.1;dbname=${DB_NAME}', '${DB_USER}', '${DB_PASS}');" 2>/dev/null; then
    log_ok "Conexão com banco de dados OK"
else
    log_warn "Falha na conexão com banco"
    ((ERRORS++))
fi

# Verificar Laravel
if cd "${APP_DIR}" && php artisan --version &>/dev/null; then
    log_ok "Laravel $(php artisan --version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1) OK"
else
    log_warn "Problema com o Laravel"
    ((ERRORS++))
fi

# =============================================================================
#  RESUMO FINAL
# =============================================================================
echo ""
echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}${BOLD}║          INSTALAÇÃO CONCLUÍDA!                       ║${NC}"
echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════╝${NC}"
echo ""

if [[ $ERRORS -gt 0 ]]; then
    echo -e "${YELLOW}${BOLD}⚠  Instalação concluída com ${ERRORS} aviso(s). Verifique acima.${NC}"
else
    echo -e "${GREEN}${BOLD}✓  Instalação 100% concluída sem erros!${NC}"
fi

echo ""
echo -e "${BOLD}📌 Acesso ao sistema:${NC}"
echo -e "   URL:          ${GREEN}http://${APP_DOMAIN}${NC}"
echo ""
echo -e "${BOLD}🔐 Credenciais de acesso:${NC}"
echo -e "   Admin:        ${YELLOW}admin@listacarioca.com.br${NC} / ${YELLOW}password${NC}"
echo -e "   Parceiro:     ${YELLOW}ana@salaobeladona.com${NC} / ${YELLOW}password${NC}"
echo -e "   Cliente:      ${YELLOW}maria@email.com${NC} / ${YELLOW}password${NC}"
echo ""
echo -e "${BOLD}🗄️  Banco de dados:${NC}"
echo -e "   Banco:        ${YELLOW}${DB_NAME}${NC}"
echo -e "   Usuário:      ${YELLOW}${DB_USER}${NC}"
echo -e "   Senha:        ${YELLOW}${DB_PASS}${NC}"
echo ""
echo -e "${BOLD}📂 Arquivos:${NC}"
echo -e "   App:          ${YELLOW}${APP_DIR}${NC}"
echo -e "   Logs Apache:  ${YELLOW}/var/log/apache2/${APP_NAME}-error.log${NC}"
echo -e "   Logs Laravel: ${YELLOW}${APP_DIR}/storage/logs/laravel.log${NC}"
echo ""
echo -e "${BOLD}🔧 Comandos úteis:${NC}"
echo -e "   Reiniciar Apache:  ${CYAN}systemctl restart apache2${NC}"
echo -e "   Reiniciar MySQL:   ${CYAN}systemctl restart mysql${NC}"
echo -e "   Logs em tempo real:${CYAN}tail -f ${APP_DIR}/storage/logs/laravel.log${NC}"
echo -e "   Limpar cache:      ${CYAN}cd ${APP_DIR} && php artisan optimize:clear${NC}"
echo ""

# Salvar credenciais em arquivo seguro
CREDS_FILE="/root/.lista-carioca-credentials.txt"
cat > "${CREDS_FILE}" << CREDS
=== Lista Carioca — Credenciais de Instalação ===
Data: $(date)

URL: http://${APP_DOMAIN}

Banco de dados:
  Nome:   ${DB_NAME}
  Usuário: ${DB_USER}
  Senha:  ${DB_PASS}

Acessos do sistema:
  Admin:    admin@listacarioca.com.br / password
  Parceiro: ana@salaobeladona.com / password
  Cliente:  maria@email.com / password
CREDS
chmod 600 "${CREDS_FILE}"
echo -e "${BOLD}💾 Credenciais salvas em:${NC} ${YELLOW}${CREDS_FILE}${NC}"
echo ""
